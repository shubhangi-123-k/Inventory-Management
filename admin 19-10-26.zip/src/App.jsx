import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Products from './pages/Products';
import ProductDetails from './pages/ProductDetails';
import Brands from './pages/Brands';
import Occasions from './pages/Occasions';
import Warehouses from './pages/Warehouses';
import Racking from './pages/Racking';
import Inventory from './pages/Inventory';
import Countries from './pages/Countries';
import Customs from './pages/Customs';
import Groups from './pages/Groups';
import GroupDetails from './pages/GroupDetails';
import Purchases from './pages/Purchases';
import Companies from './pages/Companies';
import Customers from './pages/Customers';
import CustomerForm from './pages/CustomerForm';
import CustomerDetails from './pages/CustomerDetails';
import Sales from './pages/Sales';
import SalesOrderForm from './pages/SalesOrderForm';
import UserManagement from './pages/UserManagement';
import Settings from './pages/Settings';

const SuperAdminRoute = ({ children }) => {
  const { user, loading } = useAuth();
  if (loading) return <div>Loading...</div>;
  if (!user || user.role !== 'SUPER_ADMIN') return <Navigate to="/" />;
  return children;
};

const PrivateRoute = ({ children }) => {
  const { user, loading } = useAuth();

  if (loading) return <div>Loading...</div>;

  if (!user) return <Navigate to="/login" />;

  return children;
};

function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route
        path="/"
        element={
          <PrivateRoute>
            <Layout />
          </PrivateRoute>
        }
      >
        <Route index element={<Dashboard />} />
        <Route path="products" element={<Products />} />
        <Route path="products/:id" element={<ProductDetails />} />
        <Route path="brands" element={<Brands />} />
        <Route path="occasions" element={<Occasions />} />
        <Route path="warehouses" element={<Warehouses />} />
        <Route path="racking" element={<Racking />} />
        <Route path="rackbin" element={<Racking />} />
        <Route path="inventory" element={<Inventory />} />
        <Route path="countries" element={<Countries />} />
        <Route path="customs" element={<Customs />} />
        <Route path="groups" element={<Groups />} />
        <Route path="groups/:id" element={<GroupDetails />} />
        <Route path="purchases" element={<Purchases />} />
        <Route path="companies" element={<Companies />} />
        <Route path="customers" element={<Customers />} />
        <Route path="customers/new" element={<CustomerForm />} />
        <Route path="customers/:id/edit" element={<CustomerForm />} />
        <Route path="customers/:id" element={<CustomerDetails />} />
        <Route path="sales" element={<Sales />} />
        <Route path="sales/new" element={<SalesOrderForm />} />
        <Route path="sales/:id" element={<SalesOrderForm />} />
        <Route path="users" element={<SuperAdminRoute><UserManagement /></SuperAdminRoute>} />
        <Route path="settings" element={<SuperAdminRoute><Settings /></SuperAdminRoute>} />
      </Route>
    </Routes>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router basename={import.meta.env.BASE_URL}>
        <AppRoutes />
      </Router>
    </AuthProvider>
  );
}

export default App;
