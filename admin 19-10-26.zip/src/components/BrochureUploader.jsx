import React, { useState, useRef, useEffect } from 'react';
import { Upload, FileText, MoreVertical, Eye, Edit2, Share2, Trash2, X, Download, ExternalLink, Check, Send, AlertCircle, FileCheck } from 'lucide-react';
import api from '../api/axios';

const BrochureUploader = ({
  brochureUrl = '',
  brochureName = '',
  onChange,
  label = 'Company Brochure'
}) => {
  const [uploading, setUploading] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [storedFile, setStoredFile] = useState(null);
  const [sharingMethod, setSharingMethod] = useState('');
  const [shareSuccessMsg, setShareSuccessMsg] = useState('');
  const [dragActive, setDragActive] = useState(false);

  const fileInputRef = useRef(null);
  const menuRef = useRef(null);

  // Close dropdown menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setMenuOpen(false);
      }
    };
    if (menuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [menuOpen]);

  const readFileAsDataUrl = (file) => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target.result);
      reader.onerror = () => resolve(URL.createObjectURL(file));
      reader.readAsDataURL(file);
    });
  };

  const handleFileUpload = async (file) => {
    if (!file) return;

    setStoredFile(file);
    setUploading(true);
    const fileName = file.name || 'Company_Brochure.pdf';

    try {
      // Immediate local preview
      const localUrl = await readFileAsDataUrl(file);
      onChange({ url: localUrl, name: fileName });

      // Try uploading to backend / S3 with timeout guard
      const formData = new FormData();
      formData.append('brochure', file);
      formData.append('image', file);
      formData.append('folder', 'brochures');

      let res;
      try {
        res = await api.post('/upload/brochure', formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
          timeout: 8000
        });
      } catch (uploadErr) {
        // Fallback to /upload/image
        res = await api.post('/upload/image', formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
          timeout: 8000
        });
      }

      if (res?.data?.url) {
        onChange({ url: res.data.url, name: fileName });
      }
    } catch (err) {
      console.warn('Backend upload failed or timed out, preserved local brochure preview:', err);
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // Helper to retrieve actual File object from dataUrl or remote url
  const getBrochureFile = async () => {
    if (storedFile) return storedFile;

    const safeName = brochureName || 'Company_Brochure.pdf';
    const mimeType = safeName.toLowerCase().endsWith('.pdf') ? 'application/pdf' : 'application/octet-stream';

    if (brochureUrl.startsWith('data:')) {
      const res = await fetch(brochureUrl);
      const blob = await res.blob();
      return new File([blob], safeName, { type: blob.type || mimeType });
    }

    if (brochureUrl.startsWith('http')) {
      try {
        const res = await fetch(brochureUrl);
        const blob = await res.blob();
        return new File([blob], safeName, { type: blob.type || mimeType });
      } catch (e) {
        console.warn('Cross-origin fetch failed for brochure url:', e);
      }
    }

    return null;
  };

  // Direct File Share handler (Native Web Share API with File)
  const handleShareFileDirectly = async () => {
    setMenuOpen(false);
    setShareSuccessMsg('');

    try {
      const fileToShare = await getBrochureFile();

      if (fileToShare && navigator.canShare && navigator.canShare({ files: [fileToShare] })) {
        await navigator.share({
          files: [fileToShare],
          title: brochureName || 'Company Brochure PDF',
          text: `Please find attached Company Brochure PDF: ${brochureName || ''}`
        });
        return;
      }
    } catch (err) {
      if (err.name !== 'AbortError') {
        console.warn('Native file share error:', err);
      }
    }

    // If native file share is not supported or cancelled, open the Send as PDF modal
    setShowShareModal(true);
  };

  // Trigger browser download so user has the file locally ready to attach/send
  const handleDownloadPDF = async () => {
    try {
      const safeName = brochureName || 'Company_Brochure.pdf';
      const fileToShare = await getBrochureFile();

      if (fileToShare) {
        const url = URL.createObjectURL(fileToShare);
        const a = document.createElement('a');
        a.href = url;
        a.download = safeName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } else if (brochureUrl) {
        const a = document.createElement('a');
        a.href = brochureUrl;
        a.download = safeName;
        a.target = '_blank';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      }
      setShareSuccessMsg(`PDF file "${safeName}" downloaded! You can now send it directly.`);
    } catch (e) {
      console.error('Download error:', e);
    }
  };

  // Email with client mail application
  const handleSendEmail = () => {
    const subject = encodeURIComponent(`Company Brochure PDF: ${brochureName || ''}`);
    const body = encodeURIComponent(`Hello,\n\nPlease find attached the Company Brochure PDF file: ${brochureName || ''}.\n\n(Note: If sending via Webmail, please attach the downloaded PDF file).\n\nThank you.`);
    window.location.href = `mailto:?subject=${subject}&body=${body}`;
  };

  const isPdf = brochureName?.toLowerCase().endsWith('.pdf') || brochureUrl?.includes('.pdf') || brochureUrl?.startsWith('data:application/pdf');
  const isImage = brochureUrl?.startsWith('data:image/') || /\.(jpg|jpeg|png|webp|gif|svg)$/i.test(brochureUrl);

  return (
    <div style={{ marginBottom: '24px' }}>
      <input
        ref={fileInputRef}
        type="file"
        accept=".pdf,.png,.jpg,.jpeg,.webp,.doc,.docx"
        style={{ display: 'none' }}
        onChange={(e) => {
          if (e.target.files && e.target.files[0]) {
            handleFileUpload(e.target.files[0]);
          }
        }}
      />

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', margin: 0 }}>
          {label}
        </label>
        {brochureUrl && (
          <span style={{ fontSize: '0.75rem', color: '#16a34a', fontWeight: '600' }}>
            Brochure Attached (PDF)
          </span>
        )}
      </div>

      {!brochureUrl ? (
        /* Upload Area */
        <div
          onDragOver={(e) => { e.preventDefault(); setDragActive(true); }}
          onDragLeave={() => setDragActive(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragActive(false);
            if (e.dataTransfer.files && e.dataTransfer.files[0]) {
              handleFileUpload(e.dataTransfer.files[0]);
            }
          }}
          onClick={() => !uploading && fileInputRef.current?.click()}
          style={{
            border: dragActive ? '2px dashed #4338ca' : '2px dashed #cbd5e1',
            borderRadius: '12px',
            padding: '24px 16px',
            backgroundColor: dragActive ? '#eef2ff' : '#f8fafc',
            textAlign: 'center',
            cursor: uploading ? 'not-allowed' : 'pointer',
            transition: 'all 0.2s ease',
          }}
        >
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
            <div style={{ backgroundColor: '#ede9fe', padding: '10px', borderRadius: '50%', color: '#4338ca' }}>
              <FileText size={24} />
            </div>
            <div style={{ fontSize: '0.95rem', fontWeight: '600', color: '#1e293b' }}>
              {uploading ? 'Uploading brochure...' : 'Click to upload Company Brochure (PDF)'}
            </div>
            <div style={{ fontSize: '0.8rem', color: '#64748b' }}>
              Supports PDF, PNG, JPG, DOC (Max 25MB)
            </div>
          </div>
        </div>
      ) : (
        /* Attached Brochure Card with 3-dot Corner Menu */
        <div
          style={{
            border: '1px solid #e2e8f0',
            borderRadius: '12px',
            padding: '16px 18px',
            backgroundColor: '#ffffff',
            boxShadow: '0 2px 6px rgba(0,0,0,0.04)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            position: 'relative'
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '14px', flex: 1, minWidth: 0 }}>
            <div
              style={{
                width: '46px',
                height: '46px',
                borderRadius: '10px',
                backgroundColor: '#eff6ff',
                color: '#2563eb',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0
              }}
            >
              <FileText size={24} />
            </div>
            <div style={{ minWidth: 0, flex: 1 }}>
              <div
                style={{
                  fontSize: '0.92rem',
                  fontWeight: '600',
                  color: '#0f172a',
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis'
                }}
                title={brochureName || 'Company Brochure'}
              >
                {brochureName || 'Company Brochure'}
              </div>
              <div style={{ fontSize: '0.78rem', color: '#64748b', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ color: '#2563eb', fontWeight: '700', fontSize: '0.72rem' }}>PDF DOCUMENT</span>
                <span>•</span>
                <span
                  onClick={() => setShowPreviewModal(true)}
                  style={{ color: '#2563eb', cursor: 'pointer', fontWeight: '600' }}
                >
                  Quick View
                </span>
              </div>
            </div>
          </div>

          {/* 3-DOT MENU BUTTON & DROPDOWN */}
          <div ref={menuRef} style={{ position: 'relative', flexShrink: 0 }}>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setMenuOpen(!menuOpen);
              }}
              style={{
                background: '#f8fafc',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
                width: '36px',
                height: '36px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                color: '#475569',
                transition: 'all 0.15s ease'
              }}
              onMouseOver={(e) => { e.currentTarget.style.backgroundColor = '#f1f5f9'; }}
              onMouseOut={(e) => { e.currentTarget.style.backgroundColor = '#f8fafc'; }}
              title="More options"
            >
              <MoreVertical size={18} />
            </button>

            {menuOpen && (
              <div
                style={{
                  position: 'absolute',
                  top: '42px',
                  right: '0',
                  backgroundColor: '#ffffff',
                  border: '1px solid #e2e8f0',
                  borderRadius: '10px',
                  boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)',
                  minWidth: '175px',
                  zIndex: 50,
                  overflow: 'hidden',
                  padding: '4px'
                }}
              >
                {/* 1. VIEW */}
                <button
                  type="button"
                  onClick={() => {
                    setMenuOpen(false);
                    setShowPreviewModal(true);
                  }}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    border: 'none',
                    background: 'transparent',
                    fontSize: '0.85rem',
                    color: '#1e293b',
                    cursor: 'pointer',
                    borderRadius: '6px',
                    textAlign: 'left'
                  }}
                  onMouseOver={(e) => { e.currentTarget.style.backgroundColor = '#f8fafc'; }}
                  onMouseOut={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
                >
                  <Eye size={16} color="#4338ca" />
                  <span>View PDF</span>
                </button>

                {/* 2. EDIT / REPLACE */}
                <button
                  type="button"
                  onClick={() => {
                    setMenuOpen(false);
                    fileInputRef.current?.click();
                  }}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    border: 'none',
                    background: 'transparent',
                    fontSize: '0.85rem',
                    color: '#1e293b',
                    cursor: 'pointer',
                    borderRadius: '6px',
                    textAlign: 'left'
                  }}
                  onMouseOver={(e) => { e.currentTarget.style.backgroundColor = '#f8fafc'; }}
                  onMouseOut={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
                >
                  <Edit2 size={16} color="#0284c7" />
                  <span>Edit (Replace PDF)</span>
                </button>

                {/* 3. SHARE AS PDF FILE */}
                <button
                  type="button"
                  onClick={handleShareFileDirectly}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    border: 'none',
                    background: 'transparent',
                    fontSize: '0.85rem',
                    color: '#1e293b',
                    cursor: 'pointer',
                    borderRadius: '6px',
                    textAlign: 'left'
                  }}
                  onMouseOver={(e) => { e.currentTarget.style.backgroundColor = '#f8fafc'; }}
                  onMouseOut={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
                >
                  <Share2 size={16} color="#16a34a" />
                  <span>Share (Send as PDF)</span>
                </button>

                <div style={{ height: '1px', backgroundColor: '#f1f5f9', margin: '4px 0' }} />

                {/* 4. DELETE / REMOVE */}
                <button
                  type="button"
                  onClick={() => {
                    setMenuOpen(false);
                    setStoredFile(null);
                    onChange({ url: '', name: '' });
                  }}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    border: 'none',
                    background: 'transparent',
                    fontSize: '0.85rem',
                    color: '#ef4444',
                    cursor: 'pointer',
                    borderRadius: '6px',
                    textAlign: 'left'
                  }}
                  onMouseOver={(e) => { e.currentTarget.style.backgroundColor = '#fef2f2'; }}
                  onMouseOut={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
                >
                  <Trash2 size={16} color="#ef4444" />
                  <span>Remove</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* VIEW PDF MODAL */}
      {showPreviewModal && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(15, 23, 42, 0.75)',
            zIndex: 9999,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '20px'
          }}
          onClick={() => setShowPreviewModal(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              backgroundColor: '#fff',
              borderRadius: '16px',
              maxWidth: '850px',
              width: '100%',
              maxHeight: '90vh',
              display: 'flex',
              flexDirection: 'column',
              boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
              overflow: 'hidden'
            }}
          >
            {/* Header */}
            <div style={{ padding: '16px 20px', borderBottom: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <FileText size={20} color="#2563eb" />
                <h3 style={{ margin: 0, fontSize: '1.05rem', color: '#0f172a', fontWeight: '700' }}>
                  {brochureName || 'Company Brochure Preview'}
                </h3>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <button
                  type="button"
                  onClick={handleDownloadPDF}
                  style={{
                    background: '#f1f5f9',
                    border: 'none',
                    borderRadius: '8px',
                    padding: '8px 12px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    color: '#334155',
                    fontSize: '0.82rem',
                    fontWeight: '600',
                    cursor: 'pointer'
                  }}
                >
                  <Download size={15} /> Download PDF
                </button>
                <button
                  type="button"
                  onClick={() => setShowPreviewModal(false)}
                  style={{
                    background: '#f1f5f9',
                    border: 'none',
                    borderRadius: '50%',
                    width: '32px',
                    height: '32px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                    color: '#64748b'
                  }}
                >
                  <X size={18} />
                </button>
              </div>
            </div>

            {/* Content Preview */}
            <div style={{ padding: '20px', overflowY: 'auto', flex: 1, backgroundColor: '#f8fafc', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {isImage ? (
                <img
                  src={brochureUrl}
                  alt="Brochure Preview"
                  style={{ maxWidth: '100%', maxHeight: '70vh', objectFit: 'contain', borderRadius: '8px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                />
              ) : isPdf ? (
                <iframe
                  src={brochureUrl}
                  title="PDF Preview"
                  style={{ width: '100%', height: '70vh', border: 'none', borderRadius: '8px' }}
                />
              ) : (
                <div style={{ textAlign: 'center', padding: '40px 20px' }}>
                  <FileText size={48} color="#dc2626" style={{ margin: '0 auto 12px auto' }} />
                  <p style={{ margin: 0, fontWeight: '600', color: '#1e293b' }}>{brochureName}</p>
                  <p style={{ margin: '6px 0 16px 0', fontSize: '0.85rem', color: '#64748b' }}>File preview is available via download or open in new tab</p>
                  <button
                    type="button"
                    onClick={handleDownloadPDF}
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: '6px',
                      backgroundColor: '#4338ca',
                      color: '#fff',
                      padding: '8px 16px',
                      borderRadius: '8px',
                      fontSize: '0.85rem',
                      fontWeight: '600',
                      border: 'none',
                      cursor: 'pointer'
                    }}
                  >
                    <Download size={15} /> Download PDF File
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SEND AS PDF FILE MODAL */}
      {showShareModal && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(15, 23, 42, 0.75)',
            zIndex: 9999,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '20px'
          }}
          onClick={() => setShowShareModal(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              backgroundColor: '#fff',
              borderRadius: '16px',
              maxWidth: '480px',
              width: '100%',
              padding: '24px',
              boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)'
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Send size={20} color="#16a34a" />
                <h3 style={{ margin: 0, fontSize: '1.1rem', color: '#0f172a', fontWeight: '700' }}>
                  Send as PDF File
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowShareModal(false)}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#64748b' }}
              >
                <X size={18} />
              </button>
            </div>

            {/* Attached PDF card indicator */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '12px',
                backgroundColor: '#f8fafc',
                border: '1px solid #e2e8f0',
                borderRadius: '10px',
                padding: '12px 14px',
                marginBottom: '18px'
              }}
            >
              <div style={{ width: '38px', height: '38px', borderRadius: '8px', backgroundColor: '#eff6ff', color: '#2563eb', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <FileText size={20} />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: '0.88rem', fontWeight: '600', color: '#0f172a', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {brochureName || 'Company_Brochure.pdf'}
                </div>
                <div style={{ fontSize: '0.74rem', color: '#2563eb', fontWeight: '600' }}>
                  Ready to send as PDF file (No Link)
                </div>
              </div>
            </div>

            {shareSuccessMsg && (
              <div style={{ backgroundColor: '#f0fdf4', border: '1px solid #bbf7d0', color: '#15803d', padding: '10px 14px', borderRadius: '8px', fontSize: '0.85rem', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Check size={16} />
                <span>{shareSuccessMsg}</span>
              </div>
            )}

            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginBottom: '18px' }}>
              {/* Option 1: Native Share File */}
              {navigator.canShare && (
                <button
                  type="button"
                  onClick={handleShareFileDirectly}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '8px',
                    width: '100%',
                    padding: '11px 16px',
                    backgroundColor: '#16a34a',
                    color: '#ffffff',
                    border: 'none',
                    borderRadius: '8px',
                    fontSize: '0.9rem',
                    fontWeight: '600',
                    cursor: 'pointer'
                  }}
                >
                  <Share2 size={16} /> Share PDF via WhatsApp / Apps
                </button>
              )}

              {/* Option 2: Download PDF directly to device to send */}
              <button
                type="button"
                onClick={handleDownloadPDF}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '8px',
                  width: '100%',
                  padding: '11px 16px',
                  backgroundColor: '#4338ca',
                  color: '#ffffff',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '0.9rem',
                  fontWeight: '600',
                  cursor: 'pointer'
                }}
              >
                <Download size={16} /> Download PDF to Send as Attachment
              </button>

              {/* Option 3: Send PDF via Email */}
              <button
                type="button"
                onClick={handleSendEmail}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '8px',
                  width: '100%',
                  padding: '11px 16px',
                  backgroundColor: '#f1f5f9',
                  color: '#1e293b',
                  border: '1px solid #cbd5e1',
                  borderRadius: '8px',
                  fontSize: '0.9rem',
                  fontWeight: '600',
                  cursor: 'pointer'
                }}
              >
                <Send size={16} /> Send via Email Client
              </button>
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <button
                type="button"
                onClick={() => setShowShareModal(false)}
                style={{
                  padding: '8px 16px',
                  backgroundColor: '#f1f5f9',
                  color: '#475569',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '0.85rem',
                  fontWeight: '600',
                  cursor: 'pointer'
                }}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BrochureUploader;
