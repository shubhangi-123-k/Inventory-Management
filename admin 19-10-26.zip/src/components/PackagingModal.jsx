import React, { useState } from 'react';
import { Package, Plus, Trash2, X, QrCode, Printer, Box, Check, Copy } from 'lucide-react';
import QRCodeSVG from './QRCodeSVG';

const PackagingModal = ({
  isOpen,
  onClose,
  variant,
  onSavePackaging,
  currency = 'INR'
}) => {
  if (!isOpen || !variant) return null;

  const [packagingList, setPackagingList] = useState(
    Array.isArray(variant.packagings || variant.packaging) && (variant.packagings || variant.packaging).length > 0
      ? [...(variant.packagings || variant.packaging)].map(p => ({
          id: p.id || `pkg-${Date.now()}`,
          package_name: p.package_name || 'Pack of 24',
          quantity_per_pack: p.quantity_per_pack || p.quantity || 24,
          quantity: p.quantity || p.quantity_per_pack || 24,
          barcode: p.package_barcode || p.barcode || `${variant.sku || 'SKU'}-PKG24`,
          package_barcode: p.package_barcode || p.barcode || `${variant.sku || 'SKU'}-PKG24`,
          package_qr_payload: p.package_qr_payload || JSON.stringify({ type: 'PACKAGE', sku: variant.sku, qty: p.quantity || p.quantity_per_pack || 24 }),
          selling_price: p.selling_price || (variant.selling_price ? (parseFloat(variant.selling_price) * 24 * 0.95).toFixed(2) : ''),
          notes: p.notes || ''
        }))
      : [
          {
            id: 'pkg-1',
            package_name: 'Pack of 24',
            quantity_per_pack: 24,
            quantity: 24,
            barcode: `${variant.sku || 'SKU'}-C24`,
            package_barcode: `${variant.sku || 'SKU'}-C24`,
            package_qr_payload: JSON.stringify({ type: 'PACKAGE', sku: variant.sku || 'SKU', qty: 24 }),
            selling_price: variant.selling_price ? (parseFloat(variant.selling_price) * 24 * 0.95).toFixed(2) : '',
            notes: 'Standard shipping carton / outer case'
          }
        ]
  );

  const [activePreviewPkg, setActivePreviewPkg] = useState(null);
  const [copiedCode, setCopiedCode] = useState(null);

  const handleAddPackaging = () => {
    const nextNum = (packagingList.length + 1) * 12;
    const barcodeVal = `${variant.sku || 'SKU'}-C${nextNum}`;
    const newPkg = {
      id: `pkg-${Date.now()}`,
      package_name: `Pack of ${nextNum}`,
      quantity_per_pack: nextNum,
      quantity: nextNum,
      barcode: barcodeVal,
      package_barcode: barcodeVal,
      package_qr_payload: JSON.stringify({ type: 'PACKAGE', sku: variant.sku || 'SKU', qty: nextNum }),
      selling_price: variant.selling_price ? (parseFloat(variant.selling_price) * nextNum * 0.95).toFixed(2) : '',
      notes: ''
    };
    setPackagingList([...packagingList, newPkg]);
  };

  const handleUpdateField = (index, field, value) => {
    const updated = [...packagingList];
    updated[index] = { ...updated[index], [field]: value };
    if (field === 'quantity_per_pack' || field === 'quantity') {
      const q = parseInt(value, 10) || 1;
      updated[index].quantity = q;
      updated[index].quantity_per_pack = q;
      updated[index].package_qr_payload = JSON.stringify({ type: 'PACKAGE', sku: variant.sku, qty: q });
    }
    // Auto-update barcode slug if package name changes and barcode wasn't manually customized
    if (field === 'package_name' && !updated[index].customBarcode) {
      const slug = value.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
      const code = `${variant.sku || 'SKU'}-${slug}`;
      updated[index].barcode = code;
      updated[index].package_barcode = code;
    }
    if (field === 'barcode' || field === 'package_barcode') {
      updated[index].barcode = value;
      updated[index].package_barcode = value;
    }
    setPackagingList(updated);
  };

  const handleRemove = (index) => {
    setPackagingList(packagingList.filter((_, i) => i !== index));
  };

  const handleSave = () => {
    onSavePackaging(packagingList);
    onClose();
  };

  const copyToClipboard = (text) => {
    navigator.clipboard?.writeText(text);
    setCopiedCode(text);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const printLabel = (pkg) => {
    const printWindow = window.open('', '_blank', 'width=600,height=600');
    if (!printWindow) return;
    printWindow.document.write(`
      <html>
        <head>
          <title>Carton QR Label - ${pkg.package_name}</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 24px; text-align: center; }
            .label-box { border: 2px dashed #0f172a; padding: 24px; border-radius: 12px; max-width: 380px; margin: 0 auto; }
            .title { font-size: 1.25rem; font-weight: 800; margin-bottom: 4px; color: #0f172a; }
            .sub { font-size: 0.9rem; color: #64748b; margin-bottom: 16px; }
            .badge { display: inline-block; background: #e0e7ff; color: #4338ca; font-weight: 700; padding: 4px 12px; border-radius: 999px; margin-bottom: 16px; }
            .barcode-val { font-family: monospace; font-size: 1rem; font-weight: 700; letter-spacing: 0.1em; color: #0f172a; margin-top: 10px; }
          </style>
        </head>
        <body>
          <div class="label-box">
            <div class="title">${variant.variant_name || 'Product Variant'}</div>
            <div class="sub">Variant SKU: ${variant.sku || '-'}</div>
            <div class="badge">${pkg.package_name} (Contains ${pkg.quantity_per_pack} Units)</div>
            <div style="display:flex;justify-content:center;margin:12px 0;">
              <svg width="150" height="150" viewBox="0 0 150 150">
                <rect width="150" height="150" fill="#f8fafc" rx="8" />
                <text x="75" y="70" text-anchor="middle" font-size="12" fill="#475569">CARTON QR</text>
                <text x="75" y="90" text-anchor="middle" font-size="11" font-weight="bold" fill="#1e293b">${pkg.barcode}</text>
              </svg>
            </div>
            <div class="barcode-val">${pkg.barcode}</div>
            <div style="margin-top:12px;font-size:0.8rem;color:#64748b;">Distinct Outer Case / Multi-Pack QR</div>
          </div>
          <script>
            window.onload = function() { window.print(); };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(15, 23, 42, 0.7)',
        backdropFilter: 'blur(5px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1200,
        padding: '20px'
      }}
      onClick={onClose}
    >
      <div
        style={{
          backgroundColor: '#ffffff',
          borderRadius: '16px',
          width: '840px',
          maxWidth: '96vw',
          maxHeight: '90vh',
          display: 'flex',
          flexDirection: 'column',
          boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.3)',
          overflow: 'hidden'
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div
          style={{
            padding: '20px 24px',
            borderBottom: '1px solid #e2e8f0',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            backgroundColor: '#f8fafc'
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div
              style={{
                width: '40px',
                height: '40px',
                borderRadius: '10px',
                backgroundColor: '#ede9fe',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#4f46e5'
              }}
            >
              <Box size={22} />
            </div>
            <div>
              <h3 style={{ margin: 0, fontSize: '1.2rem', fontWeight: '700', color: '#0f172a' }}>
                Multi-Pack Packaging Rules
              </h3>
              <p style={{ margin: '2px 0 0 0', fontSize: '0.85rem', color: '#64748b' }}>
                For Variant: <strong style={{ color: '#4338ca' }}>{variant.variant_name || variant.sku}</strong> (Single Unit QR: <code style={{ backgroundColor: '#f1f5f9', padding: '2px 6px', borderRadius: '4px' }}>{variant.barcode || variant.sku}</code>)
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            style={{
              background: '#f1f5f9',
              border: 'none',
              borderRadius: '50%',
              width: '36px',
              height: '36px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              color: '#64748b'
            }}
          >
            <X size={18} />
          </button>
        </div>

        {/* Body content */}
        <div style={{ padding: '24px', overflowY: 'auto', flex: 1 }}>
          <div
            style={{
              padding: '14px 18px',
              backgroundColor: '#eef2ff',
              borderRadius: '10px',
              border: '1px solid #c7d2fe',
              marginBottom: '20px',
              fontSize: '0.85rem',
              color: '#3730a3',
              display: 'flex',
              alignItems: 'center',
              gap: '12px'
            }}
          >
            <Package size={24} style={{ flexShrink: 0 }} />
            <div>
              <strong>Distinct Carton/Case QR Codes:</strong> Each multi-pack packaging (e.g. <em>Pack of 24</em>) receives a dedicated carton barcode/QR label distinct from the individual unit bottle. Warehouse scanners instantly identify the case level rather than scanning 24 single units.
            </div>
          </div>

          {packagingList.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '40px 20px', border: '2px dashed #e2e8f0', borderRadius: '12px' }}>
              <Box size={40} style={{ color: '#94a3b8', margin: '0 auto 12px' }} />
              <p style={{ margin: '0 0 12px 0', color: '#64748b', fontWeight: '500' }}>No multi-pack packaging configurations yet.</p>
              <button
                type="button"
                onClick={handleAddPackaging}
                style={{
                  backgroundColor: '#4338ca',
                  color: 'white',
                  border: 'none',
                  padding: '8px 16px',
                  borderRadius: '6px',
                  fontWeight: '600',
                  fontSize: '0.85rem',
                  cursor: 'pointer',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '6px'
                }}
              >
                <Plus size={16} /> Add First Pack (e.g. Pack of 24)
              </button>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              {packagingList.map((pkg, idx) => (
                <div
                  key={pkg.id || idx}
                  style={{
                    backgroundColor: '#ffffff',
                    border: '1px solid #e2e8f0',
                    borderRadius: '12px',
                    padding: '18px',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.03)',
                    display: 'grid',
                    gridTemplateColumns: '120px 1fr 140px auto',
                    gap: '18px',
                    alignItems: 'center'
                  }}
                >
                  {/* Carton QR Code Preview */}
                  <div style={{ textAlign: 'center' }}>
                    <div
                      style={{
                        padding: '6px',
                        background: '#f8fafc',
                        border: '1px solid #e2e8f0',
                        borderRadius: '8px',
                        display: 'inline-block',
                        boxShadow: '0 1px 3px rgba(0,0,0,0.05)'
                      }}
                    >
                      <QRCodeSVG value={pkg.barcode || `PKG-${idx + 1}`} size={90} title="Carton QR Code" />
                    </div>
                    <div style={{ fontSize: '0.7rem', fontWeight: '700', color: '#4338ca', marginTop: '4px', textTransform: 'uppercase' }}>
                      Carton QR
                    </div>
                  </div>

                  {/* Form fields */}
                  <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 0.8fr 1.2fr', gap: '12px' }}>
                    <div>
                      <label style={{ display: 'block', color: '#64748b', fontSize: '0.72rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '4px' }}>
                        Package Name *
                      </label>
                      <input
                        type="text"
                        value={pkg.package_name || ''}
                        onChange={(e) => handleUpdateField(idx, 'package_name', e.target.value)}
                        placeholder="e.g. Pack of 24"
                        style={{
                          width: '100%',
                          padding: '8px 12px',
                          border: '1px solid #cbd5e1',
                          borderRadius: '6px',
                          fontSize: '0.9rem',
                          fontWeight: '600',
                          outline: 'none'
                        }}
                      />
                    </div>

                    <div>
                      <label style={{ display: 'block', color: '#64748b', fontSize: '0.72rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '4px' }}>
                        Units Per Pack *
                      </label>
                      <input
                        type="number"
                        min="1"
                        value={pkg.quantity_per_pack || ''}
                        onKeyDown={(e) => {
                          if (e.key === '-' || e.key === 'e' || e.key === 'E') {
                            e.preventDefault();
                          }
                        }}
                        onChange={(e) => {
                          const val = e.target.value;
                          if (val !== '' && parseInt(val, 10) < 1) return;
                          handleUpdateField(idx, 'quantity_per_pack', val === '' ? '' : Math.max(1, parseInt(val, 10) || 1));
                        }}
                        placeholder="24"
                        style={{
                          width: '100%',
                          padding: '8px 12px',
                          border: '1px solid #cbd5e1',
                          borderRadius: '6px',
                          fontSize: '0.9rem',
                          fontWeight: '600',
                          outline: 'none'
                        }}
                      />
                    </div>

                    <div>
                      <label style={{ display: 'block', color: '#64748b', fontSize: '0.72rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '4px' }}>
                        Carton Barcode / QR *
                      </label>
                      <div style={{ position: 'relative' }}>
                        <input
                          type="text"
                          value={pkg.barcode || ''}
                          onChange={(e) => {
                            handleUpdateField(idx, 'customBarcode', true);
                            handleUpdateField(idx, 'barcode', e.target.value);
                          }}
                          placeholder="e.g. SKU-PKG24"
                          style={{
                            width: '100%',
                            padding: '8px 30px 8px 10px',
                            border: '1px solid #cbd5e1',
                            borderRadius: '6px',
                            fontSize: '0.85rem',
                            fontFamily: 'monospace',
                            outline: 'none'
                          }}
                        />
                        <button
                          type="button"
                          onClick={() => copyToClipboard(pkg.barcode)}
                          title="Copy Barcode"
                          style={{
                            position: 'absolute',
                            right: '6px',
                            top: '50%',
                            transform: 'translateY(-50%)',
                            background: 'none',
                            border: 'none',
                            cursor: 'pointer',
                            color: copiedCode === pkg.barcode ? '#10b981' : '#64748b'
                          }}
                        >
                          {copiedCode === pkg.barcode ? <Check size={14} /> : <Copy size={14} />}
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Pack Price */}
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.72rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '4px' }}>
                      Pack Price ({currency})
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={pkg.selling_price || ''}
                      onKeyDown={(e) => {
                        if (e.key === '-' || e.key === 'e' || e.key === 'E') {
                          e.preventDefault();
                        }
                      }}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (val !== '' && parseFloat(val) < 0) return;
                        handleUpdateField(idx, 'selling_price', val);
                      }}
                      onBlur={(e) => {
                        if (parseFloat(e.target.value) < 0) {
                          handleUpdateField(idx, 'selling_price', '0.00');
                        }
                      }}
                      placeholder="0.00"
                      style={{
                        width: '100%',
                        padding: '8px 12px',
                        border: '1px solid #cbd5e1',
                        borderRadius: '6px',
                        fontSize: '0.9rem',
                        fontWeight: '600',
                        outline: 'none'
                      }}
                    />
                    <div style={{ fontSize: '0.7rem', color: '#94a3b8', marginTop: '2px' }}>
                      {pkg.quantity_per_pack ? `≈ ${currency} ${((Math.max(0, parseFloat(pkg.selling_price) || 0)) / (pkg.quantity_per_pack || 1)).toFixed(2)}/unit` : ''}
                    </div>
                  </div>

                  {/* Actions */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    <button
                      type="button"
                      onClick={() => printLabel(pkg)}
                      style={{
                        backgroundColor: '#f1f5f9',
                        color: '#334155',
                        border: '1px solid #cbd5e1',
                        padding: '6px 12px',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px',
                        fontSize: '0.8rem',
                        fontWeight: '600'
                      }}
                    >
                      <Printer size={14} /> Print
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRemove(idx)}
                      style={{
                        backgroundColor: '#fee2e2',
                        color: '#ef4444',
                        border: 'none',
                        padding: '6px 12px',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px',
                        fontSize: '0.8rem',
                        fontWeight: '600'
                      }}
                    >
                      <Trash2 size={14} /> Remove
                    </button>
                  </div>
                </div>
              ))}

              <div>
                <button
                  type="button"
                  onClick={handleAddPackaging}
                  style={{
                    backgroundColor: '#f8fafc',
                    color: '#4338ca',
                    border: '1px dashed #c7d2fe',
                    padding: '10px 18px',
                    borderRadius: '8px',
                    cursor: 'pointer',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '6px',
                    fontSize: '0.88rem',
                    fontWeight: '600'
                  }}
                >
                  <Plus size={16} /> Add Another Packaging Rule
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div
          style={{
            padding: '16px 24px',
            borderTop: '1px solid #e2e8f0',
            backgroundColor: '#f8fafc',
            display: 'flex',
            justifyContent: 'flex-end',
            gap: '12px'
          }}
        >
          <button
            type="button"
            onClick={onClose}
            style={{
              padding: '9px 18px',
              border: '1px solid #cbd5e1',
              borderRadius: '8px',
              backgroundColor: '#ffffff',
              color: '#475569',
              fontWeight: '600',
              cursor: 'pointer'
            }}
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            style={{
              padding: '9px 24px',
              border: 'none',
              borderRadius: '8px',
              backgroundColor: '#4338ca',
              color: '#ffffff',
              fontWeight: '600',
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px'
            }}
          >
            <Check size={16} /> Save Packaging Rules ({packagingList.length})
          </button>
        </div>
      </div>
    </div>
  );
};

export default PackagingModal;
