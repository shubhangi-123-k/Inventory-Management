import { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import LogoutModal from './LogoutModal';
import { 
  Settings as SettingsIcon, 
  Users as UsersIcon, 
  LayoutDashboard, 
  Package, 
  LogOut, 
  Tags, 
  Home, 
  Globe, 
  Shield, 
  Folder, 
  FileText, 
  Briefcase, 
  ShoppingCart, 
  Users, 
  Sparkles 
} from 'lucide-react';

const Sidebar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [showLogoutModal, setShowLogoutModal] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);

  const confirmLogout = async () => {
    try {
      setLoggingOut(true);
      await logout();
      navigate('/login');
    } catch (e) {
      console.error('Logout error:', e);
      navigate('/login');
    } finally {
      setLoggingOut(false);
      setShowLogoutModal(false);
    }
  };

  const userInitial = (user?.name || user?.username || 'A')[0].toUpperCase();
  const displayName = user?.name || user?.username || 'Admin User';
  const roleLabel = user?.role === 'SUPER_ADMIN' ? 'Super Admin' : user?.role || 'Admin';

  return (
    <>
      <aside className="sidebar">
        <div className="sidebar-header">
          <Package color="var(--primary)" size={28} />
          <span>Inventory OS</span>
        </div>

        <nav className="sidebar-nav">
          <NavLink
            to="/"
            className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
            end
          >
            <LayoutDashboard size={20} />
            <span>Dashboard</span>
          </NavLink>
          <NavLink
            to="/products"
            className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
          >
            <Package size={20} />
            <span>Elements</span>
          </NavLink>
          <NavLink
            to="/groups"
            className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
          >
            <Folder size={20} />
            <span>Groups</span>
          </NavLink>
          <NavLink
            to="/companies"
            className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
          >
            <Briefcase size={20} />
            <span>Companies</span>
          </NavLink>
          <NavLink
            to="/brands"
            className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
          >
            <Tags size={20} />
            <span>Brands</span>
          </NavLink>
          <NavLink
            to="/occasions"
            className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
          >
            <Sparkles size={20} />
            <span>Occasions</span>
          </NavLink>
          <NavLink
            to="/purchases"
            className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
          >
            <FileText size={20} />
            <span>Purchases</span>
          </NavLink>
          <NavLink
            to="/sales"
            className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
          >
            <ShoppingCart size={20} />
            <span>Sales</span>
          </NavLink>
          <NavLink
            to="/customers"
            className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
          >
            <Users size={20} />
            <span>Customers</span>
          </NavLink>
          <NavLink
            to="/warehouses"
            className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
          >
            <Home size={20} />
            <span>Warehouses</span>
          </NavLink>
          <NavLink
            to="/countries"
            className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
          >
            <Globe size={20} />
            <span>Countries</span>
          </NavLink>
          <NavLink
            to="/customs"
            className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
          >
            <Shield size={20} />
            <span>Customs/Tariffs</span>
          </NavLink>

          {user?.role === 'SUPER_ADMIN' && (
            <>
              <NavLink to="/users" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
                <UsersIcon size={20} />
                <span>User Management</span>
              </NavLink>
              <NavLink to="/settings" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
                <SettingsIcon size={20} />
                <span>Settings</span>
              </NavLink>
            </>
          )}
        </nav>

        {/* Pinned Sticky Footer with User Profile and Logout */}
        <div className="sidebar-footer">
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '12px' }}>
            <div
              style={{
                width: '34px',
                height: '34px',
                borderRadius: '50%',
                background: 'linear-gradient(135deg, #6366f1 0%, #4338ca 100%)',
                color: '#ffffff',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontWeight: '700',
                fontSize: '0.9rem',
                flexShrink: 0
              }}
            >
              {userInitial}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div
                style={{
                  fontWeight: '600',
                  fontSize: '0.85rem',
                  color: '#f8fafc',
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis'
                }}
                title={displayName}
              >
                {displayName}
              </div>
              <div style={{ fontSize: '0.72rem', color: '#94a3b8' }}>
                {roleLabel}
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setShowLogoutModal(true)}
            style={{
              width: '100%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px',
              padding: '9px 14px',
              backgroundColor: 'rgba(239, 68, 68, 0.12)',
              color: '#f87171',
              border: '1px solid rgba(239, 68, 68, 0.25)',
              borderRadius: '8px',
              fontSize: '0.85rem',
              fontWeight: '600',
              cursor: 'pointer',
              transition: 'all 0.15s ease'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = '#ef4444';
              e.currentTarget.style.color = '#ffffff';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'rgba(239, 68, 68, 0.12)';
              e.currentTarget.style.color = '#f87171';
            }}
          >
            <LogOut size={16} />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      <LogoutModal
        isOpen={showLogoutModal}
        onClose={() => setShowLogoutModal(false)}
        onConfirm={confirmLogout}
        loading={loggingOut}
      />
    </>
  );
};

export default Sidebar;
