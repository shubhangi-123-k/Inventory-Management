import { useState, useRef } from 'react';
import { Upload, X, Loader2, Barcode, Eye, Trash2 } from 'lucide-react';
import api from '../api/axios';

const BarcodeUploader = ({
  barcodeValue = '',
  barcodeImageUrl = '',
  onBarcodeValueChange,
  onBarcodeImageChange,
  label = 'Barcode / UPC (Universal Product Code)',
  disabled = false
}) => {
  const [uploading, setUploading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const fileInputRef = useRef(null);

  const handleUploadFile = async (file) => {
    if (!file) return;
    setErrorMsg('');

    if (!file.type.startsWith('image/')) {
      setErrorMsg('Please select a valid image file (PNG, JPEG, WEBP, GIF, SVG)');
      return;
    }

    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('image', file);
      formData.append('folder', 'barcodes');

      const res = await api.post('/upload/image', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });

      if (res.data?.url) {
        onBarcodeImageChange(res.data.url);
      }
    } catch (err) {
      console.error('Failed to upload barcode image:', err);
      setErrorMsg(err.response?.data?.message || err.message || 'Failed to upload barcode image');
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleRemoveImage = () => {
    onBarcodeImageChange('');
  };

  return (
    <div style={{ marginBottom: '20px' }}>
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        style={{ display: 'none' }}
        onChange={(e) => {
          if (e.target.files && e.target.files[0]) {
            handleUploadFile(e.target.files[0]);
          }
        }}
        disabled={disabled}
      />

      <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
        {label}
      </label>

      {/* Barcode Number Input */}
      <div style={{ display: 'flex', gap: '10px', alignItems: 'center', marginBottom: '8px' }}>
        <div style={{ position: 'relative', flex: 1 }}>
          <div style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', display: 'flex', alignItems: 'center' }}>
            <Barcode size={18} />
          </div>
          <input
            type="text"
            placeholder="e.g. 8901030384591"
            value={barcodeValue || ''}
            onChange={(e) => onBarcodeValueChange(e.target.value)}
            disabled={disabled}
            style={{
              width: '100%',
              padding: '10px 14px 10px 38px',
              border: '1px solid #cbd5e1',
              borderRadius: '8px',
              backgroundColor: disabled ? '#f1f5f9' : '#f8fafc',
              color: '#1e293b',
              outline: 'none',
              fontSize: '0.9rem'
            }}
          />
        </div>

        {/* Upload Button */}
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          disabled={disabled || uploading}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            padding: '10px 16px',
            backgroundColor: '#4338ca',
            color: 'white',
            border: 'none',
            borderRadius: '8px',
            fontSize: '0.85rem',
            fontWeight: '600',
            cursor: disabled || uploading ? 'not-allowed' : 'pointer',
            boxShadow: '0 2px 4px rgba(67, 56, 202, 0.2)',
            whiteSpace: 'nowrap'
          }}
        >
          {uploading ? (
            <>
              <Loader2 size={16} className="animate-spin" /> Uploading...
            </>
          ) : (
            <>
              <Upload size={16} /> Upload Barcode
            </>
          )}
        </button>
      </div>

      {errorMsg && (
        <div style={{ color: '#ef4444', fontSize: '0.8rem', marginTop: '4px', marginBottom: '8px' }}>
          {errorMsg}
        </div>
      )}

      {/* Barcode Image Preview Thumbnail */}
      {barcodeImageUrl && (
        <div
          style={{
            marginTop: '8px',
            display: 'inline-flex',
            alignItems: 'center',
            gap: '12px',
            padding: '8px 14px',
            backgroundColor: '#f8fafc',
            border: '1px solid #e2e8f0',
            borderRadius: '10px'
          }}
        >
          <div
            onClick={() => setShowPreviewModal(true)}
            style={{
              position: 'relative',
              width: '64px',
              height: '36px',
              backgroundColor: 'white',
              borderRadius: '6px',
              border: '1px solid #cbd5e1',
              overflow: 'hidden',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
            title="Click to zoom barcode"
          >
            <img
              src={barcodeImageUrl}
              alt="Barcode"
              style={{ width: '100%', height: '100%', objectFit: 'contain' }}
            />
          </div>

          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <span style={{ fontSize: '0.8rem', fontWeight: '600', color: '#1e293b' }}>
              Barcode Image Attached
            </span>
            <span style={{ fontSize: '0.7rem', color: '#64748b' }}>
              Stored in cloud storage
            </span>
          </div>

          <div style={{ display: 'flex', gap: '6px', marginLeft: '8px' }}>
            <button
              type="button"
              onClick={() => setShowPreviewModal(true)}
              style={{
                background: '#ede9fe',
                border: 'none',
                color: '#4338ca',
                borderRadius: '6px',
                padding: '6px 8px',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                fontSize: '0.75rem',
                gap: '4px'
              }}
              title="View full barcode"
            >
              <Eye size={14} /> View
            </button>
            {!disabled && (
              <button
                type="button"
                onClick={handleRemoveImage}
                style={{
                  background: '#fee2e2',
                  border: 'none',
                  color: '#ef4444',
                  borderRadius: '6px',
                  padding: '6px 8px',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  fontSize: '0.75rem',
                  gap: '4px'
                }}
                title="Remove barcode image"
              >
                <Trash2 size={14} /> Remove
              </button>
            )}
          </div>
        </div>
      )}

      {/* Lightbox / Zoom Modal for Barcode Preview */}
      {showPreviewModal && (
        <div
          onClick={() => setShowPreviewModal(false)}
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(15, 23, 42, 0.75)',
            backdropFilter: 'blur(4px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 1300,
            padding: '20px'
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              backgroundColor: 'white',
              borderRadius: '16px',
              padding: '24px',
              maxWidth: '500px',
              width: '90%',
              boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
              position: 'relative',
              textAlign: 'center'
            }}
          >
            <button
              type="button"
              onClick={() => setShowPreviewModal(false)}
              style={{
                position: 'absolute',
                top: '16px',
                right: '16px',
                background: '#f1f5f9',
                border: 'none',
                borderRadius: '50%',
                width: '32px',
                height: '32px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                color: '#64748b'
              }}
            >
              <X size={18} />
            </button>
            <h4 style={{ margin: '0 0 16px 0', fontSize: '1.1rem', color: '#0f172a' }}>
              Barcode / UPC Preview
            </h4>
            <div style={{ backgroundColor: '#f8fafc', padding: '16px', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
              <img
                src={barcodeImageUrl}
                alt="Barcode Preview"
                style={{ maxWidth: '100%', maxHeight: '300px', objectFit: 'contain', display: 'block', margin: '0 auto' }}
              />
            </div>
            {barcodeValue && (
              <p style={{ marginTop: '14px', marginBottom: 0, fontSize: '0.95rem', fontWeight: '600', color: '#334155' }}>
                Code: {barcodeValue}
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default BarcodeUploader;
