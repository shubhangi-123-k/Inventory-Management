import { useState, useRef, useEffect } from 'react';
import { Outlet, useNavigate, Link } from 'react-router-dom';
import Sidebar from './Sidebar';
import LogoutModal from './LogoutModal';
import { useAuth } from '../context/AuthContext';
import { LogOut, ChevronDown, User, Shield, Settings, Users } from 'lucide-react';

const Layout = () => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [showLogoutModal, setShowLogoutModal] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);

  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const dropdownRef = useRef(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const confirmLogout = async () => {
    try {
      setLoggingOut(true);
      await logout();
      navigate('/login');
    } catch (e) {
      console.error('Logout error:', e);
      navigate('/login');
    } finally {
      setLoggingOut(false);
      setShowLogoutModal(false);
      setIsDropdownOpen(false);
    }
  };

  const userInitial = (user?.name || user?.username || 'A')[0].toUpperCase();
  const displayName = user?.name || user?.username || 'Admin User';
  const displayEmail = user?.email || 'admin@inventory.com';
  const roleLabel = user?.role === 'SUPER_ADMIN' ? 'Super Admin' : user?.role || 'Admin';

  return (
    <div className="app-container">
      <Sidebar />
      <div className="main-content">
        <header
          className="topbar"
          style={{
            display: 'flex',
            justifyContent: 'flex-end',
            alignItems: 'center',
            position: 'relative',
            zIndex: 40
          }}
        >
          {/* Right: Actions & User Profile */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
            {/* Profile Dropdown Trigger */}
            <div style={{ position: 'relative' }} ref={dropdownRef}>
              <button
                type="button"
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  background: isDropdownOpen ? '#f1f5f9' : 'transparent',
                  border: '1px solid transparent',
                  borderRadius: '10px',
                  padding: '5px 8px',
                  cursor: 'pointer',
                  transition: 'background-color 0.15s'
                }}
                onMouseEnter={(e) => {
                  if (!isDropdownOpen) e.currentTarget.style.backgroundColor = '#f8fafc';
                }}
                onMouseLeave={(e) => {
                  if (!isDropdownOpen) e.currentTarget.style.backgroundColor = 'transparent';
                }}
              >
                {/* Avatar Initial Circle */}
                <div
                  style={{
                    width: '36px',
                    height: '36px',
                    borderRadius: '50%',
                    background: 'linear-gradient(135deg, #6366f1 0%, #4338ca 100%)',
                    color: '#ffffff',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontWeight: '700',
                    fontSize: '0.95rem',
                    boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
                  }}
                >
                  {userInitial}
                </div>

                {/* Name & Role Text */}
                <div style={{ textAlign: 'left', display: 'flex', flexDirection: 'column' }}>
                  <span style={{ fontWeight: '600', fontSize: '0.88rem', color: '#0f172a', lineHeight: '1.2' }}>
                    {displayName}
                  </span>
                  <span style={{ fontSize: '0.72rem', color: '#64748b' }}>
                    {roleLabel}
                  </span>
                </div>

                <ChevronDown
                  size={16}
                  style={{
                    color: '#64748b',
                    transform: isDropdownOpen ? 'rotate(180deg)' : 'rotate(0deg)',
                    transition: 'transform 0.15s ease'
                  }}
                />
              </button>

              {/* Profile Dropdown Menu */}
              {isDropdownOpen && (
                <div
                  style={{
                    position: 'absolute',
                    top: 'calc(100% + 8px)',
                    right: 0,
                    width: '240px',
                    backgroundColor: '#ffffff',
                    borderRadius: '12px',
                    boxShadow: '0 10px 25px -5px rgba(0,0,0,0.1), 0 8px 10px -6px rgba(0,0,0,0.06)',
                    border: '1px solid #e2e8f0',
                    overflow: 'hidden',
                    animation: 'fadeIn 0.15s ease'
                  }}
                >
                  {/* User summary */}
                  <div style={{ padding: '14px 16px', borderBottom: '1px solid #f1f5f9', backgroundColor: '#fafafa' }}>
                    <div style={{ fontWeight: '700', color: '#0f172a', fontSize: '0.92rem' }}>
                      {displayName}
                    </div>
                    <div style={{ fontSize: '0.78rem', color: '#64748b', marginTop: '2px', wordBreak: 'break-all' }}>
                      {displayEmail}
                    </div>
                    <div style={{ marginTop: '8px' }}>
                      <span
                        style={{
                          fontSize: '0.7rem',
                          fontWeight: '700',
                          padding: '2px 8px',
                          borderRadius: '6px',
                          backgroundColor: user?.role === 'SUPER_ADMIN' ? '#ede9fe' : '#e0e7ff',
                          color: user?.role === 'SUPER_ADMIN' ? '#6d28d9' : '#3730a3'
                        }}
                      >
                        {roleLabel}
                      </span>
                    </div>
                  </div>

                  {/* Navigation Links (If Super Admin) */}
                  {user?.role === 'SUPER_ADMIN' && (
                    <div style={{ padding: '6px 0', borderBottom: '1px solid #f1f5f9' }}>
                      <Link
                        to="/users"
                        onClick={() => setIsDropdownOpen(false)}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '10px',
                          padding: '9px 16px',
                          color: '#334155',
                          textDecoration: 'none',
                          fontSize: '0.86rem',
                          fontWeight: '500',
                          transition: 'background-color 0.15s'
                        }}
                        onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#f8fafc')}
                        onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
                      >
                        <Users size={16} color="#6366f1" />
                        <span>User Management</span>
                      </Link>

                      <Link
                        to="/settings"
                        onClick={() => setIsDropdownOpen(false)}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '10px',
                          padding: '9px 16px',
                          color: '#334155',
                          textDecoration: 'none',
                          fontSize: '0.86rem',
                          fontWeight: '500',
                          transition: 'background-color 0.15s'
                        }}
                        onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#f8fafc')}
                        onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
                      >
                        <Settings size={16} color="#6366f1" />
                        <span>Settings</span>
                      </Link>
                    </div>
                  )}

                  {/* Logout Item */}
                  <div style={{ padding: '6px' }}>
                    <button
                      type="button"
                      onClick={() => {
                        setIsDropdownOpen(false);
                        setShowLogoutModal(true);
                      }}
                      style={{
                        width: '100%',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '10px',
                        padding: '10px 12px',
                        backgroundColor: 'transparent',
                        border: 'none',
                        borderRadius: '8px',
                        color: '#ef4444',
                        fontWeight: '600',
                        fontSize: '0.86rem',
                        cursor: 'pointer',
                        textAlign: 'left',
                        transition: 'background-color 0.15s'
                      }}
                      onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#fee2e2')}
                      onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
                    >
                      <LogOut size={16} />
                      <span>Log Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </header>

        <main className="page-content">
          <Outlet />
        </main>
      </div>

      <LogoutModal
        isOpen={showLogoutModal}
        onClose={() => setShowLogoutModal(false)}
        onConfirm={confirmLogout}
        loading={loggingOut}
      />
    </div>
  );
};

export default Layout;
