import axios from 'axios';

let rawBaseURL = import.meta.env.VITE_API_URL || '/api';
if (rawBaseURL.endsWith('/') && rawBaseURL.length > 1) {
  rawBaseURL = rawBaseURL.slice(0, -1);
}
if (!rawBaseURL.endsWith('/api')) {
  rawBaseURL = `${rawBaseURL}/api`;
}

const api = axios.create({
  baseURL: rawBaseURL,
});

const getLoginUrl = () => {
  const base = import.meta.env.BASE_URL || '/';
  return base.endsWith('/') ? `${base}login` : `${base}/login`;
};

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  // If a mock token was previously stored, purge it immediately
  if (token && token.startsWith('mock-')) {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    if (!window.location.pathname.endsWith('/login')) {
      window.location.href = getLoginUrl();
    }
    return config;
  }
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response) {
      console.error(`[API Error ${error.response.status}] ${error.config?.method?.toUpperCase()} ${error.config?.url}:`, JSON.stringify(error.response.data));
    }
    const isTokenError = 
      error.response && 
      (error.response.status === 401 || 
       (error.response.status === 403 && (
         typeof error.response.data?.error === 'string' && 
         error.response.data.error.toLowerCase().includes('token')
       )));

    if (isTokenError && !window.location.pathname.endsWith('/login')) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = getLoginUrl();
    }
    return Promise.reject(error);
  }
);

export default api;
