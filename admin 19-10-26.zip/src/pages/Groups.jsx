import { useState, useEffect } from 'react';
import api from '../api/axios';
import { Plus, Edit2, Trash2, Eye, X, Image as ImageIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import SearchAutocomplete from '../components/SearchAutocomplete';
import PhotoUploader from '../components/PhotoUploader';
import { extractGroupMedia } from '../utils/mediaUtils';

const Groups = () => {
  const navigate = useNavigate();
  const [groups, setGroups] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  // Form State
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [images, setImages] = useState([]);

  const fetchGroups = async () => {
    try {
      setLoading(true);
      const response = await api.get('/admin/groups');
      const raw = response.data?.data || response.data || [];
      setGroups(Array.isArray(raw) ? raw.map(extractGroupMedia) : []);
      setLoading(false);
    } catch (error) {
      console.error("Groups fetch error", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGroups();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const payload = { 
        name, 
        description,
        images,
        image_url: images.length > 0 ? images[0] : null,
        image: images.length > 0 ? images[0] : null
      };
      if (editId) {
        await api.put(`/admin/groups/${editId}`, payload);
      } else {
        await api.post('/admin/groups', payload);
      }
      resetForm();
      fetchGroups();
    } catch (error) {
      console.error("Failed to save group", error);
      alert(error.response?.data?.error || "Failed to save group");
    }
  };

  const handleEdit = (group) => {
    const norm = extractGroupMedia(group);
    setEditId(norm.id);
    setName(norm.name || '');
    setDescription(norm.description || '');
    setImages(norm.images || []);
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this group?')) {
      try {
        await api.delete(`/admin/groups/${id}`);
        fetchGroups();
      } catch (error) {
        alert(error.response?.data?.error || "Failed to delete group");
      }
    }
  };

  const handleStatusToggle = async (group) => {
    try {
      const newStatus = group.status === 'Active' ? 'Inactive' : 'Active';
      await api.put(`/admin/groups/${group.id}`, {
        name: group.name,
        description: group.description,
        status: newStatus
      });
      fetchGroups();
    } catch (error) {
      console.error("Failed to update status", error);
      alert("Failed to update status");
    }
  };

  const resetForm = () => {
    setEditId(null);
    setName('');
    setDescription('');
    setImages([]);
    setShowForm(false);
  };

  const filteredGroups = groups.filter(g =>
    g.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
        <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>Groups</h1>
        <button className="btn btn-primary" style={{ width: 'auto' }} onClick={() => showForm ? resetForm() : setShowForm(true)}>
          <Plus size={18} /> {showForm ? 'Cancel' : 'Add Group'}
        </button>
      </div>

      {showForm && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
          backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000
        }}>
          <div style={{
            background: 'var(--surface)', padding: '24px', borderRadius: '12px', width: '90%', maxWidth: '500px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h2 style={{ fontSize: '1.25rem', fontWeight: '600', margin: 0 }}>
                {editId ? 'Edit Group' : 'Create New Group'}
              </h2>
              <button onClick={resetForm} style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer', color: 'var(--text-muted)' }}>&times;</button>
            </div>
            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div className="form-group" style={{ marginBottom: 0 }}>
                <label className="form-label">Group Name <span style={{ color: 'red' }}>*</span></label>
                <input
                  type="text"
                  className="form-control"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
              <div className="form-group" style={{ marginBottom: 0 }}>
                <label className="form-label">Description</label>
                <input
                  type="text"
                  className="form-control"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </div>
              <div className="form-group" style={{ marginBottom: 0 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                  <label className="form-label" style={{ margin: 0 }}>Group Images (Optional)</label>
                  <span style={{ fontSize: '0.8rem', color: '#64748b' }}>{images.length} photo(s) selected</span>
                </div>
                <PhotoUploader images={images} onChange={setImages} maxFiles={10} compact={true} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px', marginTop: '8px' }}>
                <button type="button" className="btn btn-secondary" onClick={resetForm}>Cancel</button>
                <button type="submit" className="btn btn-primary">{editId ? 'Update' : 'Save'}</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div style={{ marginBottom: '16px' }}>
        <SearchAutocomplete
          placeholder="Search groups..."
          className="form-control"
          style={{ maxWidth: '300px' }}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Image</th>
              <th>Group Code</th>
              <th>Name</th>
              <th>Description</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan="7" style={{ textAlign: 'center' }}>Loading groups...</td></tr>
            ) : filteredGroups.length > 0 ? (
              filteredGroups.map((group) => (
                <tr key={group.id}>
                  <td>#{group.id}</td>
                  <td>
                    {((group.images && group.images.length > 0) || group.image_url || group.image) ? (
                      <div style={{ position: 'relative', display: 'inline-block' }}>
                        <img 
                          src={(group.images && group.images[0]) || group.image_url || group.image} 
                          alt={group.name} 
                          style={{ width: '38px', height: '38px', objectFit: 'cover', borderRadius: '6px', border: '1px solid #e2e8f0' }} 
                        />
                        {group.images && group.images.length > 1 && (
                          <span style={{
                            position: 'absolute',
                            bottom: '-4px',
                            right: '-4px',
                            backgroundColor: '#3b82f6',
                            color: '#fff',
                            fontSize: '0.62rem',
                            fontWeight: '700',
                            borderRadius: '8px',
                            padding: '1px 4px',
                            boxShadow: '0 1px 3px rgba(0,0,0,0.3)',
                            lineHeight: 1
                          }}>
                            +{group.images.length - 1}
                          </span>
                        )}
                      </div>
                    ) : (
                      <div style={{ width: '38px', height: '38px', borderRadius: '6px', backgroundColor: '#f1f5f9', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94a3b8' }}>
                        <ImageIcon size={18} />
                      </div>
                    )}
                  </td>
                  <td style={{ fontWeight: '600', color: '#64748b' }}>{group.group_code || '-'}</td>
                  <td style={{ fontWeight: '500' }}>{group.name}</td>
                  <td style={{ color: 'var(--text-muted)' }}>{group.description || '-'}</td>
                  <td>
                    <div
                      onClick={() => handleStatusToggle(group)}
                      style={{
                        cursor: 'pointer',
                        display: 'inline-flex',
                        alignItems: 'center',
                        justifyContent: group.status === 'Active' ? 'flex-end' : 'flex-start',
                        width: '40px',
                        height: '22px',
                        background: group.status === 'Active' ? 'var(--primary)' : '#cbd5e1',
                        borderRadius: '11px',
                        padding: '2px',
                        transition: 'background 0.2s',
                        marginRight: '8px',
                        verticalAlign: 'middle'
                      }}
                      title="Toggle Status"
                    >
                      <div style={{
                        width: '18px',
                        height: '18px',
                        background: '#fff',
                        borderRadius: '50%',
                        boxShadow: '0 1px 2px rgba(0,0,0,0.2)'
                      }} />
                    </div>
                    <span style={{ verticalAlign: 'middle', fontSize: '0.875rem', color: group.status === 'Active' ? 'var(--primary)' : 'var(--text-muted)' }}>
                      {group.status || 'Active'}
                    </span>
                  </td>
                  <td>
                    <button onClick={() => navigate(`/groups/${group.id}`)} style={{ background: 'none', border: 'none', cursor: 'pointer', marginRight: '8px' }} title="View"><Eye size={16} color="#3498db" /></button>
                    <button onClick={() => handleEdit(group)} style={{ background: 'none', border: 'none', cursor: 'pointer', marginRight: '8px' }} title="Edit"><Edit2 size={16} color="var(--primary)" /></button>
                    <button onClick={() => handleDelete(group.id)} style={{ background: 'none', border: 'none', cursor: 'pointer' }} title="Delete"><Trash2 size={16} color="var(--danger)" /></button>
                  </td>
                </tr>
              ))
            ) : (
              <tr><td colSpan="6" style={{ textAlign: 'center' }}>No groups found.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Groups;
