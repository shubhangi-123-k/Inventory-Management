import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../api/axios';
import { ArrowLeft, Save, Plus, Trash2, FileDown, FileSpreadsheet, X, Upload, Loader2, Image as ImageIcon, Layers, Box, QrCode, Sparkles, CheckCircle2, Building2, Gift } from 'lucide-react';
import AttributeBuilder from '../components/AttributeBuilder';
import PhotoUploader from '../components/PhotoUploader';
import AddOccasionModal from '../components/AddOccasionModal';
import BarcodeUploader from '../components/BarcodeUploader';
import VideoUploader from '../components/VideoUploader';
import BrochureUploader from '../components/BrochureUploader';
import OccasionSelector from '../components/OccasionSelector';
import ProductSchemesManager from '../components/ProductSchemesManager';
import VariantMatrixBuilder from '../components/VariantMatrixBuilder';
import PackagingModal from '../components/PackagingModal';
import QRCodeSVG from '../components/QRCodeSVG';
import { downloadProductBrochurePDF, downloadProductDetailsExcel } from '../utils/productExport';
import { extractCompanyMedia } from '../utils/mediaUtils';

const ProductDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [activeTab, setActiveTab] = useState('basic');
  const [loading, setLoading] = useState(true);
  const [product, setProduct] = useState(null);
  const [productAliases, setProductAliases] = useState(['']);
  const [attributes, setAttributes] = useState([]);
  const [hasVariants, setHasVariants] = useState('No');
  const [variantAttributes, setVariantAttributes] = useState([]);
  const [productVariants, setProductVariants] = useState([]);

  // Occasion States
  const [isOccasionBased, setIsOccasionBased] = useState('No');
  const [selectedOccasionType, setSelectedOccasionType] = useState('');
  const [selectedOccasionIds, setSelectedOccasionIds] = useState([]);
  const [occasionsList, setOccasionsList] = useState([]);
  const [occasionTypes, setOccasionTypes] = useState(['Festival', 'Season', 'Event', 'Other']);
  const [showAddOccasionModal, setShowAddOccasionModal] = useState(false);

  // Measurement Units
  const [dimensionUnit, setDimensionUnit] = useState('cm');
  const [customDimensionUnit, setCustomDimensionUnit] = useState('');
  const [volumeUnit, setVolumeUnit] = useState('ml');
  const [customVolumeUnit, setCustomVolumeUnit] = useState('');
  const [weightUnit, setWeightUnit] = useState('g');
  const [customWeightUnit, setCustomWeightUnit] = useState('');

  const handleAddAlias = () => {
    setProductAliases([...productAliases, '']);
  };

  const handleAliasChange = (index, value) => {
    const newAliases = [...productAliases];
    newAliases[index] = value;
    setProductAliases(newAliases);
    setProduct(prev => ({ ...prev, product_alias: newAliases.filter(a => a.trim() !== '').join(',') }));
  };

  const handleRemoveAlias = (index) => {
    const newAliases = productAliases.filter((_, i) => i !== index);
    setProductAliases(newAliases);
    setProduct(prev => ({ ...prev, product_alias: newAliases.filter(a => a.trim() !== '').join(',') }));
  };

  const [groups, setGroups] = useState([]);
  const [brands, setBrands] = useState([]);
  const [warehouses, setWarehouses] = useState([]);
  const [productTypes] = useState(["Processors", "Graphic Cards", "Memory"]);

  const [pricingMethod, setPricingMethod] = useState('PROFIT_ON_COST');
  const [profitOnCostPercent, setProfitOnCostPercent] = useState('');
  const [discountOnMrpPercent, setDiscountOnMrpPercent] = useState('');
  const [baseSellingPrice, setBaseSellingPrice] = useState('');
  const [discountOnSellingPricePercent, setDiscountOnSellingPricePercent] = useState('');
  const [roundOff, setRoundOff] = useState(false);

  // Auto-calculate selling price based on profit % on cost, discount % on MRP, or offer % on selling price with round off
  useEffect(() => {
    if (!product || pricingMethod === 'MANUAL') return;

    let computed = null;
    if (pricingMethod === 'PROFIT_ON_COST') {
      const cost = parseFloat(product?.purchase_price) || 0;
      const pct = parseFloat(profitOnCostPercent) || 0;
      if (cost > 0 && pct > 0) {
        computed = cost * (1 + (pct / 100));
      }
    } else if (pricingMethod === 'DISCOUNT_ON_MRP') {
      const mrpVal = parseFloat(product?.mrp) || 0;
      const pct = parseFloat(discountOnMrpPercent) || 0;
      if (mrpVal > 0 && pct > 0) {
        computed = mrpVal * (1 - (pct / 100));
      }
    } else if (pricingMethod === 'DISCOUNT_ON_SELLING_PRICE') {
      const baseVal = parseFloat(baseSellingPrice || product?.mrp || product?.selling_price) || 0;
      const pct = parseFloat(discountOnSellingPricePercent) || 0;
      if (baseVal > 0 && pct > 0) {
        computed = baseVal * (1 - (pct / 100));
      }
    }

    if (computed !== null) {
      const finalPrice = roundOff ? Math.round(computed) : parseFloat(computed.toFixed(2));
      setProduct(prev => ({ ...prev, selling_price: finalPrice.toString() }));
    }
  }, [product?.purchase_price, product?.mrp, baseSellingPrice, profitOnCostPercent, discountOnMrpPercent, discountOnSellingPricePercent, roundOff, pricingMethod]);

  // Custom Modal States
  const [showAddGroupModal, setShowAddGroupModal] = useState(false);
  const [modalGroupName, setModalGroupName] = useState('');
  const [modalGroupDesc, setModalGroupDesc] = useState('');
  const [modalGroupImages, setModalGroupImages] = useState([]);

  const [companyName, setCompanyName] = useState('');
  const [companies, setCompanies] = useState([]);
  const [companyBrochure, setCompanyBrochure] = useState({ url: '', name: '' });
  const [companyInheritedMedia, setCompanyInheritedMedia] = useState(null);
  const [companyInheritedSchemes, setCompanyInheritedSchemes] = useState(null);
  const [isInheritingMedia, setIsInheritingMedia] = useState(false);
  const [showAddCompanyModal, setShowAddCompanyModal] = useState(false);
  const [showAddBrandModal, setShowAddBrandModal] = useState(false);
  const [modalCompanyName, setModalCompanyName] = useState('');
  const [modalCompanyDesc, setModalCompanyDesc] = useState('');
  const [modalCompanyScheme, setModalCompanyScheme] = useState('');
  const [modalCompanyOffer, setModalCompanyOffer] = useState('');
  const [modalCompanyMargin, setModalCompanyMargin] = useState('');
  const [modalCompanyDistributor, setModalCompanyDistributor] = useState('');
  const [modalCompanyOfficers, setModalCompanyOfficers] = useState(['']);
  const [modalCompanyBrochures, setModalCompanyBrochures] = useState([]);
  const [modalBrandName, setModalBrandName] = useState('');
  const [modalBrandDesc, setModalBrandDesc] = useState('');
  const [modalBrandScheme, setModalBrandScheme] = useState('');
  const [modalBrandOffer, setModalBrandOffer] = useState('');
  const [modalBrandMargin, setModalBrandMargin] = useState('');
  const [modalBrandDistributor, setModalBrandDistributor] = useState('');
  const [modalBrandOfficer, setModalBrandOfficer] = useState('');

  const fetchOccasions = async () => {
    try {
      const [occRes, typesRes] = await Promise.all([
        api.get('/admin/occasions'),
        api.get('/admin/occasions/types')
      ]);
      setOccasionsList(occRes.data?.data || occRes.data || []);
      if (typesRes.data?.data) {
        setOccasionTypes(typesRes.data.data);
      }
    } catch (err) {
      console.error('Failed to fetch occasions in ProductDetails:', err);
    }
  };

  const fetchData = async () => {
    try {
      setLoading(true);
      fetchOccasions();
      const [prodRes, groupsRes, brandsRes, companiesRes] = await Promise.all([
        api.get(`/admin/products/${id}`),
        api.get('/admin/groups'),
        api.get('/admin/brands'),
        api.get('/admin/companies')
      ]);
      const prod = prodRes.data;
      const cleanDate = (d) => {
        if (!d || d === 'Invalid date' || String(d).trim() === '') return '';
        const parsed = new Date(d);
        return isNaN(parsed.getTime()) ? '' : String(d).trim().split('T')[0];
      };
      setProduct({
        ...prod,
        currency: prod.currency || 'INR',
        seasonal_period_start: cleanDate(prod.seasonal_period_start),
        seasonal_period_end: cleanDate(prod.seasonal_period_end),
        manufacturing_date: cleanDate(prod.manufacturing_date),
        expiry_date: cleanDate(prod.expiry_date),
        best_before_date: cleanDate(prod.best_before_date)
      });
      setIsOccasionBased(prod.is_occasion_based ? 'Yes' : 'No');
      if (prod.occasions && prod.occasions.length > 0) {
        setSelectedOccasionIds(prod.occasions.map(o => o.id));
      } else {
        setSelectedOccasionIds([]);
      }
      if (prod.product_alias) {
        setProductAliases(prod.product_alias.split(',').map(a => a.trim()));
      }
      // Parse unit suffixes if present
      if (prod.length) {
        const parts = prod.length.trim().split(/\s+/);
        if (parts.length > 1) {
          const u = parts.slice(1).join(' ').trim();
          if (['cm', 'mm', 'm', 'in', 'ft'].includes(u.toLowerCase())) {
            setDimensionUnit(u.toLowerCase());
          } else {
            setDimensionUnit('custom');
            setCustomDimensionUnit(u);
          }
        }
      }
      if (prod.volume) {
        const parts = prod.volume.trim().split(/\s+/);
        if (parts.length > 1) {
          const u = parts.slice(1).join(' ').trim();
          if (['ml', 'l', 'fl oz', 'gal'].includes(u.toLowerCase())) {
            setVolumeUnit(u === 'L' ? 'L' : u.toLowerCase());
          } else {
            setVolumeUnit('custom');
            setCustomVolumeUnit(u);
          }
        }
      }
      if (prod.net_weight || prod.gross_weight) {
        const wtStr = prod.net_weight || prod.gross_weight;
        const parts = wtStr.trim().split(/\s+/);
        if (parts.length > 1) {
          const u = parts.slice(1).join(' ').trim();
          if (['g', 'kg', 'mg', 'lb', 'oz'].includes(u.toLowerCase())) {
            setWeightUnit(u.toLowerCase());
          } else {
            setWeightUnit('custom');
            setCustomWeightUnit(u);
          }
        }
      }
      if (prod.attributes) {
        setAttributes(prod.attributes.map(a => ({
          name: a.Attribute ? a.Attribute.name : '',
          value: a.value
        })));
      }

      // Hydrate variants if available on product
      if (prod.has_variants || (Array.isArray(prod.variants) && prod.variants.length > 0) || (Array.isArray(prod.ProductVariants) && prod.ProductVariants.length > 0)) {
        setHasVariants('Yes');
        const vLoadedRaw = (Array.isArray(prod.variants) && prod.variants.length > 0)
          ? prod.variants
          : (Array.isArray(prod.ProductVariants) && prod.ProductVariants.length > 0)
            ? prod.ProductVariants
            : [];

        // Build or hydrate variantAttributes
        if (Array.isArray(prod.variant_attributes) && prod.variant_attributes.length > 0) {
          setVariantAttributes(prod.variant_attributes);
        } else if (vLoadedRaw.length > 0) {
          // Reconstruct attribute keys and values from variants' variant_attributes / combination
          const attrMap = {};
          vLoadedRaw.forEach(v => {
            const attrs = v.variant_attributes || v.combination || {};
            Object.entries(attrs).forEach(([k, val]) => {
              if (!attrMap[k]) attrMap[k] = new Set();
              if (val) attrMap[k].add(String(val));
            });
          });
          const reconstructed = Object.entries(attrMap).map(([name, valSet]) => ({
            name,
            values: Array.from(valSet)
          }));
          if (reconstructed.length > 0) {
            setVariantAttributes(reconstructed);
          }
        }

        const normalizedVariants = vLoadedRaw.map((v, i) => {
          const attrs = v.variant_attributes || v.combination || {};
          const pkgs = Array.isArray(v.packagings) && v.packagings.length > 0
            ? v.packagings
            : (Array.isArray(v.packaging) ? v.packaging : []);

          return {
            id: v.id || `var-${i}`,
            name: v.name || v.variant_name,
            variant_name: v.name || v.variant_name,
            sku: v.sku,
            barcode: v.gtin_ean_upc || v.barcode || `${v.sku}-UNIT`,
            gtin_ean_upc: v.gtin_ean_upc || v.barcode || `${v.sku}-UNIT`,
            selling_price: v.selling_price || prod.selling_price || 0,
            purchase_price: v.purchase_price || prod.purchase_price || 0,
            mrp: v.mrp || prod.mrp || v.selling_price || 0,
            opening_stock: v.opening_stock ?? v.purchase_quantity ?? v.current_stock ?? 0,
            price_extra: v.price_extra || '0.00',
            combination: attrs,
            variant_attributes: attrs,
            packaging: pkgs.map((p, pi) => {
              const qty = p.quantity || p.quantity_per_pack || 24;
              const pCode = p.package_barcode || p.barcode || `${v.sku}-C${qty}`;
              return {
                id: p.id || `pkg-${pi}`,
                package_name: p.package_name || `Pack of ${qty}`,
                quantity_per_pack: qty,
                quantity: qty,
                barcode: pCode,
                package_barcode: pCode,
                package_qr_payload: p.package_qr_payload || JSON.stringify({ type: 'PACKAGE', sku: v.sku, qty }),
                selling_price: p.selling_price || ''
              };
            }),
            packagings: pkgs
          };
        });

        if (normalizedVariants.length > 0) {
          setProductVariants(normalizedVariants);
        }
      } else {
        setHasVariants('No');
      }
      setGroups(groupsRes.data?.data || groupsRes.data || []);
      setBrands(brandsRes.data?.data || brandsRes.data || []);
      setCompanies(companiesRes.data?.data || companiesRes.data || []);

      try {
        const whRes = await api.get('/admin/warehouses');
        setWarehouses(whRes.data?.data || whRes.data?.warehouses || (Array.isArray(whRes.data) ? whRes.data : []));
      } catch (e) {
        console.error("Failed to fetch warehouses:", e);
      }

      // Hydrate brochure if present
      if (prod.company_brochure_url) {
        setCompanyBrochure({
          url: prod.company_brochure_url,
          name: prod.company_brochure_name || 'Product_Brochure.pdf'
        });
      }

      // Auto select company based on product's brand if present
      if (prodRes.data.brand_id) {
        const prodBrand = (brandsRes.data.data || []).find(b => b.id == prodRes.data.brand_id);
        if (prodBrand) {
          const compName = prodBrand.company_name || '';
          setCompanyName(compName);
          const matchedComp = (companiesRes.data?.data || companiesRes.data || []).find(c => c.name === compName || c.company_name === compName);
          if (matchedComp) {
            const fullComp = extractCompanyMedia(matchedComp);
            setCompanyInheritedMedia({
              companyName: compName,
              companyId: matchedComp.id,
              logoUrl: fullComp.logoUrl,
              brochureUrl: fullComp.brochureUrl,
              brochureName: fullComp.brochureName,
              videoUrl: fullComp.videoUrl,
              images: fullComp.images,
              hasMedia: Boolean(fullComp.brochureUrl || fullComp.videoUrl || fullComp.images.length > 0 || fullComp.logoUrl)
            });
            setCompanyInheritedSchemes({
              companyName: compName,
              companyId: matchedComp.id,
              schemes: fullComp.schemes,
              hasSchemes: fullComp.hasSchemes
            });
          }
        }
      }

      setLoading(false);
    } catch (error) {
      console.error("Failed to fetch product details", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [id]);

  const handleAddNewGroup = () => {
    setModalGroupName('');
    setModalGroupDesc('');
    setModalGroupImages([]);
    setShowAddGroupModal(true);
  };

  const submitNewGroup = async (e) => {
    e.preventDefault();
    try {
      const res = await api.post('/admin/groups', {
        name: modalGroupName,
        description: modalGroupDesc,
        status: 'Active',
        images: modalGroupImages,
        image_url: modalGroupImages.length > 0 ? modalGroupImages[0] : null,
        image: modalGroupImages.length > 0 ? modalGroupImages[0] : null
      });
      const newGroup = res.data?.data || res.data;
      setGroups([...groups, newGroup]);
      setProduct({ ...product, group_id: newGroup.id });
      setShowAddGroupModal(false);
      setModalGroupName('');
      setModalGroupDesc('');
      setModalGroupImages([]);
    } catch (err) {
      alert("Failed to add group");
    }
  };



  const handleCompanySelect = async (selectedCompanyName, directCompObj = null) => {
    setCompanyName(selectedCompanyName);
    setProduct(prev => ({ ...prev, brand_id: '' }));

    if (!selectedCompanyName) {
      setCompanyInheritedMedia(null);
      setCompanyInheritedSchemes(null);
      return;
    }

    const matched = directCompObj || companies.find(
      c => (c.name && c.name.toLowerCase() === selectedCompanyName.toLowerCase()) ||
           (c.company_name && c.company_name.toLowerCase() === selectedCompanyName.toLowerCase())
    );

    let fullComp = matched ? extractCompanyMedia(matched) : null;
    setIsInheritingMedia(true);

    if (matched?.id) {
      try {
        const res = await api.get(`/admin/companies/${matched.id}`);
        const fresh = res.data?.data || res.data;
        if (fresh) fullComp = extractCompanyMedia({ ...matched, ...fresh });
      } catch (err) {
        console.warn("Could not fetch fresh company details for auto-fetch in details:", err);
      }
    }
    setIsInheritingMedia(false);

    if (!fullComp) return;

    const compBrochureUrl = fullComp.brochureUrl || fullComp.brochure_url || '';
    const compBrochureName = fullComp.brochureName || fullComp.brochure_name ||
      (compBrochureUrl ? `${fullComp.company_name || fullComp.name || selectedCompanyName}_Brochure.pdf` : '');

    const compVideoUrl = fullComp.videoUrl || fullComp.video_url || '';
    const compImages = fullComp.images || [];
    const compLogoUrl = fullComp.logoUrl || fullComp.image_url || (compImages.length > 0 ? compImages[0] : '');

    const hasAnyMedia = Boolean(compBrochureUrl || compVideoUrl || compImages.length > 0 || compLogoUrl);

    setCompanyInheritedMedia({
      companyName: selectedCompanyName,
      companyId: fullComp.id,
      logoUrl: compLogoUrl,
      brochureUrl: compBrochureUrl,
      brochureName: compBrochureName,
      videoUrl: compVideoUrl,
      images: compImages,
      hasMedia: hasAnyMedia
    });

    if (compBrochureUrl && (!companyBrochure?.url || companyBrochure?.isInherited)) {
      setCompanyBrochure({
        url: compBrochureUrl,
        name: compBrochureName,
        isInherited: true,
        sourceCompany: selectedCompanyName
      });
    }

    if (compVideoUrl && (!product?.video_url || product?.video_url === companyInheritedMedia?.videoUrl)) {
      setProduct(prev => ({ ...prev, video_url: compVideoUrl }));
    }

    // Auto-inherit Schemes & Turnover Targets
    const compSchemes = fullComp.schemes || {
      product_pe_product: fullComp.product_pe_product || '',
      discount_on_product: fullComp.discount_on_product || '',
      product_target_scheme: fullComp.product_target_scheme || '',
      discount_on_bill_amount: fullComp.discount_on_bill_amount || '',
      quarterly_discount_on_turnover: fullComp.quarterly_discount_on_turnover || '',
      yearly_discount_on_turnover: fullComp.yearly_discount_on_turnover || '',
      seasonal_scheme_name: fullComp.seasonal_scheme_name || '',
      seasonal_period_start: fullComp.seasonal_period_start || '',
      seasonal_period_end: fullComp.seasonal_period_end || '',
      seasonal_applicability: fullComp.seasonal_applicability || 'All Products',
      seasonal_frequency: fullComp.seasonal_frequency || 'Yearly'
    };

    const compHasSchemes = Boolean(fullComp.hasSchemes || Object.values(compSchemes).some(v => Boolean(v && String(v).trim())));

    setCompanyInheritedSchemes({
      companyName: selectedCompanyName,
      companyId: fullComp.id,
      schemes: compSchemes,
      hasSchemes: compHasSchemes
    });

    // Auto-match schemes if product currently has no schemes configured
    const isProductSchemesEmpty = !product?.product_pe_product &&
      !product?.discount_on_product &&
      !product?.product_target_scheme &&
      !product?.discount_on_bill_amount &&
      !product?.quarterly_discount_on_turnover &&
      !product?.yearly_discount_on_turnover &&
      !product?.seasonal_scheme_name;

    if (isProductSchemesEmpty && compHasSchemes) {
      setProduct(prev => ({
        ...prev,
        product_pe_product: compSchemes.product_pe_product || prev.product_pe_product || '',
        discount_on_product: compSchemes.discount_on_product || prev.discount_on_product || '',
        product_target_scheme: compSchemes.product_target_scheme || prev.product_target_scheme || '',
        discount_on_bill_amount: compSchemes.discount_on_bill_amount || prev.discount_on_bill_amount || '',
        quarterly_discount_on_turnover: compSchemes.quarterly_discount_on_turnover || prev.quarterly_discount_on_turnover || '',
        yearly_discount_on_turnover: compSchemes.yearly_discount_on_turnover || prev.yearly_discount_on_turnover || '',
        seasonal_scheme_name: compSchemes.seasonal_scheme_name || prev.seasonal_scheme_name || '',
        seasonal_period_start: compSchemes.seasonal_period_start || prev.seasonal_period_start || '',
        seasonal_period_end: compSchemes.seasonal_period_end || prev.seasonal_period_end || '',
        seasonal_applicability: compSchemes.seasonal_applicability || prev.seasonal_applicability || 'All Products',
        seasonal_frequency: compSchemes.seasonal_frequency || prev.seasonal_frequency || 'Yearly'
      }));
    }
  };

  const handleApplyCompanySchemes = () => {
    if (!companyInheritedSchemes?.schemes) return;
    const s = companyInheritedSchemes.schemes;
    setProduct(prev => ({
      ...prev,
      product_pe_product: s.product_pe_product || '',
      discount_on_product: s.discount_on_product || '',
      product_target_scheme: s.product_target_scheme || '',
      discount_on_bill_amount: s.discount_on_bill_amount || '',
      quarterly_discount_on_turnover: s.quarterly_discount_on_turnover || '',
      yearly_discount_on_turnover: s.yearly_discount_on_turnover || '',
      seasonal_scheme_name: s.seasonal_scheme_name || '',
      seasonal_period_start: s.seasonal_period_start || '',
      seasonal_period_end: s.seasonal_period_end || '',
      seasonal_applicability: s.seasonal_applicability || 'All Products',
      seasonal_frequency: s.seasonal_frequency || 'Yearly'
    }));
  };

  const handleImportCompanyImages = () => {
    if (!companyInheritedMedia?.images?.length) return;
    const curImgs = Array.isArray(product?.images) ? product.images : (product?.image_url ? [product.image_url] : []);
    const existing = new Set(curImgs);
    const newImgs = companyInheritedMedia.images.filter(img => !existing.has(img));
    if (newImgs.length === 0) {
      alert("All photos from this company gallery are already added to the element.");
      return;
    }
    const combined = [...curImgs, ...newImgs];
    setProduct(prev => ({
      ...prev,
      images: combined,
      image_url: combined[0] || null
    }));
  };

  const handleClearInheritedMedia = () => {
    if (companyBrochure?.isInherited) {
      setCompanyBrochure({ url: '', name: '', isInherited: false });
    }
    if (companyInheritedMedia?.videoUrl && product?.video_url === companyInheritedMedia.videoUrl) {
      setProduct(prev => ({ ...prev, video_url: '' }));
    }
    setCompanyInheritedMedia(null);
  };

  const handleModalAddOfficer = () => {
    setModalCompanyOfficers([...modalCompanyOfficers, '']);
  };

  const handleModalOfficerChange = (index, value) => {
    const next = [...modalCompanyOfficers];
    next[index] = value;
    setModalCompanyOfficers(next);
  };

  const handleModalRemoveOfficer = (index) => {
    if (modalCompanyOfficers.length === 1) {
      setModalCompanyOfficers(['']);
    } else {
      setModalCompanyOfficers(modalCompanyOfficers.filter((_, i) => i !== index));
    }
  };

  const submitNewCompany = async (e) => {
    e.preventDefault();
    try {
      const validOfficers = modalCompanyOfficers.map(o => o.trim()).filter(Boolean);
      const res = await api.post('/admin/companies', {
        name: modalCompanyName,
        description: modalCompanyDesc,
        scheme: modalCompanyScheme,
        offer: modalCompanyOffer,
        margin: modalCompanyMargin,
        authorized_distributor: modalCompanyDistributor,
        company_officer_name: validOfficers.join(', '),
        company_officers: validOfficers,
        brochure_images: modalCompanyBrochures,
        brochures: modalCompanyBrochures,
        brochure_urls: modalCompanyBrochures,
        brochure_url: modalCompanyBrochures.length > 0 ? modalCompanyBrochures[0] : null,
        status: 'Active'
      });
      const newCompany = res.data?.data || res.data;
      setCompanies([...companies, newCompany]);
      handleCompanySelect(newCompany.name || modalCompanyName, newCompany);
      setShowAddCompanyModal(false);
      setModalCompanyName('');
      setModalCompanyDesc('');
      setModalCompanyScheme('');
      setModalCompanyOffer('');
      setModalCompanyMargin('');
      setModalCompanyDistributor('');
      setModalCompanyOfficers(['']);
      setModalCompanyBrochures([]);
    } catch (err) {
      alert("Failed to add company");
    }
  };

  const handleAddNewBrand = () => {
    if (!companyName) {
      alert("Please select a Company first");
      return;
    }
    setShowAddBrandModal(true);
  };
  const submitNewBrand = async (e) => {
    e.preventDefault();
    try {
      const res = await api.post('/admin/brands', {
        name: modalBrandName,
        description: modalBrandDesc,
        company_name: companyName,
        scheme: modalBrandScheme,
        offer: modalBrandOffer,
        margin: modalBrandMargin,
        authorized_distributor: modalBrandDistributor,
        company_officer_name: modalBrandOfficer,
        status: 'Active'
      });
      const newBrand = res.data?.data || res.data;
      setBrands([...brands, newBrand]);
      setProduct({ ...product, brand_id: newBrand.id });
      setShowAddBrandModal(false);
      setModalBrandName('');
      setModalBrandDesc('');
      setModalBrandScheme('');
      setModalBrandOffer('');
      setModalBrandMargin('');
      setModalBrandDistributor('');
      setModalBrandOfficer('');
    } catch (err) {
      alert("Failed to add brand");
    }
  };

  const handleAutoCalculateReorder = async () => {
    try {
      const res = await api.post('/inventory/calculate-reorder', {
        product_id: product.id,
        lead_time_days: product.lead_time_days || 7,
        safety_stock: product.safety_stock || 0,
        max_stock_level: product.max_stock_level || 0
      });
      if (res.data?.success) {
        const d = res.data.data;
        setProduct(prev => ({
          ...prev,
          reorder_level: d.calculated_reorder_level,
          reorder_qty: d.calculated_reorder_qty
        }));
        alert(`Calculated Successfully!\n\n• 30-Day Sales Velocity: ${d.avg_daily_sales} units/day\n• Formula: ${d.formulas.rol_formula}\n• Suggested Reorder Level: ${d.calculated_reorder_level} units\n• Suggested Reorder Qty: ${d.calculated_reorder_qty} units`);
      }
    } catch (err) {
      console.error('Calculation error:', err);
      alert('Failed to calculate reorder metrics automatically.');
    }
  };

  const handleUpdateProduct = async (e) => {
    e.preventDefault();
    try {
      const effectiveDimUnit = dimensionUnit === 'custom' ? (customDimensionUnit.trim() || '') : dimensionUnit;
      const effectiveVolUnit = volumeUnit === 'custom' ? (customVolumeUnit.trim() || '') : volumeUnit;
      const effectiveWtUnit = weightUnit === 'custom' ? (customWeightUnit.trim() || '') : weightUnit;

      if (
        (product.purchase_price !== '' && parseFloat(product.purchase_price) < 0) ||
        (product.selling_price !== '' && parseFloat(product.selling_price) < 0) ||
        (product.mrp !== '' && parseFloat(product.mrp) < 0) ||
        (product.distributor_price !== '' && parseFloat(product.distributor_price) < 0) ||
        (product.profit_percent !== '' && parseFloat(product.profit_percent) < 0) ||
        (product.selling_price_wholesale !== '' && parseFloat(product.selling_price_wholesale) < 0) ||
        (product.selling_price_retail !== '' && parseFloat(product.selling_price_retail) < 0) ||
        (product.gst_rate !== '' && parseFloat(product.gst_rate) < 0) ||
        (product.reorder_level !== '' && parseInt(product.reorder_level, 10) < 0)
      ) {
        alert("Pricing, GST rate, and quantities cannot be negative.");
        return;
      }

      if (hasVariants === 'Yes') {
        const hasNegativeVariantPrice = productVariants.some(v => {
          const sPrice = parseFloat(v.selling_price);
          const pExtra = parseFloat(v.price_extra);
          const pkgs = Array.isArray(v.packagings) ? v.packagings : (Array.isArray(v.packaging) ? v.packaging : []);
          const hasNegPkg = pkgs.some(p => (p.selling_price !== '' && parseFloat(p.selling_price) < 0) || (p.quantity && parseInt(p.quantity, 10) < 0));
          return (!isNaN(sPrice) && sPrice < 0) || (!isNaN(pExtra) && pExtra < 0) || hasNegPkg;
        });
        if (hasNegativeVariantPrice) {
          alert("Variant selling prices, extra prices, or packaging prices cannot be negative.");
          return;
        }
      }

      if (
        (product.lot_number !== '' && product.lot_number !== null && !/^\d+$/.test(String(product.lot_number).trim())) ||
        (product.lot_number !== '' && product.lot_number !== null && Number(product.lot_number) < 0)
      ) {
        alert("Lot Number must contain only positive numbers.");
        return;
      }

      if (
        (product.batch_number !== '' && product.batch_number !== null && !/^\d+$/.test(String(product.batch_number).trim())) ||
        (product.batch_number !== '' && product.batch_number !== null && Number(product.batch_number) < 0)
      ) {
        alert("Batch Number must contain only positive numbers.");
        return;
      }

      const cleanVal = (val, u) => {
        if (!val) return '';
        let str = String(val).trim();
        // remove known standard units or custom unit if at end
        str = str.replace(/\s*(cm|mm|m|in|ft|ml|l|fl oz|gal|kg|g|mg|lb|oz)$/i, '').trim();
        if (u) {
          const escU = u.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
          str = str.replace(new RegExp(`\\s*${escU}$`, 'i'), '').trim();
        }
        return str;
      };

      const cleanDatePayload = (d) => {
        if (!d || d === 'Invalid date' || String(d).trim() === '') return null;
        const parsed = new Date(d);
        return isNaN(parsed.getTime()) ? null : String(d).trim().split('T')[0];
      };

      const payload = {
        ...product,
        company_brochure_url: companyBrochure?.url || null,
        company_brochure_name: companyBrochure?.name || null,
        seasonal_period_start: cleanDatePayload(product.seasonal_period_start),
        seasonal_period_end: cleanDatePayload(product.seasonal_period_end),
        manufacturing_date: cleanDatePayload(product.manufacturing_date),
        expiry_date: cleanDatePayload(product.expiry_date),
        best_before_date: cleanDatePayload(product.best_before_date),
        length: cleanVal(product.length, effectiveDimUnit) ? (effectiveDimUnit ? `${cleanVal(product.length, effectiveDimUnit)} ${effectiveDimUnit}` : cleanVal(product.length)) : null,
        breadth: cleanVal(product.breadth, effectiveDimUnit) ? (effectiveDimUnit ? `${cleanVal(product.breadth, effectiveDimUnit)} ${effectiveDimUnit}` : cleanVal(product.breadth)) : null,
        thickness: cleanVal(product.thickness, effectiveDimUnit) ? (effectiveDimUnit ? `${cleanVal(product.thickness, effectiveDimUnit)} ${effectiveDimUnit}` : cleanVal(product.thickness)) : null,
        volume: cleanVal(product.volume, effectiveVolUnit) ? (effectiveVolUnit ? `${cleanVal(product.volume, effectiveVolUnit)} ${effectiveVolUnit}` : cleanVal(product.volume)) : null,
        net_weight: cleanVal(product.net_weight, effectiveWtUnit) ? (effectiveWtUnit ? `${cleanVal(product.net_weight, effectiveWtUnit)} ${effectiveWtUnit}` : cleanVal(product.net_weight)) : null,
        gross_weight: cleanVal(product.gross_weight, effectiveWtUnit) ? (effectiveWtUnit ? `${cleanVal(product.gross_weight, effectiveWtUnit)} ${effectiveWtUnit}` : cleanVal(product.gross_weight)) : null,
        attributes: attributes.filter(a => a.name.trim() !== '' && a.value.trim() !== ''),
        is_occasion_based: isOccasionBased === 'Yes',
        occasion_ids: isOccasionBased === 'Yes' ? selectedOccasionIds : [],
        has_variants: hasVariants === 'Yes',
        variant_attributes: hasVariants === 'Yes' ? variantAttributes : [],
        variants: hasVariants === 'Yes' ? productVariants.map(v => {
          const vSellingPrice = parseFloat(v.selling_price) || (parseFloat(product.selling_price) || 0) + (parseFloat(v.price_extra) || 0);
          const vPurchasePrice = parseFloat(v.purchase_price) || (parseFloat(product.purchase_price) || 0);
          const vMrp = parseFloat(v.mrp) || (parseFloat(product.mrp) || vSellingPrice);
          const vOpeningStock = parseInt(v.opening_stock ?? v.stock ?? (product.purchase_quantity || 0), 10);
          const rawPackagings = Array.isArray(v.packagings) ? v.packagings : (Array.isArray(v.packaging) ? v.packaging : []);

          return {
            name: v.name || v.variant_name || `${product.product_name} (${Object.values(v.combination || v.variant_attributes || {}).join(' - ')})`,
            variant_name: v.name || v.variant_name,
            sku: v.sku,
            variant_attributes: v.variant_attributes || v.combination || {},
            combination: v.combination || v.variant_attributes || {},
            purchase_price: vPurchasePrice,
            selling_price: vSellingPrice,
            mrp: vMrp,
            opening_stock: vOpeningStock,
            gtin_ean_upc: v.gtin_ean_upc || v.barcode || `${v.sku}-UNIT`,
            barcode: v.gtin_ean_upc || v.barcode || `${v.sku}-UNIT`,
            price_extra: parseFloat(v.price_extra) || 0,
            packagings: rawPackagings.map(p => {
              const qty = parseInt(p.quantity || p.quantity_per_pack || 24, 10);
              const pCode = p.package_barcode || p.barcode || `${v.sku}-C${qty}`;
              return {
                package_name: p.package_name || `Pack of ${qty}`,
                quantity: qty,
                quantity_per_pack: qty,
                package_barcode: pCode,
                barcode: pCode,
                package_qr_payload: p.package_qr_payload || JSON.stringify({ type: "PACKAGE", sku: v.sku, qty }),
                selling_price: parseFloat(p.selling_price) || (vSellingPrice * qty * 0.95)
              };
            }),
            packaging: rawPackagings.map(p => {
              const qty = parseInt(p.quantity || p.quantity_per_pack || 24, 10);
              const pCode = p.package_barcode || p.barcode || `${v.sku}-C${qty}`;
              return {
                id: p.id,
                package_name: p.package_name || `Pack of ${qty}`,
                quantity_per_pack: qty,
                quantity: qty,
                barcode: pCode,
                package_barcode: pCode,
                package_qr_payload: p.package_qr_payload || JSON.stringify({ type: "PACKAGE", sku: v.sku, qty }),
                selling_price: parseFloat(p.selling_price) || (vSellingPrice * qty * 0.95)
              };
            })
          };
        }) : []
      };
      await api.put(`/admin/products/${id}`, payload);
      alert('Product updated successfully');
      fetchData();
    } catch (error) {
      console.error("Failed to update product", error);
      alert('Failed to update product');
    }
  };

  const handleStatusChange = async (status) => {
    try {
      await api.patch(`/admin/products/${id}/status`, { status });
      setProduct({ ...product, status });
    } catch (error) {
      console.error("Failed to update status", error);
    }
  };

  if (loading) return <div>Loading...</div>;
  if (!product) return <div>Product not found.</div>;

  return (
    <div>
      {showAddGroupModal && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1100, padding: '16px' }}>
          <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '8px', width: '520px', maxWidth: '95vw', maxHeight: '90vh', overflowY: 'auto', position: 'relative', boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.2)' }}>
            <button type="button" onClick={() => { setShowAddGroupModal(false); setModalGroupImages([]); }} style={{ position: 'absolute', top: '16px', right: '16px', background: 'transparent', border: 'none', fontSize: '24px', cursor: 'pointer', color: '#7f8c8d' }}>&times;</button>
            <h2 style={{ marginTop: 0, marginBottom: '20px', color: '#2c3e50', fontSize: '1.25rem' }}>Add Product Group</h2>
            <form onSubmit={submitNewGroup}>
              <div style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', color: '#000', fontSize: '1rem', marginBottom: '6px' }}>Group Name *</label>
                <input type="text" required style={{ width: '100%', padding: '10px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalGroupName} onChange={e => setModalGroupName(e.target.value)} />
              </div>
              <div style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', color: '#000', fontSize: '1rem', marginBottom: '6px' }}>Description</label>
                <textarea style={{ width: '100%', padding: '10px', border: '1px solid #bdc3c7', borderRadius: '4px' }} rows="3" value={modalGroupDesc} onChange={e => setModalGroupDesc(e.target.value)}></textarea>
              </div>

              {/* GROUP IMAGES FIELD (MULTIPLE) */}
              <div style={{ marginBottom: '20px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                  <label style={{ display: 'block', color: '#000', fontSize: '0.95rem', fontWeight: '600', margin: 0 }}>Group Images (Optional)</label>
                  <span style={{ fontSize: '0.8rem', color: '#64748b' }}>{modalGroupImages.length} photo(s) selected</span>
                </div>
                <PhotoUploader images={modalGroupImages} onChange={setModalGroupImages} maxFiles={10} compact={true} />
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
                <button type="button" onClick={() => { setShowAddGroupModal(false); setModalGroupImages([]); }} style={{ padding: '10px 16px', backgroundColor: '#ecf0f1', color: '#2c3e50', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Cancel</button>
                <button type="submit" style={{ padding: '10px 16px', backgroundColor: '#3498db', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Save Group</button>
              </div>
            </form>
          </div>
        </div>
      )}
      <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '24px' }}>
        <button className="btn" style={{ padding: '8px', width: 'auto' }} onClick={() => navigate('/products')}>
          <ArrowLeft size={20} />
        </button>
        <div>
          <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold', margin: 0, display: 'flex', alignItems: 'center', gap: '12px' }}>
            {product.product_name}
            <span style={{ color: '#94a3b8', fontSize: '1.1rem', fontWeight: 'normal', backgroundColor: '#f1f5f9', padding: '4px 10px', borderRadius: '6px' }}>
              PRO{String(product.id).padStart(5, '0')}
            </span>
          </h1>
          <div style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>
            {(() => {
              let path = [];
              let currentId = product.group_id;
              while (currentId) {
                const g = groups.find(x => x.id == currentId);
                if (g) {
                  path.unshift(`${g.name} (${g.group_code || 'GRP'})`);
                  currentId = g.parent_id;
                } else {
                  break;
                }
              }
              return path.length > 0 ? path.join(' > ') + ' > ' : '';
            })()}
            {product.product_name} | SKU: {product.internal_sku}
          </div>
        </div>
        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
          <button
            type="button"
            onClick={() => downloadProductBrochurePDF(product, groups, brands)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '8px 14px',
              backgroundColor: '#4338ca',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              fontSize: '0.85rem',
              fontWeight: '600',
              cursor: 'pointer',
              boxShadow: '0 2px 4px rgba(67, 56, 202, 0.2)'
            }}
          >
            <FileDown size={16} /> Brochure (PDF)
          </button>
          <button
            type="button"
            onClick={() => downloadProductDetailsExcel(product, groups, brands)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '8px 14px',
              backgroundColor: '#059669',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              fontSize: '0.85rem',
              fontWeight: '600',
              cursor: 'pointer',
              boxShadow: '0 2px 4px rgba(5, 150, 105, 0.2)'
            }}
          >
            <FileSpreadsheet size={16} /> Export (Excel)
          </button>
          <select
            className="form-control"
            style={{ width: 'auto', margin: 0, padding: '8px 12px' }}
            value={product.status}
            onChange={(e) => handleStatusChange(e.target.value)}
          >
            <option value="Draft">Draft</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>
      </div>

      <div style={{ maxWidth: '1000px', margin: '0 auto', gap: '24px', display: 'flex', flexDirection: 'column' }}>
        <style>
          {`
            .premium-input:focus { border-color: #3b82f6 !important; background-color: #fff !important; box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1); }
            .premium-card:hover { box-shadow: 0 15px 35px rgba(0,0,0,0.08), 0 5px 15px rgba(0,0,0,0.03) !important; transform: translateY(-2px); }
          `}
        </style>
        <form onSubmit={handleUpdateProduct}>
          {/* CATEGORIZATION CARD */}
          <div className="premium-card" style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', backdropFilter: 'blur(10px)', padding: '32px', borderRadius: '16px', boxShadow: '0 10px 25px rgba(0,0,0,0.04)', marginBottom: '24px', border: '1px solid rgba(226, 232, 240, 0.8)', transition: 'all 0.3s ease' }}>
            <h2 style={{ fontSize: '1.2rem', fontWeight: '600', color: '#0f172a', borderBottom: '2px solid #f1f5f9', paddingBottom: '12px', marginBottom: '24px' }}>Categorization</h2>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '24px' }}>
              {(() => {
                let path = [];
                let currentId = product.group_id;
                while (currentId) {
                  const g = groups.find(x => x.id == currentId);
                  if (g) {
                    path.unshift(g.id);
                    currentId = g.parent_id;
                  } else {
                    break;
                  }
                }

                const dropdowns = [];
                let parentForNext = null;

                for (let i = 0; i <= path.length; i++) {
                  const availableOptions = groups.filter(g => g.parent_id == parentForNext);
                  if (availableOptions.length === 0) break;

                  const selectedValue = i < path.length ? path[i] : '';
                  const currentParentId = parentForNext;

                  dropdowns.push(
                    <div key={i} style={{ marginBottom: '16px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                        <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', margin: 0 }}>
                          {i === 0 ? 'Product Group (Optional)' : `Product SubGroup (Level ${i})`}
                        </label>
                        {i === 0 && <button type="button" onClick={handleAddNewGroup} style={{ background: 'none', border: 'none', color: '#3b82f6', cursor: 'pointer', fontSize: '0.85rem', padding: 0, fontWeight: '600' }}>+ Add Group</button>}
                      </div>
                      <select className="premium-input" style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s', appearance: 'none', backgroundImage: 'url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'currentColor\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3e%3cpolyline points=\'6 9 12 15 18 9\'%3e%3c/polyline%3e%3c/svg%3e")', backgroundRepeat: 'no-repeat', backgroundPosition: 'right 1rem center', backgroundSize: '1em' }}
                        value={selectedValue}
                        onChange={e => {
                          const newGroupId = e.target.value || currentParentId;
                          setProduct({ ...product, group_id: newGroupId });
                        }}
                      >
                        <option value="">{i === 0 ? 'Select Category' : 'Select Subcategory'}</option>
                        {availableOptions.map(g => (
                          <option key={g.id} value={g.id}>{g.name} {g.group_code ? `(${g.group_code})` : ''}</option>
                        ))}
                      </select>
                    </div>
                  );

                  parentForNext = selectedValue;
                  if (!parentForNext) break;
                }

                return dropdowns;
              })()}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px', paddingTop: '12px', borderTop: '1px dashed #e2e8f0' }}>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                  <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', margin: 0 }}>Company</label>
                  <button type="button" onClick={handleAddNewCompany} style={{ background: 'none', border: 'none', color: '#3b82f6', cursor: 'pointer', fontSize: '0.85rem', padding: 0, fontWeight: '600' }}>+ Add Company</button>
                </div>
                <select className="premium-input" style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s', appearance: 'none', backgroundImage: 'url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'currentColor\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3e%3cpolyline points=\'6 9 12 15 18 9\'%3e%3c/polyline%3e%3c/svg%3e")', backgroundRepeat: 'no-repeat', backgroundPosition: 'right 1rem center', backgroundSize: '1em' }} value={companyName} onChange={(e) => handleCompanySelect(e.target.value)}>
                  <option value="">Select Company</option>
                  {companies.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                </select>
              </div>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                  <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', margin: 0 }}>Brand</label>
                  <button type="button" onClick={handleAddNewBrand} style={{ background: 'none', border: 'none', color: '#3b82f6', cursor: 'pointer', fontSize: '0.85rem', padding: 0, fontWeight: '600' }}>+ Add Brand</button>
                </div>
                <select className="premium-input" style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s', appearance: 'none', backgroundImage: 'url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'currentColor\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3e%3cpolyline points=\'6 9 12 15 18 9\'%3e%3c/polyline%3e%3c/svg%3e")', backgroundRepeat: 'no-repeat', backgroundPosition: 'right 1rem center', backgroundSize: '1em' }} value={product.brand_id || ''} onChange={e => setProduct({ ...product, brand_id: e.target.value })} disabled={!companyName}>
                  <option value="">Select Brand</option>
                  {brands.filter(b => b.company_name === companyName).map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                </select>
              </div>
            </div>

            {/* SMART AUTO-FETCH BANNER (EDIT MODE) */}
            {companyName && (
              <div style={{
                marginTop: '16px',
                padding: '12px 16px',
                borderRadius: '10px',
                background: companyInheritedMedia?.hasMedia
                  ? 'linear-gradient(135deg, #f0fdf4 0%, #eef2ff 100%)'
                  : '#f8fafc',
                border: companyInheritedMedia?.hasMedia
                  ? '1px solid #c7d2fe'
                  : '1px dashed #cbd5e1',
                boxShadow: companyInheritedMedia?.hasMedia
                  ? '0 2px 6px rgba(99, 102, 241, 0.08)'
                  : 'none'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '8px', marginBottom: companyInheritedMedia?.hasMedia ? '10px' : '0' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <Sparkles size={16} color={companyInheritedMedia?.hasMedia ? '#4f46e5' : '#94a3b8'} />
                    <span style={{ fontSize: '0.85rem', fontWeight: '700', color: companyInheritedMedia?.hasMedia ? '#1e1b4b' : '#64748b' }}>
                      {companyInheritedMedia?.hasMedia
                        ? `Smart Media Auto-Fetch Active (${companyName})`
                        : `Company Media Assets (${companyName})`}
                    </span>
                    {isInheritingMedia && (
                      <span style={{ fontSize: '0.72rem', color: '#6366f1', display: 'flex', alignItems: 'center', gap: '4px' }}>
                        <Loader2 size={12} className="animate-spin" /> Fetching assets...
                      </span>
                    )}
                  </div>

                  {companyInheritedMedia?.hasMedia && (
                    <button
                      type="button"
                      onClick={handleClearInheritedMedia}
                      style={{
                        background: 'none',
                        border: 'none',
                        color: '#ef4444',
                        fontSize: '0.75rem',
                        fontWeight: '600',
                        cursor: 'pointer',
                        padding: 0
                      }}
                    >
                      Clear Inherited
                    </button>
                  )}
                </div>

                {companyInheritedMedia?.hasMedia && (
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', alignItems: 'center' }}>
                    {companyInheritedMedia.brochureUrl && (
                      <span style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '5px',
                        padding: '4px 10px',
                        borderRadius: '6px',
                        backgroundColor: '#ecfdf5',
                        color: '#065f46',
                        border: '1px solid #a7f3d0',
                        fontSize: '0.78rem',
                        fontWeight: '600'
                      }}>
                        <CheckCircle2 size={13} color="#059669" /> Brochure PDF Auto-Linked
                      </span>
                    )}

                    {companyInheritedMedia.videoUrl && (
                      <span style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '5px',
                        padding: '4px 10px',
                        borderRadius: '6px',
                        backgroundColor: '#eff6ff',
                        color: '#1e40af',
                        border: '1px solid #bfdbfe',
                        fontSize: '0.78rem',
                        fontWeight: '600'
                      }}>
                        <CheckCircle2 size={13} color="#2563eb" /> Video Auto-Linked
                      </span>
                    )}

                    {companyInheritedMedia.images?.length > 0 && (
                      <button
                        type="button"
                        onClick={handleImportCompanyImages}
                        style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: '6px',
                          padding: '4px 12px',
                          borderRadius: '6px',
                          backgroundColor: '#4338ca',
                          color: '#ffffff',
                          border: 'none',
                          fontSize: '0.78rem',
                          fontWeight: '700',
                          cursor: 'pointer',
                          transition: 'all 0.15s'
                        }}
                      >
                        <ImageIcon size={13} /> + Import {companyInheritedMedia.images.length} Company Photos
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* OCCASION MANAGEMENT CARD */}
          <div className="premium-card" style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', backdropFilter: 'blur(10px)', padding: '32px', borderRadius: '16px', boxShadow: '0 10px 25px rgba(0,0,0,0.04)', marginBottom: '24px', border: '1px solid rgba(226, 232, 240, 0.8)', transition: 'all 0.3s ease' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '2px solid #f1f5f9', paddingBottom: '12px', marginBottom: '24px' }}>
              <div>
                <h2 style={{ fontSize: '1.2rem', fontWeight: '600', color: '#0f172a', margin: 0 }}>Occasion Management</h2>
                <p style={{ margin: '4px 0 0 0', fontSize: '0.85rem', color: '#64748b' }}>Configure seasonal, festival, or event affiliation for this product</p>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                <span style={{ fontSize: '0.9rem', fontWeight: '600', color: '#475569' }}>Is Occasion Based?</span>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '0.9rem', fontWeight: '600', color: isOccasionBased === 'Yes' ? '#4338ca' : '#64748b' }}>
                    <input
                      type="radio"
                      name="edit_is_occasion_based"
                      value="Yes"
                      checked={isOccasionBased === 'Yes'}
                      onChange={() => setIsOccasionBased('Yes')}
                    />
                    Yes
                  </label>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '0.9rem', fontWeight: '600', color: isOccasionBased === 'No' ? '#4338ca' : '#64748b' }}>
                    <input
                      type="radio"
                      name="edit_is_occasion_based"
                      value="No"
                      checked={isOccasionBased === 'No'}
                      onChange={() => {
                        setIsOccasionBased('No');
                        setSelectedOccasionIds([]);
                      }}
                    />
                    No
                  </label>
                </div>
              </div>
            </div>

            {isOccasionBased === 'Yes' && (
              <OccasionSelector
                occasionsList={occasionsList}
                occasionTypes={occasionTypes}
                selectedOccasionIds={selectedOccasionIds}
                onChange={setSelectedOccasionIds}
                onOpenAddModal={() => setShowAddOccasionModal(true)}
              />
            )}
          </div>

          {/* BASIC INFORMATION CARD */}
          <div className="premium-card" style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', backdropFilter: 'blur(10px)', padding: '32px', borderRadius: '16px', boxShadow: '0 10px 25px rgba(0,0,0,0.04)', marginBottom: '24px', border: '1px solid rgba(226, 232, 240, 0.8)', transition: 'all 0.3s ease' }}>
            <h2 style={{ fontSize: '1.2rem', fontWeight: '600', color: '#0f172a', borderBottom: '2px solid #f1f5f9', paddingBottom: '12px', marginBottom: '24px' }}>Basic Information</h2>

            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>Element Name *</label>
              <input className="premium-input" type="text" required style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s' }} value={product.product_name || ''} onChange={e => setProduct({ ...product, product_name: e.target.value })} />
            </div>

            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>Element Aliases / Keywords</label>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {productAliases.map((alias, index) => (
                  <div key={index} style={{ display: 'flex', gap: '12px' }}>
                    <input className="premium-input" type="text" placeholder="e.g. Graphic Tee" style={{ flex: 1, padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s' }} value={alias} onChange={(e) => handleAliasChange(index, e.target.value)} />
                    {productAliases.length > 1 && (
                      <button type="button" onClick={() => handleRemoveAlias(index)} style={{ backgroundColor: '#fee2e2', color: '#ef4444', border: 'none', padding: '0 16px', borderRadius: '8px', cursor: 'pointer', transition: 'background-color 0.2s' }} onMouseOver={e => e.currentTarget.style.backgroundColor = '#fca5a5'} onMouseOut={e => e.currentTarget.style.backgroundColor = '#fee2e2'}>
                        <Trash2 size={18} />
                      </button>
                    )}
                  </div>
                ))}
              </div>
              <button type="button" onClick={handleAddAlias} style={{ marginTop: '16px', backgroundColor: '#f1f5f9', color: '#334155', border: '1px dashed #cbd5e1', padding: '10px 16px', borderRadius: '8px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.95rem', fontWeight: '500', transition: 'all 0.2s' }} onMouseOver={e => e.currentTarget.style.backgroundColor = '#e2e8f0'} onMouseOut={e => e.currentTarget.style.backgroundColor = '#f1f5f9'}>
                <Plus size={16} /> Add Another Alias
              </button>
            </div>

            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>Element Description</label>
              <textarea className="premium-input" style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s', minHeight: '100px', resize: 'vertical' }} value={product.short_description || ''} onChange={e => setProduct({ ...product, short_description: e.target.value })} placeholder="Write a compelling description..."></textarea>
            </div>

            {/* HAS VARIANTS TOGGLE */}
            <div
              style={{
                marginTop: '20px',
                padding: '16px 20px',
                borderRadius: '12px',
                backgroundColor: hasVariants === 'Yes' ? '#eef2ff' : '#f8fafc',
                border: '1px solid',
                borderColor: hasVariants === 'Yes' ? '#c7d2fe' : '#e2e8f0',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                transition: 'all 0.2s ease'
              }}
            >
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <Layers size={20} color="#4338ca" />
                  <span style={{ fontSize: '0.95rem', fontWeight: '700', color: '#1e293b' }}>
                    This product has multiple variants (e.g. Flavors, Sizes, Volumes)
                  </span>
                </div>
                <p style={{ margin: '3px 0 0 28px', fontSize: '0.82rem', color: '#64748b' }}>
                  Manage Odoo-style variant matrix, Cartesian combinations, distinct unit QR codes, and multi-pack cartons.
                </p>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '0.92rem', fontWeight: '700', color: hasVariants === 'Yes' ? '#4338ca' : '#64748b' }}>
                  <input
                    type="radio"
                    name="details_has_variants_toggle"
                    value="Yes"
                    checked={hasVariants === 'Yes'}
                    onChange={() => setHasVariants('Yes')}
                  />
                  Yes
                </label>
                <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '0.92rem', fontWeight: '700', color: hasVariants === 'No' ? '#4338ca' : '#64748b' }}>
                  <input
                    type="radio"
                    name="details_has_variants_toggle"
                    value="No"
                    checked={hasVariants === 'No'}
                    onChange={() => setHasVariants('No')}
                  />
                  No
                </label>
              </div>
            </div>

            <div style={{ marginTop: '24px', paddingTop: '24px', borderTop: '1px dashed #e2e8f0' }}>
              <AttributeBuilder attributes={attributes} setAttributes={setAttributes} />
            </div>
          </div>

          {/* ODOO-STYLE VARIANT MATRIX BUILDER CARD (WHEN ENABLED) */}
          {hasVariants === 'Yes' && (
            <div className="premium-card" style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', backdropFilter: 'blur(10px)', padding: '32px', borderRadius: '16px', boxShadow: '0 10px 25px rgba(0,0,0,0.04)', marginBottom: '24px', border: '1px solid #c7d2fe', transition: 'all 0.3s ease' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '2px solid #e0e7ff', paddingBottom: '12px', marginBottom: '24px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <div style={{ backgroundColor: '#e0e7ff', padding: '6px', borderRadius: '8px', color: '#4338ca' }}>
                    <Layers size={22} />
                  </div>
                  <div>
                    <h2 style={{ fontSize: '1.2rem', fontWeight: '700', color: '#0f172a', margin: 0 }}>
                      Product Variants Matrix & Packaging QR
                    </h2>
                    <p style={{ margin: '2px 0 0 0', fontSize: '0.82rem', color: '#64748b' }}>
                      Real-time Cartesian product calculation, individual QR codes, and multi-pack (e.g. Pack of 24) carton labels.
                    </p>
                  </div>
                </div>
                <span style={{ backgroundColor: '#ede9fe', color: '#4338ca', padding: '4px 12px', borderRadius: '999px', fontSize: '0.82rem', fontWeight: '700' }}>
                  {productVariants.length} Active Combinations
                </span>
              </div>

              <VariantMatrixBuilder
                baseProductName={product.product_name}
                baseSku={product.sku || product.internal_sku}
                basePrice={product.selling_price || product.mrp || product.purchase_price || '0.00'}
                currency={product.currency || 'INR'}
                attributes={variantAttributes}
                onChangeAttributes={setVariantAttributes}
                variants={productVariants}
                onChangeVariants={setProductVariants}
              />
            </div>
          )}

          {/* PHYSICAL DETAILS CARD */}
          <div className="premium-card" style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', backdropFilter: 'blur(10px)', padding: '32px', borderRadius: '16px', boxShadow: '0 10px 25px rgba(0,0,0,0.04)', marginBottom: '24px', border: '1px solid rgba(226, 232, 240, 0.8)', transition: 'all 0.3s ease' }}>
            <h2 style={{ fontSize: '1.2rem', fontWeight: '600', color: '#0f172a', borderBottom: '2px solid #f1f5f9', paddingBottom: '12px', marginBottom: '24px' }}>Physical Details</h2>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '20px', marginBottom: '20px' }}>
              <div>
                <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '8px' }}>Product Type</label>
                <select className="premium-input" style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s', appearance: 'none', backgroundImage: 'url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'currentColor\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3e%3cpolyline points=\'6 9 12 15 18 9\'%3e%3c/polyline%3e%3c/svg%3e")', backgroundRepeat: 'no-repeat', backgroundPosition: 'right 1rem center', backgroundSize: '1em' }} value={product.item_type || ''} onChange={(e) => setProduct({ ...product, item_type: e.target.value })}>
                  <option value="">Select Type</option>
                  {["Solid", "Liquid", "Gas"].map((t, idx) => <option key={idx} value={t}>{t}</option>)}
                </select>
              </div>
              <div>
                <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '8px' }}>Physical Appearance</label>
                <select className="premium-input" style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }} value={product.physical_appearance || product.physical_shape || ''} onChange={e => setProduct({ ...product, physical_appearance: e.target.value, physical_shape: e.target.value })}>
                  <option value="">Select...</option>
                  <option value="Powder">Powder</option>
                  <option value="Granules">Granules</option>
                  <option value="Flakes">Flakes</option>
                  <option value="Paste">Paste</option>
                  <option value="Pellets">Pellets</option>
                  <option value="Sheet / Plate">Sheet / Plate</option>
                  <option value="Cylinder / Round">Cylinder / Round</option>
                  <option value="Box / Cube">Box / Cube</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div>
                <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '8px' }}>Size</label>
                <input className="premium-input" type="text" placeholder="Enter size..." style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }} value={product.size || ''} onChange={e => setProduct({ ...product, size: e.target.value })} />
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '20px', marginBottom: '20px' }}>
              <div>
                <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '8px' }}>Packaging</label>
                <select className="premium-input" style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }} value={product.packaging || ''} onChange={e => setProduct({ ...product, packaging: e.target.value })}>
                  <option value="">Select...</option>
                  <option value="Box / Carton">Box / Carton</option>
                  <option value="Bottle">Bottle</option>
                  <option value="Bag / Pouch">Bag / Pouch</option>
                  <option value="Can / Tin">Can / Tin</option>
                  <option value="Drum / Barrel">Drum / Barrel</option>
                  <option value="Packet / Sachet">Packet / Sachet</option>
                  <option value="Blister Pack">Blister Pack</option>
                  <option value="Tube">Tube</option>
                  <option value="Jar">Jar</option>
                  <option value="Strips">Strips</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                  <label style={{ color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', margin: 0 }}>Length</label>
                  <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
                    <select
                      style={{ padding: '2px 8px', border: '1px solid #cbd5e1', borderRadius: '4px', backgroundColor: '#eef2f6', color: '#4338ca', fontSize: '0.75rem', fontWeight: '700', outline: 'none', cursor: 'pointer' }}
                      value={dimensionUnit}
                      onChange={(e) => setDimensionUnit(e.target.value)}
                      title="Dimension Unit"
                    >
                      <option value="cm">cm</option>
                      <option value="mm">mm</option>
                      <option value="m">m</option>
                      <option value="in">in</option>
                      <option value="ft">ft</option>
                      <option value="custom">+ Custom...</option>
                    </select>
                    {dimensionUnit === 'custom' && (
                      <input
                        type="text"
                        placeholder="unit (e.g. yd)"
                        value={customDimensionUnit}
                        onChange={(e) => setCustomDimensionUnit(e.target.value)}
                        style={{ width: '80px', padding: '2px 6px', border: '1px solid #4338ca', borderRadius: '4px', fontSize: '0.75rem', fontWeight: '600', outline: 'none' }}
                      />
                    )}
                  </div>
                </div>
                <div style={{ position: 'relative' }}>
                  <input
                    className="premium-input"
                    type="text"
                    placeholder="Enter length..."
                    style={{ width: '100%', padding: '12px 48px 12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                    value={product.length ? (dimensionUnit === 'custom' && customDimensionUnit ? product.length.replace(new RegExp(`\\s*${customDimensionUnit.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&')}$`, 'i'), '') : product.length.replace(/\s*(cm|mm|m|in|ft)$/i, '')) : ''}
                    onChange={e => setProduct({ ...product, length: e.target.value })}
                  />
                  <span style={{ position: 'absolute', right: '14px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', fontSize: '0.85rem', fontWeight: '600' }}>{dimensionUnit === 'custom' ? (customDimensionUnit || 'unit') : dimensionUnit}</span>
                </div>
              </div>

              <div>
                <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '8px' }}>Breadth</label>
                <div style={{ position: 'relative' }}>
                  <input
                    className="premium-input"
                    type="text"
                    placeholder="Enter breadth..."
                    style={{ width: '100%', padding: '12px 48px 12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                    value={product.breadth ? (dimensionUnit === 'custom' && customDimensionUnit ? product.breadth.replace(new RegExp(`\\s*${customDimensionUnit.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&')}$`, 'i'), '') : product.breadth.replace(/\s*(cm|mm|m|in|ft)$/i, '')) : ''}
                    onChange={e => setProduct({ ...product, breadth: e.target.value })}
                  />
                  <span style={{ position: 'absolute', right: '14px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', fontSize: '0.85rem', fontWeight: '600' }}>{dimensionUnit === 'custom' ? (customDimensionUnit || 'unit') : dimensionUnit}</span>
                </div>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '20px', marginBottom: '20px' }}>
              <div>
                <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '8px' }}>Thickness / Height</label>
                <div style={{ position: 'relative' }}>
                  <input
                    className="premium-input"
                    type="text"
                    placeholder="Enter thickness..."
                    style={{ width: '100%', padding: '12px 48px 12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                    value={product.thickness ? (dimensionUnit === 'custom' && customDimensionUnit ? product.thickness.replace(new RegExp(`\\s*${customDimensionUnit.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&')}$`, 'i'), '') : product.thickness.replace(/\s*(cm|mm|m|in|ft)$/i, '')) : ''}
                    onChange={e => setProduct({ ...product, thickness: e.target.value })}
                  />
                  <span style={{ position: 'absolute', right: '14px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', fontSize: '0.85rem', fontWeight: '600' }}>{dimensionUnit === 'custom' ? (customDimensionUnit || 'unit') : dimensionUnit}</span>
                </div>
              </div>

              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                  <label style={{ color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', margin: 0 }}>Volume</label>
                  <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
                    <select
                      style={{ padding: '2px 8px', border: '1px solid #cbd5e1', borderRadius: '4px', backgroundColor: '#eef2f6', color: '#4338ca', fontSize: '0.75rem', fontWeight: '700', outline: 'none', cursor: 'pointer' }}
                      value={volumeUnit}
                      onChange={(e) => setVolumeUnit(e.target.value)}
                      title="Volume Unit"
                    >
                      <option value="ml">ml</option>
                      <option value="L">L</option>
                      <option value="fl oz">fl oz</option>
                      <option value="gal">gal</option>
                      <option value="custom">+ Custom...</option>
                    </select>
                    {volumeUnit === 'custom' && (
                      <input
                        type="text"
                        placeholder="unit (e.g. cc)"
                        value={customVolumeUnit}
                        onChange={(e) => setCustomVolumeUnit(e.target.value)}
                        style={{ width: '80px', padding: '2px 6px', border: '1px solid #4338ca', borderRadius: '4px', fontSize: '0.75rem', fontWeight: '600', outline: 'none' }}
                      />
                    )}
                  </div>
                </div>
                <div style={{ position: 'relative' }}>
                  <input
                    className="premium-input"
                    type="text"
                    placeholder="Enter volume..."
                    style={{ width: '100%', padding: '12px 48px 12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                    value={product.volume ? (volumeUnit === 'custom' && customVolumeUnit ? product.volume.replace(new RegExp(`\\s*${customVolumeUnit.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&')}$`, 'i'), '') : product.volume.replace(/\s*(ml|l|fl oz|gal)$/i, '')) : ''}
                    onChange={e => setProduct({ ...product, volume: e.target.value })}
                  />
                  <span style={{ position: 'absolute', right: '14px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', fontSize: '0.85rem', fontWeight: '600' }}>{volumeUnit === 'custom' ? (customVolumeUnit || 'unit') : volumeUnit}</span>
                </div>
              </div>

              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                  <label style={{ color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', margin: 0 }}>Net Weight</label>
                  <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
                    <select
                      style={{ padding: '2px 8px', border: '1px solid #cbd5e1', borderRadius: '4px', backgroundColor: '#eef2f6', color: '#4338ca', fontSize: '0.75rem', fontWeight: '700', outline: 'none', cursor: 'pointer' }}
                      value={weightUnit}
                      onChange={(e) => setWeightUnit(e.target.value)}
                      title="Weight Unit"
                    >
                      <option value="g">g</option>
                      <option value="kg">kg</option>
                      <option value="mg">mg</option>
                      <option value="lb">lb</option>
                      <option value="oz">oz</option>
                      <option value="custom">+ Custom...</option>
                    </select>
                    {weightUnit === 'custom' && (
                      <input
                        type="text"
                        placeholder="unit (e.g. ton)"
                        value={customWeightUnit}
                        onChange={(e) => setCustomWeightUnit(e.target.value)}
                        style={{ width: '80px', padding: '2px 6px', border: '1px solid #4338ca', borderRadius: '4px', fontSize: '0.75rem', fontWeight: '600', outline: 'none' }}
                      />
                    )}
                  </div>
                </div>
                <div style={{ position: 'relative' }}>
                  <input
                    className="premium-input"
                    type="text"
                    placeholder="Enter net weight..."
                    style={{ width: '100%', padding: '12px 48px 12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                    value={product.net_weight ? (weightUnit === 'custom' && customWeightUnit ? product.net_weight.replace(new RegExp(`\\s*${customWeightUnit.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&')}$`, 'i'), '') : product.net_weight.replace(/\s*(kg|g|mg|lb|oz)$/i, '')) : ''}
                    onChange={e => setProduct({ ...product, net_weight: e.target.value })}
                  />
                  <span style={{ position: 'absolute', right: '14px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', fontSize: '0.85rem', fontWeight: '600' }}>{weightUnit === 'custom' ? (customWeightUnit || 'unit') : weightUnit}</span>
                </div>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '20px' }}>
              <div>
                <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '8px' }}>Gross Weight</label>
                <div style={{ position: 'relative' }}>
                  <input
                    className="premium-input"
                    type="text"
                    placeholder="Enter gross weight..."
                    style={{ width: '100%', padding: '12px 48px 12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                    value={product.gross_weight ? (weightUnit === 'custom' && customWeightUnit ? product.gross_weight.replace(new RegExp(`\\s*${customWeightUnit.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&')}$`, 'i'), '') : product.gross_weight.replace(/\s*(kg|g|mg|lb|oz)$/i, '')) : ''}
                    onChange={e => setProduct({ ...product, gross_weight: e.target.value })}
                  />
                  <span style={{ position: 'absolute', right: '14px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', fontSize: '0.85rem', fontWeight: '600' }}>{weightUnit === 'custom' ? (customWeightUnit || 'unit') : weightUnit}</span>
                </div>
              </div>
            </div>
          </div>

          {/* IDENTIFIERS & PRICING CARD */}
          <div className="premium-card" style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', backdropFilter: 'blur(10px)', padding: '32px', borderRadius: '16px', boxShadow: '0 10px 25px rgba(0,0,0,0.04)', marginBottom: '24px', border: '1px solid rgba(226, 232, 240, 0.8)', transition: 'all 0.3s ease' }}>
            <h2 style={{ fontSize: '1.2rem', fontWeight: '600', color: '#0f172a', borderBottom: '2px solid #f1f5f9', paddingBottom: '12px', marginBottom: '24px' }}>Identifiers & Pricing</h2>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '24px', marginBottom: '24px' }}>
              <div>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>
                  SKU (Stock Keeping Unit) {hasVariants === 'Yes' && <span style={{ color: '#6366f1', fontSize: '0.8rem' }}>(Template / Base)</span>}
                </label>
                <input
                  className="premium-input"
                  type="text"
                  placeholder={hasVariants === 'Yes' ? "Auto-managed per variant" : "e.g. SKU-PROD-001"}
                  style={{
                    width: '100%',
                    padding: '12px 16px',
                    border: '1px solid #cbd5e1',
                    borderRadius: '8px',
                    backgroundColor: hasVariants === 'Yes' ? '#f1f5f9' : '#f8fafc',
                    color: '#1e293b',
                    outline: 'none',
                    transition: 'all 0.2s',
                    cursor: hasVariants === 'Yes' ? 'not-allowed' : 'text'
                  }}
                  value={product.sku || product.internal_sku || ''}
                  disabled={hasVariants === 'Yes'}
                  onChange={e => setProduct({ ...product, sku: e.target.value, internal_sku: e.target.value })}
                />
                {hasVariants === 'Yes' && (
                  <div style={{ fontSize: '0.75rem', color: '#6366f1', marginTop: '4px' }}>
                    Variant SKUs are configured in the Variants Matrix section above.
                  </div>
                )}
              </div>
              <div>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>Product Code (Auto)</label>
                <input type="text" style={{ width: '100%', padding: '12px 16px', border: '1px solid #e2e8f0', borderRadius: '8px', backgroundColor: '#f1f5f9', color: '#94a3b8', outline: 'none', cursor: 'not-allowed' }} value={product.product_code || ''} disabled />
              </div>
              <div style={{ gridColumn: 'span 2' }}>
                <BarcodeUploader
                  barcodeValue={product.gtin_ean_upc || ''}
                  barcodeImageUrl={product.barcode_image_url || ''}
                  onBarcodeValueChange={(val) => setProduct({ ...product, gtin_ean_upc: val })}
                  onBarcodeImageChange={(url) => setProduct({ ...product, barcode_image_url: url })}
                  label="Barcode / UPC (Universal Product Code)"
                />
              </div>
              <div style={{ gridColumn: 'span 2' }}>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>HSN Code</label>
                <input
                  className="premium-input"
                  type="text"
                  placeholder="e.g. 1905, 8517.12.00"
                  style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s' }}
                  value={product.hsn_code || ''}
                  onChange={(e) => setProduct({ ...product, hsn_code: e.target.value })}
                />
              </div>
            </div>

            {/* Selling Price Calculation Mode & Round Off */}
            <div style={{
              backgroundColor: '#f8fafc',
              border: '1px solid #e2e8f0',
              borderRadius: '12px',
              padding: '16px 20px',
              marginBottom: '24px'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px', flexWrap: 'wrap', gap: '10px' }}>
                <span style={{ fontSize: '0.9rem', fontWeight: '700', color: '#1e293b', display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <span>💡</span> Selling Price Calculation Mode
                </span>

                {/* Round Off Toggle (Yes / No) */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span style={{ fontSize: '0.82rem', color: '#64748b', fontWeight: '600' }}>
                    Round Off (e.g. 10.12 → 10)?
                  </span>
                  <button
                    type="button"
                    onClick={() => setRoundOff(!roundOff)}
                    style={{
                      padding: '4px 14px',
                      borderRadius: '20px',
                      border: 'none',
                      backgroundColor: roundOff ? '#10b981' : '#cbd5e1',
                      color: roundOff ? '#ffffff' : '#475569',
                      fontSize: '0.78rem',
                      fontWeight: '700',
                      cursor: 'pointer',
                      transition: 'all 0.2s'
                    }}
                  >
                    {roundOff ? 'YES' : 'NO'}
                  </button>
                </div>
              </div>

              {/* Mode selector buttons */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '10px', marginBottom: '14px' }}>
                <button
                  type="button"
                  onClick={() => setPricingMethod('PROFIT_ON_COST')}
                  style={{
                    padding: '9px 14px',
                    borderRadius: '8px',
                    border: '1px solid ' + (pricingMethod === 'PROFIT_ON_COST' ? '#4338ca' : '#cbd5e1'),
                    backgroundColor: pricingMethod === 'PROFIT_ON_COST' ? '#e0e7ff' : '#ffffff',
                    color: pricingMethod === 'PROFIT_ON_COST' ? '#4338ca' : '#475569',
                    fontWeight: '600',
                    fontSize: '0.85rem',
                    cursor: 'pointer',
                    transition: 'all 0.2s'
                  }}
                >
                  + Profit % on Cost (Purchase Price)
                </button>

                <button
                  type="button"
                  onClick={() => setPricingMethod('DISCOUNT_ON_MRP')}
                  style={{
                    padding: '9px 14px',
                    borderRadius: '8px',
                    border: '1px solid ' + (pricingMethod === 'DISCOUNT_ON_MRP' ? '#4338ca' : '#cbd5e1'),
                    backgroundColor: pricingMethod === 'DISCOUNT_ON_MRP' ? '#e0e7ff' : '#ffffff',
                    color: pricingMethod === 'DISCOUNT_ON_MRP' ? '#4338ca' : '#475569',
                    fontWeight: '600',
                    fontSize: '0.85rem',
                    cursor: 'pointer',
                    transition: 'all 0.2s'
                  }}
                >
                  - % Discount on MRP
                </button>

                <button
                  type="button"
                  onClick={() => setPricingMethod('DISCOUNT_ON_SELLING_PRICE')}
                  style={{
                    padding: '9px 14px',
                    borderRadius: '8px',
                    border: '1px solid ' + (pricingMethod === 'DISCOUNT_ON_SELLING_PRICE' ? '#4338ca' : '#cbd5e1'),
                    backgroundColor: pricingMethod === 'DISCOUNT_ON_SELLING_PRICE' ? '#e0e7ff' : '#ffffff',
                    color: pricingMethod === 'DISCOUNT_ON_SELLING_PRICE' ? '#4338ca' : '#475569',
                    fontWeight: '600',
                    fontSize: '0.85rem',
                    cursor: 'pointer',
                    transition: 'all 0.2s'
                  }}
                >
                  🏷️ - % Offer on Selling Price
                </button>

                <button
                  type="button"
                  onClick={() => setPricingMethod('MANUAL')}
                  style={{
                    padding: '9px 14px',
                    borderRadius: '8px',
                    border: '1px solid ' + (pricingMethod === 'MANUAL' ? '#4338ca' : '#cbd5e1'),
                    backgroundColor: pricingMethod === 'MANUAL' ? '#e0e7ff' : '#ffffff',
                    color: pricingMethod === 'MANUAL' ? '#4338ca' : '#475569',
                    fontWeight: '600',
                    fontSize: '0.85rem',
                    cursor: 'pointer',
                    transition: 'all 0.2s'
                  }}
                >
                  Manual Price Entry
                </button>
              </div>

              {/* Percentage input for active mode */}
              {pricingMethod === 'PROFIT_ON_COST' && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
                  <label style={{ fontSize: '0.85rem', color: '#475569', fontWeight: '600' }}>
                    Target Profit % on Purchase Price (Cost: {product.currency === 'INR' ? '₹' : (product.currency === 'EUR' ? '€' : (product.currency === 'GBP' ? '£' : '$'))} {product.purchase_price || 0}):
                  </label>
                  <div style={{ position: 'relative', width: '130px' }}>
                    <input
                      type="number"
                      min="0"
                      step="0.1"
                      placeholder="e.g. 15"
                      value={profitOnCostPercent}
                      onChange={(e) => setProfitOnCostPercent(e.target.value)}
                      style={{ width: '100%', padding: '6px 24px 6px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '0.85rem', textAlign: 'right' }}
                    />
                    <span style={{ position: 'absolute', right: '8px', top: '50%', transform: 'translateY(-50%)', fontSize: '0.85rem', color: '#94a3b8' }}>%</span>
                  </div>
                  {product.selling_price && product.purchase_price && (
                    <span style={{ fontSize: '0.85rem', color: '#15803d', fontWeight: '600', backgroundColor: '#dcfce7', padding: '4px 12px', borderRadius: '6px' }}>
                      Calculated Price: {product.currency === 'INR' ? '₹' : (product.currency === 'EUR' ? '€' : (product.currency === 'GBP' ? '£' : '$'))} {product.selling_price} (Profit: +{product.currency === 'INR' ? '₹' : (product.currency === 'EUR' ? '€' : (product.currency === 'GBP' ? '£' : '$'))} {(parseFloat(product.selling_price) - parseFloat(product.purchase_price)).toFixed(2)})
                    </span>
                  )}
                </div>
              )}

              {pricingMethod === 'DISCOUNT_ON_MRP' && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
                  <label style={{ fontSize: '0.85rem', color: '#475569', fontWeight: '600' }}>
                    Discount % off on MRP (MRP: {product.currency === 'INR' ? '₹' : (product.currency === 'EUR' ? '€' : (product.currency === 'GBP' ? '£' : '$'))} {product.mrp || 0}):
                  </label>
                  <div style={{ position: 'relative', width: '130px' }}>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step="0.1"
                      placeholder="e.g. 10"
                      value={discountOnMrpPercent}
                      onChange={(e) => setDiscountOnMrpPercent(e.target.value)}
                      style={{ width: '100%', padding: '6px 24px 6px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '0.85rem', textAlign: 'right' }}
                    />
                    <span style={{ position: 'absolute', right: '8px', top: '50%', transform: 'translateY(-50%)', fontSize: '0.85rem', color: '#94a3b8' }}>%</span>
                  </div>
                  {product.selling_price && product.mrp && (
                    <span style={{ fontSize: '0.85rem', color: '#4338ca', fontWeight: '600', backgroundColor: '#ede9fe', padding: '4px 12px', borderRadius: '6px' }}>
                      Calculated Price: {product.currency === 'INR' ? '₹' : (product.currency === 'EUR' ? '€' : (product.currency === 'GBP' ? '£' : '$'))} {product.selling_price} (Save: {product.currency === 'INR' ? '₹' : (product.currency === 'EUR' ? '€' : (product.currency === 'GBP' ? '£' : '$'))} {(parseFloat(product.mrp) - parseFloat(product.selling_price)).toFixed(2)})
                    </span>
                  )}
                </div>
              )}

              {pricingMethod === 'DISCOUNT_ON_SELLING_PRICE' && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
                  <label style={{ fontSize: '0.85rem', color: '#475569', fontWeight: '600' }}>
                    Base Selling Price:
                  </label>
                  <div style={{ position: 'relative', width: '120px' }}>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      placeholder={product.mrp || product.selling_price || "0.00"}
                      value={baseSellingPrice}
                      onChange={(e) => setBaseSellingPrice(e.target.value)}
                      style={{ width: '100%', padding: '6px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '0.85rem' }}
                    />
                  </div>
                  <label style={{ fontSize: '0.85rem', color: '#475569', fontWeight: '600' }}>
                    Offer % off:
                  </label>
                  <div style={{ position: 'relative', width: '110px' }}>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step="0.1"
                      placeholder="e.g. 10"
                      value={discountOnSellingPricePercent}
                      onChange={(e) => setDiscountOnSellingPricePercent(e.target.value)}
                      style={{ width: '100%', padding: '6px 24px 6px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '0.85rem', textAlign: 'right' }}
                    />
                    <span style={{ position: 'absolute', right: '8px', top: '50%', transform: 'translateY(-50%)', fontSize: '0.85rem', color: '#94a3b8' }}>%</span>
                  </div>
                  {product.selling_price && (
                    <span style={{ fontSize: '0.85rem', color: '#15803d', fontWeight: '600', backgroundColor: '#dcfce7', padding: '4px 12px', borderRadius: '6px' }}>
                      Discounted Selling Price: {product.currency === 'INR' ? '₹' : (product.currency === 'EUR' ? '€' : (product.currency === 'GBP' ? '£' : '$'))} {product.selling_price}
                    </span>
                  )}
                </div>
              )}

              {/* Offer & Scheme Explanation Note */}
              <div style={{ marginTop: '12px', paddingTop: '10px', borderTop: '1px dashed #cbd5e1', fontSize: '0.8rem', color: '#64748b' }}>
                🏷️ <strong>Pricing Guide:</strong> Set your selling price based on <strong>Purchase Price (Cost + Profit %)</strong>, <strong>MRP (- Discount %)</strong>, or <strong>Base Selling Price (- Offer %)</strong>. Special BOGO & Turnover schemes are configured below in <strong>🎁 Product Schemes & Targets</strong>.
              </div>
            </div>

            <div style={{ display: 'flex', gap: '24px', marginBottom: '24px', flexWrap: 'wrap' }}>
              <div style={{ flex: '0 0 120px' }}>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>Currency</label>
                <select className="premium-input" style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s', appearance: 'none', backgroundImage: 'url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'currentColor\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3e%3cpolyline points=\'6 9 12 15 18 9\'%3e%3c/polyline%3e%3c/svg%3e")', backgroundRepeat: 'no-repeat', backgroundPosition: 'right 1rem center', backgroundSize: '1em' }} value={product.currency || 'INR'} onChange={(e) => setProduct({ ...product, currency: e.target.value })}>
                  <option value="INR">INR (₹)</option>
                  <option value="USD">USD ($)</option>
                  <option value="EUR">EUR (€)</option>
                  <option value="GBP">GBP (£)</option>
                  <option value="AUD">AUD</option>
                  <option value="CAD">CAD</option>
                </select>
              </div>
              <div style={{ flex: 1, minWidth: '150px' }}>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>Purchase Price</label>
                <div style={{ position: 'relative' }}>
                  <span style={{ position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', fontWeight: '500' }}>
                    {product.currency === 'INR' ? '₹' : (product.currency === 'EUR' ? '€' : (product.currency === 'GBP' ? '£' : '$'))}
                  </span>
                  <input
                    className="premium-input"
                    type="number"
                    min="0"
                    step="0.01"
                    style={{ width: '100%', padding: '12px 16px 12px 32px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s' }}
                    value={product.purchase_price || ''}
                    onKeyDown={(e) => { if (e.key === '-' || e.key === 'e') e.preventDefault(); }}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val === '' || parseFloat(val) >= 0) setProduct({ ...product, purchase_price: val });
                    }}
                  />
                </div>
              </div>
              <div style={{ flex: 1, minWidth: '150px' }}>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>
                  Selling Price {hasVariants === 'Yes' && <span style={{ color: '#6366f1', fontSize: '0.8rem' }}>(Base)</span>}
                </label>
                <div style={{ position: 'relative' }}>
                  <span style={{ position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', fontWeight: '500' }}>
                    {product.currency === 'INR' ? '₹' : (product.currency === 'EUR' ? '€' : (product.currency === 'GBP' ? '£' : '$'))}
                  </span>
                  <input
                    className="premium-input"
                    type="number"
                    min="0"
                    step="0.01"
                    style={{
                      width: '100%',
                      padding: '12px 16px 12px 32px',
                      border: '1px solid #cbd5e1',
                      borderRadius: '8px',
                      backgroundColor: hasVariants === 'Yes' ? '#f1f5f9' : '#f8fafc',
                      color: '#1e293b',
                      outline: 'none',
                      transition: 'all 0.2s',
                      cursor: hasVariants === 'Yes' ? 'not-allowed' : 'text'
                    }}
                    value={product.selling_price || ''}
                    disabled={hasVariants === 'Yes'}
                    onKeyDown={(e) => { if (e.key === '-' || e.key === 'e') e.preventDefault(); }}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val === '' || parseFloat(val) >= 0) setProduct({ ...product, selling_price: val });
                    }}
                  />
                </div>
                {hasVariants === 'Yes' && (
                  <div style={{ fontSize: '0.75rem', color: '#6366f1', marginTop: '4px' }}>
                    Variant prices are configured in the Variants Matrix section above.
                  </div>
                )}
              </div>
              <div style={{ flex: 1, minWidth: '150px' }}>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>MRP</label>
                <div style={{ position: 'relative' }}>
                  <span style={{ position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', fontWeight: '500' }}>
                    {product.currency === 'INR' ? '₹' : (product.currency === 'EUR' ? '€' : (product.currency === 'GBP' ? '£' : '$'))}
                  </span>
                  <input
                    className="premium-input"
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="0.00"
                    style={{ width: '100%', padding: '12px 16px 12px 32px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s' }}
                    value={product.mrp || ''}
                    onKeyDown={(e) => { if (e.key === '-' || e.key === 'e') e.preventDefault(); }}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val === '' || parseFloat(val) >= 0) setProduct({ ...product, mrp: val });
                    }}
                  />
                </div>
              </div>
              <div style={{ flex: 1, minWidth: '150px' }}>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>Distributor Price</label>
                <div style={{ position: 'relative' }}>
                  <span style={{ position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', fontWeight: '500' }}>
                    {product.currency === 'INR' ? '₹' : (product.currency === 'EUR' ? '€' : (product.currency === 'GBP' ? '£' : '$'))}
                  </span>
                  <input
                    className="premium-input"
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="0.00"
                    style={{ width: '100%', padding: '12px 16px 12px 32px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s' }}
                    value={product.distributor_price || ''}
                    onKeyDown={(e) => { if (e.key === '-' || e.key === 'e') e.preventDefault(); }}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val === '' || parseFloat(val) >= 0) setProduct({ ...product, distributor_price: val });
                    }}
                  />
                </div>
              </div>
              <div style={{ flex: 1, minWidth: '150px' }}>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>Purchase Quantity</label>
                <input
                  className="premium-input"
                  type="number"
                  min="0"
                  step="1"
                  placeholder="0"
                  style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s' }}
                  value={product.purchase_quantity ?? ''}
                  onKeyDown={(e) => { if (e.key === '-' || e.key === 'e') e.preventDefault(); }}
                  onChange={(e) => {
                    const val = e.target.value;
                    if (val === '' || parseInt(val, 10) >= 0) {
                      setProduct({ ...product, purchase_quantity: val === '' ? '' : parseInt(val, 10) });
                    }
                  }}
                />
              </div>
              <div style={{ flex: 1, minWidth: '150px' }}>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>GST Rate (%)</label>
                <div style={{ position: 'relative' }}>
                  <input
                    className="premium-input"
                    type="number"
                    min="0"
                    max="100"
                    step="0.01"
                    placeholder="0.00"
                    style={{ width: '100%', padding: '12px 32px 12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s' }}
                    value={product.gst_rate || ''}
                    onKeyDown={(e) => { if (e.key === '-' || e.key === 'e') e.preventDefault(); }}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val === '' || (parseFloat(val) >= 0 && parseFloat(val) <= 100)) setProduct({ ...product, gst_rate: val });
                    }}
                  />
                  <span style={{ position: 'absolute', right: '16px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', fontWeight: '500' }}>%</span>
                </div>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '24px', marginBottom: '24px' }}>
              <div>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>Profit Percent (%)</label>
                <div style={{ position: 'relative' }}>
                  <input
                    className="premium-input"
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="0.00"
                    style={{ width: '100%', padding: '12px 32px 12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s' }}
                    value={product.profit_percent || ''}
                    onKeyDown={(e) => { if (e.key === '-' || e.key === 'e') e.preventDefault(); }}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val === '' || parseFloat(val) >= 0) setProduct({ ...product, profit_percent: val });
                    }}
                  />
                  <span style={{ position: 'absolute', right: '16px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', fontWeight: '500' }}>%</span>
                </div>
              </div>
              <div>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>Selling Price (Wholesale)</label>
                <div style={{ position: 'relative' }}>
                  <span style={{ position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', fontWeight: '500' }}>
                    {product.currency === 'INR' ? '₹' : (product.currency === 'EUR' ? '€' : (product.currency === 'GBP' ? '£' : '$'))}
                  </span>
                  <input
                    className="premium-input"
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="0.00"
                    style={{ width: '100%', padding: '12px 16px 12px 32px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s' }}
                    value={product.selling_price_wholesale || ''}
                    onKeyDown={(e) => { if (e.key === '-' || e.key === 'e') e.preventDefault(); }}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val === '' || parseFloat(val) >= 0) setProduct({ ...product, selling_price_wholesale: val });
                    }}
                  />
                </div>
              </div>
              <div>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>Selling Price (Retail / MRP)</label>
                <div style={{ position: 'relative' }}>
                  <span style={{ position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', fontWeight: '500' }}>
                    {product.currency === 'INR' ? '₹' : (product.currency === 'EUR' ? '€' : (product.currency === 'GBP' ? '£' : '$'))}
                  </span>
                  <input
                    className="premium-input"
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="0.00"
                    style={{ width: '100%', padding: '12px 16px 12px 32px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s' }}
                    value={product.selling_price_retail || ''}
                    onKeyDown={(e) => { if (e.key === '-' || e.key === 'e') e.preventDefault(); }}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val === '' || parseFloat(val) >= 0) setProduct({ ...product, selling_price_retail: val });
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Schemes & Targets Section */}
            {/* COMPANY SCHEMES MATCH & SYNC BANNER */}
            {companyName && (
              <div style={{
                marginBottom: '16px',
                padding: '12px 16px',
                borderRadius: '10px',
                backgroundColor: companyInheritedSchemes?.hasSchemes ? '#f0fdf4' : '#f8fafc',
                border: companyInheritedSchemes?.hasSchemes ? '1px solid #86efac' : '1px solid #e2e8f0',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                flexWrap: 'wrap',
                gap: '12px'
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <div style={{
                    width: '36px',
                    height: '36px',
                    borderRadius: '8px',
                    backgroundColor: companyInheritedSchemes?.hasSchemes ? '#dcfce7' : '#e2e8f0',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: companyInheritedSchemes?.hasSchemes ? '#16a34a' : '#64748b'
                  }}>
                    <Building2 size={20} />
                  </div>
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <strong style={{ fontSize: '0.88rem', color: '#0f172a' }}>
                        {companyName} Trade Schemes Engine
                      </strong>
                      {companyInheritedSchemes?.hasSchemes ? (
                        <span style={{ fontSize: '0.72rem', backgroundColor: '#dcfce7', color: '#15803d', padding: '2px 8px', borderRadius: '999px', fontWeight: '700' }}>
                          ✓ Company Policy Available
                        </span>
                      ) : (
                        <span style={{ fontSize: '0.72rem', backgroundColor: '#f1f5f9', color: '#64748b', padding: '2px 8px', borderRadius: '999px', fontWeight: '600' }}>
                          No default company schemes
                        </span>
                      )}
                    </div>
                    <p style={{ margin: '2px 0 0 0', fontSize: '0.78rem', color: '#64748b' }}>
                      {companyInheritedSchemes?.hasSchemes
                        ? `Default BOGO, discounts, and turnover rebates configured for ${companyName} match directly with this product.`
                        : `You can configure custom trade schemes below or define defaults in the Companies module.`}
                    </p>
                  </div>
                </div>

                {companyInheritedSchemes?.hasSchemes && (
                  <button
                    type="button"
                    onClick={handleApplyCompanySchemes}
                    style={{
                      padding: '8px 14px',
                      backgroundColor: '#16a34a',
                      color: '#ffffff',
                      border: 'none',
                      borderRadius: '6px',
                      fontSize: '0.8rem',
                      fontWeight: '700',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '6px',
                      boxShadow: '0 2px 4px rgba(22, 163, 74, 0.2)'
                    }}
                  >
                    <Sparkles size={14} /> Re-apply Company Schemes
                  </button>
                )}
              </div>
            )}

            {/* ZERO-ERROR PRODUCT SCHEMES & TARGETS ENGINE */}
            <ProductSchemesManager
              product={product}
              onChange={(field, value) => {
                setProduct(prev => ({ ...prev, [field]: value }));
              }}
            />

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '24px', marginBottom: '20px' }}>
              <div>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>Lot Number</label>
                <input
                  className="premium-input"
                  type="text"
                  inputMode="numeric"
                  placeholder="e.g. 102401"
                  style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s' }}
                  value={product.lot_number || ''}
                  onKeyDown={(e) => {
                    if (
                      !/^\d$/.test(e.key) &&
                      !['Backspace', 'Delete', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Tab', 'Enter'].includes(e.key) &&
                      !e.ctrlKey &&
                      !e.metaKey
                    ) {
                      e.preventDefault();
                    }
                  }}
                  onChange={(e) => {
                    const val = e.target.value.replace(/\D/g, '');
                    setProduct({ ...product, lot_number: val });
                  }}
                />
              </div>
              <div>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>Batch Number</label>
                <input
                  className="premium-input"
                  type="text"
                  inputMode="numeric"
                  placeholder="e.g. 9901"
                  style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s' }}
                  value={product.batch_number || ''}
                  onKeyDown={(e) => {
                    if (
                      !/^\d$/.test(e.key) &&
                      !['Backspace', 'Delete', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Tab', 'Enter'].includes(e.key) &&
                      !e.ctrlKey &&
                      !e.metaKey
                    ) {
                      e.preventDefault();
                    }
                  }}
                  onChange={(e) => {
                    const val = e.target.value.replace(/\D/g, '');
                    setProduct({ ...product, batch_number: val });
                  }}
                />
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '24px' }}>
              <div>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>Manufacturing Date (MFG)</label>
                <input
                  className="premium-input"
                  type="date"
                  style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s' }}
                  value={product.manufacturing_date || ''}
                  onChange={(e) => setProduct({ ...product, manufacturing_date: e.target.value })}
                />
              </div>
              <div>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>Expiry Date (EXP)</label>
                <input
                  className="premium-input"
                  type="date"
                  style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s' }}
                  value={product.expiry_date || ''}
                  onChange={(e) => setProduct({ ...product, expiry_date: e.target.value })}
                />
              </div>
              <div>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>Best Before Date</label>
                <input
                  className="premium-input"
                  type="date"
                  style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s' }}
                  value={product.best_before_date || ''}
                  onChange={(e) => setProduct({ ...product, best_before_date: e.target.value })}
                />
              </div>
            </div>
          </div>

          {/* RACKBIN (WAREHOUSE) CARD */}
          <div className="premium-card" style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', backdropFilter: 'blur(10px)', padding: '32px', borderRadius: '16px', boxShadow: '0 10px 25px rgba(0,0,0,0.04)', marginBottom: '24px', border: '1px solid rgba(226, 232, 240, 0.8)', transition: 'all 0.3s ease' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '2px solid #f1f5f9', paddingBottom: '12px', marginBottom: '24px' }}>
              <h2 style={{ fontSize: '1.2rem', fontWeight: '600', color: '#0f172a', margin: 0 }}>Rackbin (Warehouse)</h2>
              <span style={{ fontSize: '0.85rem', color: '#64748b' }}>Warehouse Storage & Rackbin Allocation</span>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '24px', marginBottom: '20px' }}>
              <div>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>Warehouse</label>
                <select
                  className="premium-input"
                  style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s' }}
                  value={product.warehouse_location || ''}
                  onChange={(e) => {
                    const selectedWh = warehouses.find(w => w.name === e.target.value || String(w.id) === e.target.value);
                    setProduct({
                      ...product,
                      warehouse_location: selectedWh ? selectedWh.name : e.target.value,
                      default_warehouse_id: selectedWh ? selectedWh.id : (product.default_warehouse_id || null)
                    });
                  }}
                >
                  <option value="">Select Warehouse...</option>
                  {warehouses.map(w => (
                    <option key={w.id} value={w.name}>
                      {(w.warehouse_code || w.code) ? `[${w.warehouse_code || w.code}] ` : ''}{w.name} {w.is_default ? '★ (Default)' : ''} - ({w.warehouse_type || w.type || 'Warehouse'})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>Rack Number</label>
                <input
                  className="premium-input"
                  type="text"
                  placeholder="e.g. Rack A-12, R-04"
                  style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s' }}
                  value={product.rack_number || ''}
                  onChange={(e) => setProduct({ ...product, rack_number: e.target.value })}
                />
              </div>

              <div>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>Shelf Number</label>
                <input
                  className="premium-input"
                  type="text"
                  placeholder="e.g. Shelf 03, S-2"
                  style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s' }}
                  value={product.shelf_number || ''}
                  onChange={(e) => setProduct({ ...product, shelf_number: e.target.value })}
                />
              </div>

              <div>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.95rem', fontWeight: '500', marginBottom: '8px' }}>Bin Location</label>
                <input
                  className="premium-input"
                  type="text"
                  placeholder="e.g. Bin B-05, BIN-101"
                  style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', transition: 'all 0.2s' }}
                  value={product.bin_location || ''}
                  onChange={(e) => setProduct({ ...product, bin_location: e.target.value })}
                />
              </div>
            </div>

            {/* Warehouse Allocation Table if product has allocations */}
            {product.warehouse_allocations && product.warehouse_allocations.length > 0 && (
              <div style={{ marginTop: '20px', borderTop: '1px solid #e2e8f0', paddingTop: '18px' }}>
                <h4 style={{ margin: '0 0 12px 0', fontSize: '0.95rem', fontWeight: '700', color: '#334155' }}>
                  Multi-Warehouse Inventory Stock & Racking Allocations
                </h4>
                <div style={{ overflowX: 'auto' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.875rem' }}>
                    <thead>
                      <tr style={{ backgroundColor: '#f8fafc', borderBottom: '1px solid #cbd5e1', color: '#64748b', textAlign: 'left' }}>
                        <th style={{ padding: '8px 12px' }}>Warehouse</th>
                        <th style={{ padding: '8px 12px' }}>Current Stock</th>
                        <th style={{ padding: '8px 12px' }}>Opening Stock</th>
                        <th style={{ padding: '8px 12px' }}>Rack</th>
                        <th style={{ padding: '8px 12px' }}>Shelf</th>
                        <th style={{ padding: '8px 12px' }}>Bin</th>
                        <th style={{ padding: '8px 12px' }}>Primary</th>
                      </tr>
                    </thead>
                    <tbody>
                      {product.warehouse_allocations.map((alloc, idx) => (
                        <tr key={alloc.id || idx} style={{ borderBottom: '1px solid #f1f5f9' }}>
                          <td style={{ padding: '10px 12px', fontWeight: '600', color: '#0f172a' }}>
                            {alloc.warehouse?.name || `Warehouse #${alloc.warehouse_id}`}
                          </td>
                          <td style={{ padding: '10px 12px', color: '#16a34a', fontWeight: '700' }}>
                            {alloc.current_stock ?? alloc.opening_stock ?? 0}
                          </td>
                          <td style={{ padding: '10px 12px', color: '#64748b' }}>
                            {alloc.opening_stock ?? 0}
                          </td>
                          <td style={{ padding: '10px 12px' }}>{alloc.rack_number || '-'}</td>
                          <td style={{ padding: '10px 12px' }}>{alloc.shelf_number || '-'}</td>
                          <td style={{ padding: '10px 12px' }}>{alloc.bin_location || '-'}</td>
                          <td style={{ padding: '10px 12px' }}>
                            {alloc.is_primary ? (
                              <span style={{ fontSize: '0.75rem', padding: '2px 8px', borderRadius: '4px', backgroundColor: '#dcfce7', color: '#15803d', fontWeight: '600' }}>
                                Primary
                              </span>
                            ) : '-'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>

          {/* PRODUCT MEDIA / PHOTOS CARD */}
          <div className="premium-card" style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', backdropFilter: 'blur(10px)', padding: '32px', borderRadius: '16px', boxShadow: '0 10px 25px rgba(0,0,0,0.04)', marginBottom: '24px', border: '1px solid rgba(226, 232, 240, 0.8)', transition: 'all 0.3s ease' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '2px solid #f1f5f9', paddingBottom: '12px', marginBottom: '24px', flexWrap: 'wrap', gap: '8px' }}>
              <h2 style={{ fontSize: '1.2rem', fontWeight: '600', color: '#0f172a', margin: 0 }}>Product Photos</h2>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                {companyInheritedMedia?.images?.length > 0 && (
                  <button
                    type="button"
                    onClick={handleImportCompanyImages}
                    style={{
                      background: '#e0e7ff',
                      color: '#4338ca',
                      border: '1px solid #c7d2fe',
                      padding: '4px 10px',
                      borderRadius: '6px',
                      fontSize: '0.75rem',
                      fontWeight: '700',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '5px'
                    }}
                  >
                    <ImageIcon size={13} /> Import from {companyName} Gallery ({companyInheritedMedia.images.length})
                  </button>
                )}
                <span style={{ fontSize: '0.8rem', color: '#6366f1', fontWeight: '600' }}>
                  {(Array.isArray(product.images) ? product.images.length : (product.image_url ? 1 : 0))} photo(s)
                </span>
              </div>
            </div>
            <PhotoUploader
              images={Array.isArray(product.images) ? product.images : (product.image_url ? [product.image_url] : [])}
              onChange={(newImages) => {
                setProduct({
                  ...product,
                  images: newImages,
                  image_url: newImages.length > 0 ? newImages[0] : null
                });
              }}
              maxFiles={15}
            />
          </div>

          {/* PRODUCT VIDEO CARD */}
          <div className="premium-card" style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', backdropFilter: 'blur(10px)', padding: '32px', borderRadius: '16px', boxShadow: '0 10px 25px rgba(0,0,0,0.04)', marginBottom: '24px', border: '1px solid rgba(226, 232, 240, 0.8)', transition: 'all 0.3s ease' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '2px solid #f1f5f9', paddingBottom: '12px', marginBottom: '20px' }}>
              <div>
                <h2 style={{ fontSize: '1.2rem', fontWeight: '600', color: '#0f172a', margin: 0 }}>Product Video</h2>
                <p style={{ margin: '4px 0 0 0', fontSize: '0.85rem', color: '#64748b' }}>Upload video demonstration (Max 50 MB, MP4/WebM) or paste link</p>
              </div>
              <span style={{ fontSize: '0.8rem', color: '#6366f1', fontWeight: '600' }}>
                50 MB Limit
              </span>
            </div>

            {companyInheritedMedia?.videoUrl && product.video_url === companyInheritedMedia.videoUrl && (
              <div style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '6px 12px',
                backgroundColor: '#eff6ff',
                border: '1px solid #bfdbfe',
                borderRadius: '8px',
                marginBottom: '12px',
                fontSize: '0.78rem',
                color: '#1e40af',
                fontWeight: '600'
              }}>
                <span>⚡ Video Auto-Inherited from <strong>{companyName}</strong></span>
                <button
                  type="button"
                  onClick={() => setProduct({ ...product, video_url: '' })}
                  style={{
                    background: 'none',
                    border: 'none',
                    color: '#ef4444',
                    fontSize: '0.75rem',
                    fontWeight: '700',
                    cursor: 'pointer',
                    padding: 0
                  }}
                >
                  Clear Video
                </button>
              </div>
            )}

            <VideoUploader
              videoUrl={product.video_url || ''}
              onChange={(newUrl) => {
                setProduct({
                  ...product,
                  video_url: newUrl
                });
              }}
            />
          </div>

          {/* PRODUCT BROCHURE CARD */}
          <div className="premium-card" style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', backdropFilter: 'blur(10px)', padding: '32px', borderRadius: '16px', boxShadow: '0 10px 25px rgba(0,0,0,0.04)', marginBottom: '24px', border: '1px solid rgba(226, 232, 240, 0.8)', transition: 'all 0.3s ease' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '2px solid #f1f5f9', paddingBottom: '12px', marginBottom: '20px' }}>
              <div>
                <h2 style={{ fontSize: '1.2rem', fontWeight: '600', color: '#0f172a', margin: 0 }}>Company / Product Brochure PDF</h2>
                <p style={{ margin: '4px 0 0 0', fontSize: '0.85rem', color: '#64748b' }}>Digital catalog & technical datasheet</p>
              </div>
            </div>

            {companyBrochure?.url && companyBrochure.url === companyInheritedMedia?.brochureUrl && (
              <div style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '6px 12px',
                backgroundColor: '#ecfdf5',
                border: '1px solid #a7f3d0',
                borderRadius: '8px',
                marginBottom: '12px',
                fontSize: '0.78rem',
                color: '#065f46',
                fontWeight: '600'
              }}>
                <span>⚡ Brochure Auto-Inherited from <strong>{companyName}</strong></span>
                <button
                  type="button"
                  onClick={() => setCompanyBrochure({ url: '', name: '', isInherited: false })}
                  style={{
                    background: 'none',
                    border: 'none',
                    color: '#ef4444',
                    fontSize: '0.75rem',
                    fontWeight: '700',
                    cursor: 'pointer',
                    padding: 0
                  }}
                >
                  Clear Brochure
                </button>
              </div>
            )}

            <BrochureUploader
              brochureUrl={companyBrochure.url}
              brochureName={companyBrochure.name}
              onChange={setCompanyBrochure}
            />
          </div>

          {/* INVENTORY CONTROL & REORDER ENGINE CARD */}
          <div className="premium-card" style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', backdropFilter: 'blur(10px)', padding: '32px', borderRadius: '16px', boxShadow: '0 10px 25px rgba(0,0,0,0.04)', marginBottom: '32px', border: '1px solid rgba(226, 232, 240, 0.8)', transition: 'all 0.3s ease' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '2px solid #f1f5f9', paddingBottom: '16px', marginBottom: '24px', flexWrap: 'wrap', gap: '12px' }}>
              <div>
                <h2 style={{ fontSize: '1.25rem', fontWeight: '700', color: '#0f172a', margin: 0 }}>Inventory Control & Reorder Intelligence</h2>
                <p style={{ margin: '4px 0 0 0', fontSize: '0.85rem', color: '#64748b' }}>Configure automatic safety thresholds, lead times, and calculation rules</p>
              </div>

              {/* Dynamic Status Badge */}
              {(() => {
                const cur = parseInt(product.purchase_quantity || 0, 10);
                const rLevel = parseInt(product.reorder_level || 0, 10);
                const sStock = parseInt(product.safety_stock || 0, 10);
                let badgeLabel = 'NORMAL';
                let badgeBg = '#dcfce7';
                let badgeColor = '#15803d';

                if (cur <= 0 || (sStock > 0 && cur <= Math.floor(sStock / 2))) {
                  badgeLabel = 'CRITICAL STOCK';
                  badgeBg = '#fee2e2';
                  badgeColor = '#b91c1c';
                } else if (cur <= rLevel) {
                  badgeLabel = 'LOW STOCK';
                  badgeBg = '#fef3c7';
                  badgeColor = '#d97706';
                }

                return (
                  <span style={{ padding: '6px 14px', borderRadius: '999px', fontWeight: '800', fontSize: '0.85rem', backgroundColor: badgeBg, color: badgeColor, letterSpacing: '0.05em' }}>
                    ● {badgeLabel}
                  </span>
                );
              })()}
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '20px', marginBottom: '24px' }}>
              {/* Current Stock (Read-Only) */}
              <div>
                <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>Current Stock (Read-Only)</label>
                <div style={{ padding: '12px 16px', borderRadius: '8px', backgroundColor: '#f1f5f9', border: '1px solid #cbd5e1', fontWeight: '800', fontSize: '1.1rem', color: '#0f172a' }}>
                  {product.purchase_quantity || 0} <span style={{ fontSize: '0.8rem', fontWeight: '500', color: '#64748b' }}>units</span>
                </div>
              </div>

              {/* Minimum Stock */}
              <div>
                <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>Minimum Stock</label>
                <input
                  className="premium-input"
                  type="number"
                  min="0"
                  step="1"
                  style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                  value={product.min_stock_level || ''}
                  onChange={(e) => setProduct({ ...product, min_stock_level: e.target.value })}
                  placeholder="e.g. 5"
                />
              </div>

              {/* Maximum Stock */}
              <div>
                <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>Maximum Stock</label>
                <input
                  className="premium-input"
                  type="number"
                  min="0"
                  step="1"
                  style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                  value={product.max_stock_level || ''}
                  onChange={(e) => setProduct({ ...product, max_stock_level: e.target.value })}
                  placeholder="e.g. 100"
                />
              </div>

              {/* Safety Stock */}
              <div>
                <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>Safety Stock (Buffer)</label>
                <input
                  className="premium-input"
                  type="number"
                  min="0"
                  step="1"
                  style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                  value={product.safety_stock || ''}
                  onChange={(e) => setProduct({ ...product, safety_stock: e.target.value })}
                  placeholder="e.g. 10"
                />
              </div>

              {/* Lead Time Days */}
              <div>
                <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>Supplier Lead Time (Days)</label>
                <input
                  className="premium-input"
                  type="number"
                  min="1"
                  step="1"
                  style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                  value={product.lead_time_days || ''}
                  onChange={(e) => setProduct({ ...product, lead_time_days: e.target.value })}
                  placeholder="e.g. 7"
                />
              </div>
            </div>

            {/* Reorder Level & Quantity with Auto-Calculate Actions */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '20px', padding: '20px', borderRadius: '12px', backgroundColor: '#f8fafc', border: '1px solid #e2e8f0', marginBottom: '24px' }}>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                  <label style={{ color: '#0f172a', fontSize: '0.85rem', fontWeight: '700', textTransform: 'uppercase' }}>Reorder Level *</label>
                  <button
                    type="button"
                    onClick={handleAutoCalculateReorder}
                    style={{ background: 'none', border: 'none', color: '#4338ca', fontSize: '0.8rem', fontWeight: '700', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px' }}
                  >
                    ⚡ Auto Calculate
                  </button>
                </div>
                <input
                  className="premium-input"
                  type="number"
                  required
                  min="0"
                  step="1"
                  style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#fff', color: '#1e293b', fontWeight: '700', outline: 'none' }}
                  value={product.reorder_level || ''}
                  onChange={(e) => setProduct({ ...product, reorder_level: e.target.value })}
                />
                <p style={{ margin: '6px 0 0 0', fontSize: '0.75rem', color: '#64748b' }}>Formula: (Avg Daily Sales × Lead Time) + Safety Stock</p>
              </div>

              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                  <label style={{ color: '#0f172a', fontSize: '0.85rem', fontWeight: '700', textTransform: 'uppercase' }}>Reorder Quantity</label>
                  <button
                    type="button"
                    onClick={handleAutoCalculateReorder}
                    style={{ background: 'none', border: 'none', color: '#4338ca', fontSize: '0.8rem', fontWeight: '700', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px' }}
                  >
                    ⚡ Auto Calculate
                  </button>
                </div>
                <input
                  className="premium-input"
                  type="number"
                  min="0"
                  step="1"
                  style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#fff', color: '#1e293b', fontWeight: '700', outline: 'none' }}
                  value={product.reorder_qty || ''}
                  onChange={(e) => setProduct({ ...product, reorder_qty: e.target.value })}
                  placeholder="e.g. 50"
                />
                <p style={{ margin: '6px 0 0 0', fontSize: '0.75rem', color: '#64748b' }}>Formula: Max Stock Level - Current Stock</p>
              </div>

              {/* Auto Reorder Switch */}
              <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer', marginTop: '10px' }}>
                  <input
                    type="checkbox"
                    checked={product.auto_reorder || false}
                    onChange={(e) => setProduct({ ...product, auto_reorder: e.target.checked })}
                    style={{ width: '20px', height: '20px', accentColor: '#4338ca' }}
                  />
                  <div>
                    <span style={{ fontWeight: '700', color: '#0f172a', fontSize: '0.9rem' }}>Auto-Reorder Drafting</span>
                    <p style={{ margin: '2px 0 0 0', fontSize: '0.75rem', color: '#64748b' }}>Automatically draft Purchase Requests when stock drops below ROL</p>
                  </div>
                </label>
              </div>
            </div>

            {/* Reorder Note */}
            <div>
              <label style={{ display: 'block', color: '#475569', fontSize: '0.9rem', fontWeight: '600', marginBottom: '8px' }}>Reorder Note & Procurement Instructions</label>
              <textarea
                className="premium-input"
                style={{ width: '100%', padding: '12px 16px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', minHeight: '75px', resize: 'vertical' }}
                value={product.reorder_note || ''}
                onChange={(e) => setProduct({ ...product, reorder_note: e.target.value })}
                placeholder="e.g., Only order from primary supplier in bulk batches of 50..."
              />
            </div>
          </div>

          <div style={{ position: 'sticky', bottom: '24px', zIndex: 10, display: 'flex', justifyContent: 'flex-end', gap: '16px', marginTop: '24px', backgroundColor: 'rgba(255,255,255,0.85)', backdropFilter: 'blur(12px)', padding: '16px 24px', borderRadius: '12px', boxShadow: '0 -4px 20px rgba(0,0,0,0.03), 0 4px 10px rgba(0,0,0,0.05)', border: '1px solid rgba(255,255,255,0.4)' }}>
            <button type="button" onClick={() => navigate('/products')} style={{ padding: '12px 24px', border: '1px solid #cbd5e1', backgroundColor: '#fff', color: '#475569', borderRadius: '8px', cursor: 'pointer', fontWeight: '600', transition: 'all 0.2s', fontSize: '0.95rem' }} onMouseOver={e => e.currentTarget.style.backgroundColor = '#f8fafc'} onMouseOut={e => e.currentTarget.style.backgroundColor = '#fff'}>Cancel</button>
            <button type="submit" style={{ padding: '12px 28px', border: 'none', backgroundColor: '#3b82f6', color: 'white', borderRadius: '8px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px', fontWeight: '600', transition: 'all 0.2s', boxShadow: '0 4px 12px rgba(59, 130, 246, 0.3)', fontSize: '0.95rem' }} onMouseOver={e => { e.currentTarget.style.backgroundColor = '#2563eb'; e.currentTarget.style.transform = 'translateY(-1px)'; }} onMouseOut={e => { e.currentTarget.style.backgroundColor = '#3b82f6'; e.currentTarget.style.transform = 'translateY(0)'; }}>
              <Save size={18} /> Save Changes
            </button>
          </div>
        </form>
        {showAddCompanyModal && (
          <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1100 }}>
            <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '8px', width: '520px', maxWidth: '95vw', maxHeight: '90vh', overflowY: 'auto', position: 'relative' }}>
              <button type="button" onClick={() => setShowAddCompanyModal(false)} style={{ position: 'absolute', top: '16px', right: '16px', background: 'transparent', border: 'none', fontSize: '24px', cursor: 'pointer', color: '#7f8c8d' }}>&times;</button>
              <h2 style={{ marginTop: 0, marginBottom: '20px', color: '#2c3e50', fontSize: '1.25rem' }}>Add Company</h2>
              <form onSubmit={submitNewCompany}>
                <div style={{ marginBottom: '14px' }}>
                  <label style={{ display: 'block', color: '#000', fontSize: '0.9rem', fontWeight: '600', marginBottom: '6px' }}>Company Name *</label>
                  <input type="text" required placeholder="e.g. Acme Corp" style={{ width: '100%', padding: '10px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalCompanyName} onChange={e => setModalCompanyName(e.target.value)} />
                </div>
                <div style={{ marginBottom: '14px' }}>
                  <label style={{ display: 'block', color: '#475569', fontSize: '0.85rem', fontWeight: '600', marginBottom: '6px' }}>Brand Name</label>
                  <input type="text" placeholder="e.g. Acme, Nike" style={{ width: '100%', padding: '10px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalBrandName} onChange={e => setModalBrandName(e.target.value)} />
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '14px' }}>
                  <div>
                    <label style={{ display: 'block', color: '#475569', fontSize: '0.85rem', fontWeight: '600', marginBottom: '6px' }}>Scheme</label>
                    <input type="text" placeholder="e.g. Annual Turnover Scheme" style={{ width: '100%', padding: '9px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalCompanyScheme} onChange={e => setModalCompanyScheme(e.target.value)} />
                  </div>
                  <div>
                    <label style={{ display: 'block', color: '#475569', fontSize: '0.85rem', fontWeight: '600', marginBottom: '6px' }}>Offer</label>
                    <input type="text" placeholder="e.g. 5% Trade Discount" style={{ width: '100%', padding: '9px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalCompanyOffer} onChange={e => setModalCompanyOffer(e.target.value)} />
                  </div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '14px' }}>
                  <div>
                    <label style={{ display: 'block', color: '#475569', fontSize: '0.85rem', fontWeight: '600', marginBottom: '6px' }}>Margin (%)</label>
                    <input type="text" placeholder="e.g. 20%" style={{ width: '100%', padding: '9px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalCompanyMargin} onChange={e => setModalCompanyMargin(e.target.value)} />
                  </div>
                  <div>
                    <label style={{ display: 'block', color: '#475569', fontSize: '0.85rem', fontWeight: '600', marginBottom: '6px' }}>Authorized Distributor</label>
                    <input type="text" placeholder="e.g. Primus Wholesale" style={{ width: '100%', padding: '9px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalCompanyDistributor} onChange={e => setModalCompanyDistributor(e.target.value)} />
                  </div>
                </div>
                <div style={{ marginBottom: '14px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                    <label style={{ display: 'block', color: '#475569', fontSize: '0.85rem', fontWeight: '600', margin: 0 }}>Company Officer Name(s)</label>
                    <span style={{ fontSize: '0.75rem', color: '#64748b' }}>{modalCompanyOfficers.filter(o => o.trim()).length} officer(s)</span>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    {modalCompanyOfficers.map((officer, index) => (
                      <div key={index} style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                        <input
                          type="text"
                          placeholder="e.g. Robert Smith (Director of Operations)"
                          style={{ flex: 1, padding: '9px 12px', border: '1px solid #bdc3c7', borderRadius: '4px', fontSize: '0.9rem' }}
                          value={officer}
                          onChange={(e) => handleModalOfficerChange(index, e.target.value)}
                        />
                        {(modalCompanyOfficers.length > 1 || officer.trim() !== '') && (
                          <button
                            type="button"
                            onClick={() => handleModalRemoveOfficer(index)}
                            style={{
                              padding: '9px 12px',
                              backgroundColor: '#fee2e2',
                              color: '#b91c1c',
                              border: '1px solid #fecaca',
                              borderRadius: '4px',
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              fontSize: '0.85rem',
                              fontWeight: '600'
                            }}
                            title="Remove officer"
                          >
                            <Trash2 size={16} />
                          </button>
                        )}
                      </div>
                    ))}
                    <button
                      type="button"
                      onClick={handleModalAddOfficer}
                      style={{
                        marginTop: '4px',
                        padding: '8px 12px',
                        backgroundColor: '#f8fafc',
                        color: '#4338ca',
                        border: '1px dashed #cbd5e1',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        display: 'inline-flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: '6px',
                        fontSize: '0.82rem',
                        fontWeight: '600'
                      }}
                    >
                      <Plus size={15} /> Add Another Officer
                    </button>
                  </div>
                </div>
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ display: 'block', color: '#000', fontSize: '0.9rem', fontWeight: '600', marginBottom: '6px' }}>Description</label>
                  <textarea style={{ width: '100%', padding: '10px', border: '1px solid #bdc3c7', borderRadius: '4px' }} rows="2" placeholder="Optional notes..." value={modalCompanyDesc} onChange={e => setModalCompanyDesc(e.target.value)}></textarea>
                </div>
                <div style={{ marginBottom: '16px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                    <label style={{ display: 'block', color: '#000', fontSize: '0.85rem', fontWeight: '600', margin: 0 }}>Company Brochure Images (Multiple)</label>
                    <span style={{ fontSize: '0.75rem', color: '#64748b' }}>{modalCompanyBrochures.length} image(s)</span>
                  </div>
                  <PhotoUploader images={modalCompanyBrochures} onChange={setModalCompanyBrochures} maxFiles={15} compact={true} />
                </div>
                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
                  <button type="button" onClick={() => { setShowAddCompanyModal(false); setModalCompanyBrochures([]); }} style={{ padding: '10px 16px', backgroundColor: '#ecf0f1', color: '#2c3e50', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Cancel</button>
                  <button type="submit" style={{ padding: '10px 16px', backgroundColor: '#3498db', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Save Company</button>
                </div>
              </form>
            </div>
          </div>
        )}

        {showAddBrandModal && (
          <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1100 }}>
            <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '8px', width: '520px', maxWidth: '95vw', maxHeight: '90vh', overflowY: 'auto', position: 'relative' }}>
              <button type="button" onClick={() => setShowAddBrandModal(false)} style={{ position: 'absolute', top: '16px', right: '16px', background: 'transparent', border: 'none', fontSize: '24px', cursor: 'pointer', color: '#7f8c8d' }}>&times;</button>
              <h2 style={{ marginTop: 0, marginBottom: '20px', color: '#2c3e50', fontSize: '1.25rem' }}>Add Brand</h2>
              <form onSubmit={submitNewBrand}>
                <div style={{ marginBottom: '14px' }}>
                  <label style={{ display: 'block', color: '#000', fontSize: '0.9rem', fontWeight: '600', marginBottom: '6px' }}>Brand Name *</label>
                  <input type="text" required placeholder="e.g. Nike, Samsung" style={{ width: '100%', padding: '10px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalBrandName} onChange={e => setModalBrandName(e.target.value)} />
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '14px' }}>
                  <div>
                    <label style={{ display: 'block', color: '#475569', fontSize: '0.85rem', fontWeight: '600', marginBottom: '6px' }}>Scheme</label>
                    <input type="text" placeholder="e.g. Buy 10 Get 1" style={{ width: '100%', padding: '9px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalBrandScheme} onChange={e => setModalBrandScheme(e.target.value)} />
                  </div>
                  <div>
                    <label style={{ display: 'block', color: '#475569', fontSize: '0.85rem', fontWeight: '600', marginBottom: '6px' }}>Offer</label>
                    <input type="text" placeholder="e.g. 5% Festive Discount" style={{ width: '100%', padding: '9px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalBrandOffer} onChange={e => setModalBrandOffer(e.target.value)} />
                  </div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '14px' }}>
                  <div>
                    <label style={{ display: 'block', color: '#475569', fontSize: '0.85rem', fontWeight: '600', marginBottom: '6px' }}>Margin (%)</label>
                    <input type="text" placeholder="e.g. 15%" style={{ width: '100%', padding: '9px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalBrandMargin} onChange={e => setModalBrandMargin(e.target.value)} />
                  </div>
                  <div>
                    <label style={{ display: 'block', color: '#475569', fontSize: '0.85rem', fontWeight: '600', marginBottom: '6px' }}>Authorized Distributor</label>
                    <input type="text" placeholder="e.g. Apex Distributors" style={{ width: '100%', padding: '9px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalBrandDistributor} onChange={e => setModalBrandDistributor(e.target.value)} />
                  </div>
                </div>
                <div style={{ marginBottom: '14px' }}>
                  <label style={{ display: 'block', color: '#475569', fontSize: '0.85rem', fontWeight: '600', marginBottom: '6px' }}>Company Officer Name</label>
                  <input type="text" placeholder="e.g. John Doe" style={{ width: '100%', padding: '9px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalBrandOfficer} onChange={e => setModalBrandOfficer(e.target.value)} />
                </div>
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ display: 'block', color: '#000', fontSize: '0.9rem', fontWeight: '600', marginBottom: '6px' }}>Description</label>
                  <textarea style={{ width: '100%', padding: '10px', border: '1px solid #bdc3c7', borderRadius: '4px' }} rows="2" placeholder="Optional notes..." value={modalBrandDesc} onChange={e => setModalBrandDesc(e.target.value)}></textarea>
                </div>
                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
                  <button type="button" onClick={() => setShowAddBrandModal(false)} style={{ padding: '10px 16px', backgroundColor: '#ecf0f1', color: '#2c3e50', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Cancel</button>
                  <button type="submit" style={{ padding: '10px 16px', backgroundColor: '#3498db', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Save Brand</button>
                </div>
              </form>
            </div>
          </div>
        )}

        {showAddGroupModal && (
          <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1100, padding: '16px' }}>
            <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '8px', width: '520px', maxWidth: '95vw', maxHeight: '90vh', overflowY: 'auto', position: 'relative', boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.2)' }}>
              <button type="button" onClick={() => { setShowAddGroupModal(false); setModalGroupImages([]); }} style={{ position: 'absolute', top: '16px', right: '16px', background: 'transparent', border: 'none', fontSize: '24px', cursor: 'pointer', color: '#7f8c8d' }}>&times;</button>
              <h2 style={{ marginTop: 0, marginBottom: '20px', color: '#2c3e50', fontSize: '1.25rem' }}>Add Product Group</h2>
              <form onSubmit={submitNewGroup}>
                <div style={{ marginBottom: '16px' }}>
                  <label style={{ display: 'block', color: '#000', fontSize: '1rem', marginBottom: '6px' }}>Group Name *</label>
                  <input type="text" required style={{ width: '100%', padding: '10px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalGroupName} onChange={e => setModalGroupName(e.target.value)} />
                </div>
                <div style={{ marginBottom: '16px' }}>
                  <label style={{ display: 'block', color: '#000', fontSize: '1rem', marginBottom: '6px' }}>Description</label>
                  <textarea style={{ width: '100%', padding: '10px', border: '1px solid #bdc3c7', borderRadius: '4px' }} rows="3" value={modalGroupDesc} onChange={e => setModalGroupDesc(e.target.value)}></textarea>
                </div>

                {/* GROUP IMAGES FIELD (MULTIPLE) */}
                <div style={{ marginBottom: '20px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                    <label style={{ display: 'block', color: '#000', fontSize: '0.95rem', fontWeight: '600', margin: 0 }}>Group Images (Optional)</label>
                    <span style={{ fontSize: '0.8rem', color: '#64748b' }}>{modalGroupImages.length} photo(s) selected</span>
                  </div>
                  <PhotoUploader images={modalGroupImages} onChange={setModalGroupImages} maxFiles={10} compact={true} />
                </div>

                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
                  <button type="button" onClick={() => { setShowAddGroupModal(false); setModalGroupImages([]); }} style={{ padding: '10px 16px', backgroundColor: '#ecf0f1', color: '#2c3e50', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Cancel</button>
                  <button type="submit" style={{ padding: '10px 16px', backgroundColor: '#3498db', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Save Group</button>
                </div>
              </form>
            </div>
          </div>
        )}



        {showAddOccasionModal && (
          <AddOccasionModal
            isOpen={showAddOccasionModal}
            onClose={() => setShowAddOccasionModal(false)}
            defaultType={selectedOccasionType || 'Festival'}
            onOccasionAdded={(newOcc) => {
              fetchOccasions();
              if (newOcc && newOcc.id) {
                setSelectedOccasionId(newOcc.id);
                if (newOcc.occasion_type) {
                  setSelectedOccasionType(newOcc.occasion_type);
                }
              }
            }}
          />
        )}

      </div>
    </div>
  );
};

export default ProductDetails;
