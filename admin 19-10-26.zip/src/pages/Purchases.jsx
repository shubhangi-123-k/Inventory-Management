import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import api from '../api/axios';
import SearchAutocomplete from '../components/SearchAutocomplete';
import { 
  FileText, 
  ShoppingCart, 
  CheckCircle, 
  Clock, 
  AlertTriangle, 
  ArrowRight, 
  RefreshCw,
  Plus,
  Building2,
  Truck,
  UserCheck,
  Percent,
  Tag,
  X
} from 'lucide-react';

const Purchases = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialTab = searchParams.get('tab') === 'requests' ? 'requests' : 'orders';
  
  const [activeMainTab, setActiveMainTab] = useState(initialTab);
  const [purchases, setPurchases] = useState([]);
  const [purchaseRequests, setPurchaseRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingRequests, setLoadingRequests] = useState(true);
  
  // Modal states for manual PO creation
  const [showModal, setShowModal] = useState(searchParams.get('action') === 'new');
  const [suppliers, setSuppliers] = useState([]);
  const [products, setProducts] = useState([]);
  const [convertingPrId, setConvertingPrId] = useState(null);
  const [actionSuccessMsg, setActionSuccessMsg] = useState('');
  
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    supplier_id: '',
    bill_num: '',
    pmt_status: 'Pending',
    shipping_status: 'Pending',
    total_paid: 0,
    details: [{ product_id: '', qty: 1, price: 0 }]
  });

  const fetchPurchases = async () => {
    try {
      setLoading(true);
      const response = await api.get('/admin/purchases');
      if (response.data.success) {
        setPurchases(response.data.data);
      }
    } catch (error) {
      console.error('Failed to fetch purchases:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchPurchaseRequests = async () => {
    try {
      setLoadingRequests(true);
      const response = await api.get('/purchase-requests');
      if (response.data.success) {
        setPurchaseRequests(response.data.data || []);
      }
    } catch (error) {
      console.error('Failed to fetch purchase requests:', error);
    } finally {
      setLoadingRequests(false);
    }
  };

  const fetchSuppliersAndProducts = async () => {
    try {
      const [supRes, prodRes] = await Promise.all([
        api.get('/admin/suppliers').catch(() => ({ data: { data: [] }})),
        api.get('/admin/products').catch(() => ({ data: { data: [] }}))
      ]);
      if (supRes.data?.data) setSuppliers(supRes.data.data);
      if (prodRes.data?.data) setProducts(prodRes.data.data);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    fetchPurchases();
    fetchPurchaseRequests();
    fetchSuppliersAndProducts();
  }, []);

  const handleConvertToPO = async (pr) => {
    try {
      setConvertingPrId(pr.id);
      const res = await api.post(`/purchase-requests/${pr.id}/convert-to-po`, {
        notes: `Converted directly from Purchase Request ${pr.pr_number}`
      });
      if (res.data?.success) {
        setActionSuccessMsg(`Purchase Request ${pr.pr_number} successfully converted to official Purchase Order!`);
        setTimeout(() => setActionSuccessMsg(''), 5000);
        fetchPurchaseRequests();
        fetchPurchases();
      }
    } catch (err) {
      console.error('Error converting PR to PO:', err);
      alert(err.response?.data?.message || 'Failed to convert Purchase Request to PO');
    } finally {
      setConvertingPrId(null);
    }
  };

  const handleDetailChange = (index, field, value) => {
    const newDetails = [...formData.details];
    newDetails[index][field] = value;
    setFormData({ ...formData, details: newDetails });
  };

  const addDetailRow = () => {
    setFormData({
      ...formData,
      details: [...formData.details, { product_id: '', qty: 1, price: 0 }]
    });
  };

  const removeDetailRow = (index) => {
    const newDetails = formData.details.filter((_, i) => i !== index);
    setFormData({ ...formData, details: newDetails });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const total_amount = formData.details.reduce((sum, d) => sum + (parseFloat(d.qty) * parseFloat(d.price)), 0);
      
      const payload = {
        ...formData,
        total_amount,
        details: formData.details.filter(d => d.product_id && d.qty > 0)
      };

      const res = await api.post('/admin/purchases', payload);
      if (res.data.success) {
        setShowModal(false);
        fetchPurchases();
      }
    } catch (error) {
      console.error('Error submitting PO:', error);
      alert('Failed to create Purchase Order');
    }
  };

  const calculateTotal = () => {
    return formData.details.reduce((sum, d) => sum + ((parseFloat(d.qty)||0) * (parseFloat(d.price)||0)), 0).toFixed(2);
  };

  const draftCount = purchaseRequests.filter(pr => pr.status === 'Draft').length;
  const selectedSupplier = suppliers.find(s => String(s.id) === String(formData.supplier_id));

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* HEADER & TOP CONTROLS */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <h1 style={{ fontSize: '1.75rem', fontWeight: '800', color: '#0f172a', margin: 0 }}>
            Procurement & Purchase Management
          </h1>
          <p style={{ margin: '4px 0 0 0', color: '#64748b', fontSize: '0.95rem' }}>
            Manage supplier purchase orders and approve automated reorder purchase requests
          </p>
        </div>

        <div style={{ display: 'flex', gap: '10px' }}>
          <button 
            onClick={() => setShowModal(true)} 
            className="btn btn-primary"
            style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 18px', fontWeight: '600' }}
          >
            <Plus size={18} /> New Purchase Order
          </button>
          <button 
            onClick={() => { fetchPurchases(); fetchPurchaseRequests(); }}
            style={{ padding: '10px 14px', borderRadius: '8px', border: '1px solid #cbd5e1', backgroundColor: '#fff', cursor: 'pointer', display: 'flex', alignItems: 'center', color: '#475569' }}
            title="Refresh"
          >
            <RefreshCw size={18} />
          </button>
        </div>
      </div>

      {/* TOAST SUCCESS MESSAGE */}
      {actionSuccessMsg && (
        <div style={{ padding: '12px 18px', borderRadius: '8px', backgroundColor: '#dcfce7', border: '1px solid #86efac', color: '#15803d', display: 'flex', alignItems: 'center', gap: '10px', fontWeight: '600' }}>
          <CheckCircle size={20} />
          <span>{actionSuccessMsg}</span>
        </div>
      )}

      {/* MAIN NAVIGATION TABS */}
      <div style={{ display: 'flex', gap: '12px', borderBottom: '2px solid #e2e8f0', paddingBottom: '2px' }}>
        <button
          onClick={() => { setActiveMainTab('orders'); setSearchParams({}); }}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            padding: '12px 20px',
            border: 'none',
            borderBottom: activeMainTab === 'orders' ? '3px solid #3b82f6' : '3px solid transparent',
            backgroundColor: 'transparent',
            color: activeMainTab === 'orders' ? '#3b82f6' : '#64748b',
            fontWeight: '700',
            fontSize: '1rem',
            cursor: 'pointer',
            marginBottom: '-2px'
          }}
        >
          <FileText size={18} />
          <span>Official Purchase Orders</span>
          <span style={{ padding: '2px 8px', borderRadius: '999px', fontSize: '0.75rem', backgroundColor: activeMainTab === 'orders' ? '#3b82f6' : '#e2e8f0', color: activeMainTab === 'orders' ? '#fff' : '#475569' }}>
            {purchases.length}
          </span>
        </button>

        <button
          onClick={() => { setActiveMainTab('requests'); setSearchParams({ tab: 'requests' }); }}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            padding: '12px 20px',
            border: 'none',
            borderBottom: activeMainTab === 'requests' ? '3px solid #8b5cf6' : '3px solid transparent',
            backgroundColor: 'transparent',
            color: activeMainTab === 'requests' ? '#8b5cf6' : '#64748b',
            fontWeight: '700',
            fontSize: '1rem',
            cursor: 'pointer',
            marginBottom: '-2px'
          }}
        >
          <ShoppingCart size={18} />
          <span>Draft Purchase Requests</span>
          <span style={{ padding: '2px 8px', borderRadius: '999px', fontSize: '0.75rem', backgroundColor: activeMainTab === 'requests' ? '#8b5cf6' : '#e2e8f0', color: activeMainTab === 'requests' ? '#fff' : '#475569' }}>
            {draftCount} Pending
          </span>
        </button>
      </div>

      {/* VIEW 1: PURCHASE REQUESTS (DRAFTS CREATED FROM REORDER ENGINE) */}
      {activeMainTab === 'requests' && (
        <div className="table-container" style={{ margin: 0 }}>
          <div style={{ padding: '16px 20px', borderBottom: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <h2 style={{ fontSize: '1.1rem', fontWeight: '700', margin: 0, color: '#0f172a' }}>Reorder Purchase Requests</h2>
              <p style={{ margin: '2px 0 0 0', fontSize: '0.85rem', color: '#64748b' }}>
                Non-binding procurement drafts generated automatically from low stock alerts or manual inventory requests
              </p>
            </div>
          </div>
          <table>
            <thead>
              <tr>
                <th>PR Number</th>
                <th>Request Date</th>
                <th>Warehouse</th>
                <th>Requested Products & Quantity</th>
                <th>Total Est. Amount</th>
                <th>Priority</th>
                <th>Status</th>
                <th style={{ textAlign: 'right' }}>Action</th>
              </tr>
            </thead>
            <tbody>
              {loadingRequests ? (
                <tr><td colSpan="8" style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>Loading purchase requests...</td></tr>
              ) : purchaseRequests.length > 0 ? (
                purchaseRequests.map(pr => {
                  const isDraft = pr.status === 'Draft';
                  const isConverted = pr.status === 'Converted_to_PO';

                  return (
                    <tr key={pr.id}>
                      <td style={{ fontWeight: '700', color: '#8b5cf6' }}>{pr.pr_number}</td>
                      <td>{pr.request_date}</td>
                      <td>{pr.warehouse?.name || 'Central Facility'}</td>
                      <td>
                        {pr.items && pr.items.length > 0 ? (
                          <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                            {pr.items.map(item => (
                              <div key={item.id} style={{ fontSize: '0.85rem' }}>
                                <strong>{item.product?.name || `Product #${item.product_id}`}</strong>: <span style={{ color: '#4338ca', fontWeight: '700' }}>{item.required_qty} units</span>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <span style={{ color: '#94a3b8' }}>No items listed</span>
                        )}
                      </td>
                      <td style={{ fontWeight: '700' }}>
                        ${parseFloat(pr.total_estimated_amount || 0).toFixed(2)}
                      </td>
                      <td>
                        <span style={{ 
                          padding: '3px 8px', 
                          borderRadius: '6px', 
                          fontSize: '0.75rem', 
                          fontWeight: '700',
                          backgroundColor: pr.priority === 'Critical' ? '#fee2e2' : '#f1f5f9',
                          color: pr.priority === 'Critical' ? '#b91c1c' : '#334155'
                        }}>
                          {pr.priority || 'Medium'}
                        </span>
                      </td>
                      <td>
                        <span style={{
                          padding: '4px 10px',
                          borderRadius: '999px',
                          fontSize: '0.75rem',
                          fontWeight: '700',
                          backgroundColor: isConverted ? '#dcfce7' : '#fef3c7',
                          color: isConverted ? '#15803d' : '#d97706'
                        }}>
                          {isConverted ? 'Converted to PO' : pr.status}
                        </span>
                      </td>
                      <td style={{ textAlign: 'right' }}>
                        {isDraft ? (
                          <button
                            onClick={() => handleConvertToPO(pr)}
                            disabled={convertingPrId === pr.id}
                            className="btn btn-primary"
                            style={{
                              display: 'inline-flex',
                              alignItems: 'center',
                              gap: '6px',
                              padding: '7px 14px',
                              fontSize: '0.8rem',
                              fontWeight: '600',
                              backgroundColor: '#10b981',
                              color: '#fff',
                              border: 'none',
                              borderRadius: '6px',
                              cursor: 'pointer'
                            }}
                          >
                            <ShoppingCart size={14} />
                            {convertingPrId === pr.id ? 'Converting...' : 'Convert to PO'}
                          </button>
                        ) : (
                          <span style={{ color: '#10b981', display: 'inline-flex', alignItems: 'center', gap: '4px', fontSize: '0.85rem', fontWeight: '600' }}>
                            <CheckCircle size={15} /> PO Generated
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan="8" style={{ textAlign: 'center', padding: '36px', color: '#64748b' }}>
                    No pending draft purchase requests. When stock drops below reorder level, click "Generate PR" in Inventory to create one!
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* VIEW 2: OFFICIAL PURCHASE ORDERS TABLE */}
      {activeMainTab === 'orders' && (
        <div style={{ backgroundColor: 'white', borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th style={{ backgroundColor: '#1e293b', color: 'white', padding: '14px 16px', textAlign: 'left', fontWeight: '600' }}>Date</th>
                <th style={{ backgroundColor: '#1e293b', color: 'white', padding: '14px 16px', textAlign: 'left', fontWeight: '600' }}>PO Number</th>
                <th style={{ backgroundColor: '#1e293b', color: 'white', padding: '14px 16px', textAlign: 'left', fontWeight: '600' }}>Supplier</th>
                <th style={{ backgroundColor: '#1e293b', color: 'white', padding: '14px 16px', textAlign: 'left', fontWeight: '600' }}>Total Amount</th>
                <th style={{ backgroundColor: '#1e293b', color: 'white', padding: '14px 16px', textAlign: 'left', fontWeight: '600' }}>Total Paid</th>
                <th style={{ backgroundColor: '#1e293b', color: 'white', padding: '14px 16px', textAlign: 'left', fontWeight: '600' }}>PMT Status</th>
                <th style={{ backgroundColor: '#1e293b', color: 'white', padding: '14px 16px', textAlign: 'left', fontWeight: '600' }}>Shipping Status</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan="7" style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>Loading Purchase Orders...</td></tr>
              ) : purchases.length > 0 ? (
                purchases.map((po) => (
                  <tr key={po.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
                    <td style={{ padding: '12px 16px', color: '#334155' }}>{po.date}</td>
                    <td style={{ padding: '12px 16px', fontWeight: '700', color: '#3b82f6' }}>{po.po_number || po.po_id}</td>
                    <td style={{ padding: '12px 16px', color: '#334155' }}>{po.supplier?.name || po.Supplier?.name || 'Standard Supplier'}</td>
                    <td style={{ padding: '12px 16px', fontWeight: '700', color: '#0f172a' }}>${parseFloat(po.total_amount || 0).toFixed(2)}</td>
                    <td style={{ padding: '12px 16px', color: '#334155' }}>${parseFloat(po.total_paid || 0).toFixed(2)}</td>
                    <td style={{ padding: '12px 16px' }}>
                      <span style={{ 
                        padding: '3px 8px', 
                        borderRadius: '6px', 
                        fontSize: '0.75rem', 
                        fontWeight: '700',
                        backgroundColor: po.pmt_status === 'Paid' ? '#dcfce7' : '#fef3c7',
                        color: po.pmt_status === 'Paid' ? '#15803d' : '#d97706'
                      }}>
                        {po.pmt_status}
                      </span>
                    </td>
                    <td style={{ padding: '12px 16px' }}>
                      <span style={{ 
                        padding: '3px 8px', 
                        borderRadius: '6px', 
                        fontSize: '0.75rem', 
                        fontWeight: '700',
                        backgroundColor: po.shipping_status === 'Received' ? '#dcfce7' : '#e0e7ff',
                        color: po.shipping_status === 'Received' ? '#15803d' : '#4338ca'
                      }}>
                        {po.shipping_status}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>No Purchase Orders recorded yet.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* CREATE NEW PURCHASE ORDER MODAL */}
      {showModal && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(15, 23, 42, 0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, backdropFilter: 'blur(3px)' }}>
          <div style={{ backgroundColor: 'white', padding: '28px', borderRadius: '16px', width: '820px', maxWidth: '95vw', maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <h2 style={{ margin: 0, fontSize: '1.25rem', fontWeight: '700', color: '#0f172a', display: 'flex', alignItems: 'center', gap: '10px' }}>
                <ShoppingCart size={22} color="#4338ca" />
                Create New Purchase Order
              </h2>
              <button
                type="button"
                onClick={() => setShowModal(false)}
                style={{ background: '#f1f5f9', border: 'none', borderRadius: '50%', width: '32px', height: '32px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#64748b' }}
              >
                <X size={18} />
              </button>
            </div>
            <form onSubmit={handleSubmit}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: selectedSupplier ? '16px' : '20px' }}>
                <div>
                  <label style={{ display: 'block', marginBottom: '6px', fontSize: '0.85rem', fontWeight: '600', color: '#334155' }}>Supplier *</label>
                  <select required value={formData.supplier_id} onChange={(e) => setFormData({...formData, supplier_id: e.target.value})} style={{ width: '100%', padding: '10px 12px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '0.9rem', outline: 'none' }}>
                    <option value="">Select Supplier</option>
                    {suppliers.map(s => (
                      <option key={s.id} value={s.id}>{s.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label style={{ display: 'block', marginBottom: '6px', fontSize: '0.85rem', fontWeight: '600', color: '#334155' }}>Bill / Invoice Number</label>
                  <input type="text" value={formData.bill_num} onChange={(e) => setFormData({...formData, bill_num: e.target.value})} style={{ width: '100%', padding: '10px 12px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '0.9rem', outline: 'none' }} placeholder="e.g. INV-2026-001" />
                </div>
                <div>
                  <label style={{ display: 'block', marginBottom: '6px', fontSize: '0.85rem', fontWeight: '600', color: '#334155' }}>Payment Status</label>
                  <select value={formData.pmt_status} onChange={(e) => setFormData({...formData, pmt_status: e.target.value})} style={{ width: '100%', padding: '10px 12px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '0.9rem', outline: 'none' }}>
                    <option value="Pending">Pending</option>
                    <option value="Partial">Partial</option>
                    <option value="Paid">Paid</option>
                  </select>
                </div>
                <div>
                  <label style={{ display: 'block', marginBottom: '6px', fontSize: '0.85rem', fontWeight: '600', color: '#334155' }}>Shipping Status</label>
                  <select value={formData.shipping_status} onChange={(e) => setFormData({...formData, shipping_status: e.target.value})} style={{ width: '100%', padding: '10px 12px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '0.9rem', outline: 'none' }}>
                    <option value="Pending">Pending</option>
                    <option value="Ordered">Ordered</option>
                    <option value="Received">Received (Increments Stock)</option>
                  </select>
                </div>
              </div>

              {/* SUPPLIER DETAILS CARD */}
              {selectedSupplier && (
                <div style={{
                  backgroundColor: '#f8fafc',
                  borderRadius: '12px',
                  border: '1px solid #e2e8f0',
                  borderLeft: '4px solid #4338ca',
                  padding: '16px 20px',
                  marginBottom: '22px',
                  boxShadow: '0 1px 3px rgba(0,0,0,0.03)'
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px', flexWrap: 'wrap', gap: '8px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <div style={{ width: '36px', height: '36px', borderRadius: '8px', backgroundColor: '#e0e7ff', color: '#4338ca', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <Building2 size={20} />
                      </div>
                      <div>
                        <div style={{ fontSize: '0.72rem', fontWeight: '700', textTransform: 'uppercase', letterSpacing: '0.05em', color: '#64748b' }}>
                          Supplier Details
                        </div>
                        <div style={{ fontSize: '1.05rem', fontWeight: '700', color: '#0f172a' }}>
                          {selectedSupplier.name}
                        </div>
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span style={{ 
                        fontSize: '0.75rem', 
                        fontWeight: '700', 
                        backgroundColor: selectedSupplier.status === 'Active' ? '#dcfce7' : '#fee2e2', 
                        color: selectedSupplier.status === 'Active' ? '#15803d' : '#b91c1c', 
                        padding: '3px 10px', 
                        borderRadius: '999px' 
                      }}>
                        {selectedSupplier.status || 'Active'}
                      </span>
                      <span style={{ fontSize: '0.78rem', color: '#64748b', fontFamily: 'monospace', fontWeight: '600', backgroundColor: '#f1f5f9', padding: '2px 8px', borderRadius: '4px' }}>
                        COM{String(selectedSupplier.id).padStart(5, '0')}
                      </span>
                    </div>
                  </div>

                  <div style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))',
                    gap: '14px',
                    paddingTop: '12px',
                    borderTop: '1px dashed #cbd5e1'
                  }}>
                    <div>
                      <div style={{ fontSize: '0.75rem', color: '#64748b', display: 'flex', alignItems: 'center', gap: '5px', marginBottom: '3px', fontWeight: '600' }}>
                        <Truck size={14} color="#4338ca" />
                        <span>Authorized Distributor</span>
                      </div>
                      <div style={{ fontSize: '0.9rem', fontWeight: '600', color: '#1e293b' }}>
                        {selectedSupplier.authorized_distributor || '—'}
                      </div>
                    </div>

                    <div>
                      <div style={{ fontSize: '0.75rem', color: '#64748b', display: 'flex', alignItems: 'center', gap: '5px', marginBottom: '3px', fontWeight: '600' }}>
                        <UserCheck size={14} color="#4338ca" />
                        <span>Company Officer</span>
                      </div>
                      <div style={{ fontSize: '0.9rem', fontWeight: '600', color: '#1e293b' }}>
                        {selectedSupplier.company_officer_name || '—'}
                      </div>
                    </div>

                    <div>
                      <div style={{ fontSize: '0.75rem', color: '#64748b', display: 'flex', alignItems: 'center', gap: '5px', marginBottom: '3px', fontWeight: '600' }}>
                        <Percent size={14} color="#4338ca" />
                        <span>Margin</span>
                      </div>
                      <div style={{ fontSize: '0.9rem', fontWeight: '600', color: '#1e293b' }}>
                        {selectedSupplier.margin || 'Standard'}
                      </div>
                    </div>

                    <div>
                      <div style={{ fontSize: '0.75rem', color: '#64748b', display: 'flex', alignItems: 'center', gap: '5px', marginBottom: '3px', fontWeight: '600' }}>
                        <Tag size={14} color="#4338ca" />
                        <span>Scheme / Offer</span>
                      </div>
                      <div style={{ fontSize: '0.9rem', fontWeight: '600', color: '#1e293b' }}>
                        {[selectedSupplier.scheme, selectedSupplier.offer].filter(Boolean).join(' • ') || 'None'}
                      </div>
                    </div>
                  </div>

                  {selectedSupplier.description && (
                    <div style={{ marginTop: '12px', fontSize: '0.82rem', color: '#475569', backgroundColor: '#ffffff', padding: '8px 12px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                      <span style={{ fontWeight: '700', color: '#334155' }}>Description: </span>
                      {selectedSupplier.description}
                    </div>
                  )}
                </div>
              )}

              {/* Line Items */}
              <h3 style={{ fontSize: '1rem', fontWeight: '700', marginBottom: '12px' }}>Order Line Items</h3>
              {formData.details.map((detail, index) => (
                <div key={index} style={{ display: 'flex', gap: '10px', marginBottom: '10px', alignItems: 'center' }}>
                  <select required value={detail.product_id} onChange={(e) => handleDetailChange(index, 'product_id', e.target.value)} style={{ flex: 2, padding: '10px', borderRadius: '6px', border: '1px solid #cbd5e1' }}>
                    <option value="">Select Product</option>
                    {products.map(p => (
                      <option key={p.id} value={p.id}>{p.name} ({p.sku || 'No SKU'})</option>
                    ))}
                  </select>
                  <input type="number" min="1" required placeholder="Qty" value={detail.qty} onChange={(e) => handleDetailChange(index, 'qty', e.target.value)} style={{ width: '80px', padding: '10px', borderRadius: '6px', border: '1px solid #cbd5e1' }} />
                  <input type="number" step="0.01" min="0" required placeholder="Price" value={detail.price} onChange={(e) => handleDetailChange(index, 'price', e.target.value)} style={{ width: '110px', padding: '10px', borderRadius: '6px', border: '1px solid #cbd5e1' }} />
                  {formData.details.length > 1 && (
                    <button type="button" onClick={() => removeDetailRow(index)} style={{ backgroundColor: '#ef4444', color: 'white', border: 'none', padding: '10px 14px', borderRadius: '6px', cursor: 'pointer' }}>
                      &times;
                    </button>
                  )}
                </div>
              ))}

              <button type="button" onClick={addDetailRow} style={{ backgroundColor: '#f1f5f9', border: '1px solid #cbd5e1', padding: '8px 16px', borderRadius: '6px', cursor: 'pointer', marginTop: '6px', fontWeight: '600', fontSize: '0.85rem' }}>
                + Add Another Product
              </button>

              <div style={{ marginTop: '20px', textAlign: 'right', fontSize: '1.1rem', fontWeight: '700', color: '#0f172a' }}>
                Total Estimated: ${calculateTotal()}
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px', marginTop: '24px' }}>
                <button type="button" onClick={() => setShowModal(false)} style={{ padding: '10px 18px', border: '1px solid #cbd5e1', backgroundColor: '#fff', borderRadius: '6px', cursor: 'pointer' }}>Cancel</button>
                <button type="submit" className="btn btn-primary" style={{ padding: '10px 24px', fontWeight: '600' }}>Submit Purchase Order</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Purchases;
