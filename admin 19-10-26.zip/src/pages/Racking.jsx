import React, { useState, useEffect } from 'react';
import api from '../api/axios';
import { Warehouse as WarehouseIcon, Search, Plus, Edit2, Check, X, Layers, Box, AlertCircle, RefreshCw } from 'lucide-react';

const Racking = () => {
  const [products, setProducts] = useState([]);
  const [warehouses, setWarehouses] = useState([]);
  const [loading, setLoading] = useState(true);

  // Form State for Racking Allocation
  const [selectedProductId, setSelectedProductId] = useState('');
  const [warehouseLocation, setWarehouseLocation] = useState('');
  const [rackNumber, setRackNumber] = useState('');
  const [shelfNumber, setShelfNumber] = useState('');
  const [binLocation, setBinLocation] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  // Table search & filter state
  const [search, setSearch] = useState('');
  const [selectedWarehouseFilter, setSelectedWarehouseFilter] = useState('');

  // Add Warehouse Modal State
  const [showAddWarehouseModal, setShowAddWarehouseModal] = useState(false);
  const [modalWhName, setModalWhName] = useState('');
  const [modalWhCode, setModalWhCode] = useState('');
  const [modalWhType, setModalWhType] = useState('Central Distribution Center');
  const [modalWhStatus, setModalWhStatus] = useState('Active');
  const [modalWhAddress, setModalWhAddress] = useState('');
  const [modalWhCity, setModalWhCity] = useState('');
  const [modalWhState, setModalWhState] = useState('');
  const [modalWhCountry, setModalWhCountry] = useState('India');
  const [modalWhPincode, setModalWhPincode] = useState('');
  const [modalWhManagerName, setModalWhManagerName] = useState('');
  const [modalWhContactNumber, setModalWhContactNumber] = useState('');
  const [modalWhEmail, setModalWhEmail] = useState('');
  const [modalWhCapacity, setModalWhCapacity] = useState('');
  const [modalWhIsDefault, setModalWhIsDefault] = useState(false);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [productsRes, warehousesRes] = await Promise.all([
        api.get('/admin/products?limit=500'),
        api.get('/admin/warehouses')
      ]);

      const pData = productsRes.data?.data || productsRes.data?.products || (Array.isArray(productsRes.data) ? productsRes.data : []);
      setProducts(pData);

      const wData = warehousesRes.data?.data || warehousesRes.data?.warehouses || (Array.isArray(warehousesRes.data) ? warehousesRes.data : []);
      setWarehouses(wData);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching racking data:', error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleProductSelect = (productId) => {
    setSelectedProductId(productId);
    const prod = products.find(p => String(p.id) === String(productId));
    if (prod) {
      setWarehouseLocation(prod.warehouse_location || '');
      setRackNumber(prod.rack_number || '');
      setShelfNumber(prod.shelf_number || '');
      setBinLocation(prod.bin_location || '');
    } else {
      setWarehouseLocation('');
      setRackNumber('');
      setShelfNumber('');
      setBinLocation('');
    }
  };

  const handleSubmitAllocation = async (e) => {
    e.preventDefault();
    if (!selectedProductId) {
      alert('Please select a product to assign warehouse & racking location.');
      return;
    }

    try {
      setIsSubmitting(true);
      await api.put(`/admin/products/${selectedProductId}`, {
        warehouse_location: warehouseLocation || null,
        rack_number: rackNumber || null,
        shelf_number: shelfNumber || null,
        bin_location: binLocation || null
      });

      // Update in local state
      setProducts(prev =>
        prev.map(p =>
          String(p.id) === String(selectedProductId)
            ? { ...p, warehouse_location: warehouseLocation, rack_number: rackNumber, shelf_number: shelfNumber, bin_location: binLocation }
            : p
        )
      );

      setSuccessMessage('Racking allocation successfully saved!');
      setTimeout(() => setSuccessMessage(''), 3500);
    } catch (err) {
      console.error('Failed to save racking allocation:', err);
      alert(err.response?.data?.message || 'Failed to save racking allocation');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEditFromTable = (product) => {
    setSelectedProductId(product.id);
    setWarehouseLocation(product.warehouse_location || '');
    setRackNumber(product.rack_number || '');
    setShelfNumber(product.shelf_number || '');
    setBinLocation(product.bin_location || '');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const submitNewWarehouse = async (e) => {
    e.preventDefault();
    if (!modalWhName.trim()) {
      alert("Warehouse Name is required");
      return;
    }
    try {
      const payload = {
        name: modalWhName.trim(),
        warehouse_code: modalWhCode.trim() || null,
        code: modalWhCode.trim() || null,
        warehouse_type: modalWhType || 'Central Distribution Center',
        type: modalWhType || 'Central Distribution Center',
        status: modalWhStatus || 'Active',
        address_line_1: modalWhAddress.trim() || null,
        address: modalWhAddress.trim() || null,
        city: modalWhCity.trim() || 'N/A',
        state: modalWhState.trim() || null,
        country: modalWhCountry.trim() || 'India',
        pincode: modalWhPincode.trim() || null,
        contact_person: modalWhManagerName.trim() || null,
        manager_name: modalWhManagerName.trim() || null,
        phone_number: modalWhContactNumber.trim() || null,
        contact_number: modalWhContactNumber.trim() || null,
        email: modalWhEmail.trim() || null,
        total_capacity: modalWhCapacity.trim() || null,
        capacity: modalWhCapacity.trim() || null,
        is_default: modalWhIsDefault
      };
      const res = await api.post('/admin/warehouses', payload);
      const newWh = res.data?.data || res.data;
      setWarehouses(prev => [...prev, newWh]);
      setWarehouseLocation(newWh.name || modalWhName);
      setShowAddWarehouseModal(false);
      resetWarehouseForm();
    } catch (err) {
      console.error('Failed to add warehouse:', err);
      alert(err.response?.data?.message || 'Failed to add warehouse');
    }
  };

  const resetWarehouseForm = () => {
    setModalWhName('');
    setModalWhCode('');
    setModalWhType('Central Distribution Center');
    setModalWhStatus('Active');
    setModalWhAddress('');
    setModalWhCity('');
    setModalWhState('');
    setModalWhCountry('India');
    setModalWhPincode('');
    setModalWhManagerName('');
    setModalWhContactNumber('');
    setModalWhEmail('');
    setModalWhCapacity('');
    setModalWhIsDefault(false);
  };

  const filteredProducts = products.filter(p => {
    const matchesSearch =
      (p.name || '').toLowerCase().includes(search.toLowerCase()) ||
      (p.sku || '').toLowerCase().includes(search.toLowerCase()) ||
      (p.rack_number || '').toLowerCase().includes(search.toLowerCase()) ||
      (p.shelf_number || '').toLowerCase().includes(search.toLowerCase()) ||
      (p.bin_location || '').toLowerCase().includes(search.toLowerCase());

    const matchesWarehouse = !selectedWarehouseFilter || p.warehouse_location === selectedWarehouseFilter;
    return matchesSearch && matchesWarehouse;
  });

  return (
    <div style={{ padding: '4px 0' }}>
      {/* HEADER SECTION */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <h1 style={{ fontSize: '1.75rem', fontWeight: '800', color: '#0f172a', margin: 0, letterSpacing: '-0.02em' }}>
              Rackbin (Warehouse)
            </h1>
            <span style={{ backgroundColor: '#e0e7ff', color: '#4338ca', fontSize: '0.75rem', fontWeight: '700', padding: '3px 8px', borderRadius: '12px' }}>
              Master Section
            </span>
          </div>
          <p style={{ margin: '6px 0 0 0', fontSize: '0.875rem', color: '#64748b' }}>
            Designate storage warehouse, rack number, and shelf location for products.
          </p>
        </div>

        <button
          onClick={fetchData}
          title="Refresh"
          style={{
            padding: '9px 14px',
            backgroundColor: '#ffffff',
            color: '#475569',
            border: '1px solid #cbd5e1',
            borderRadius: '8px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            fontSize: '0.85rem',
            fontWeight: '600'
          }}
        >
          <RefreshCw size={15} /> Refresh
        </button>
      </div>

      {successMessage && (
        <div style={{ backgroundColor: '#ecfdf5', border: '1px solid #6ee7b7', color: '#065f46', padding: '12px 18px', borderRadius: '10px', marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '10px', fontWeight: '600' }}>
          <Check size={18} color="#059669" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* EXACT SAME RACKBIN (WAREHOUSE) ALLOCATION FORM AS IN ADD PRODUCT */}
      <div
        style={{
          backgroundColor: '#ffffff',
          borderRadius: '16px',
          border: '1px solid #e2e8f0',
          padding: '24px 28px',
          marginBottom: '28px',
          boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.05)'
        }}
      >
        <form onSubmit={handleSubmitAllocation}>
          {/* Header Banner - IDENTICAL TO ADD PRODUCT FORM */}
          <div
            style={{
              backgroundColor: '#f8fafc',
              padding: '16px 20px',
              borderRadius: '12px',
              border: '1px solid #e2e8f0',
              marginBottom: '24px',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              flexWrap: 'wrap',
              gap: '12px'
            }}
          >
            <div>
              <h3 style={{ margin: 0, fontSize: '1.05rem', color: '#0f172a', fontWeight: '700' }}>
                Rackbin (Warehouse) Allocation
              </h3>
              <p style={{ margin: '4px 0 0 0', fontSize: '0.82rem', color: '#64748b' }}>
                Select storage warehouse and designate rack & shelf location for this product.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowAddWarehouseModal(true)}
              style={{
                padding: '8px 16px',
                backgroundColor: '#4338ca',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                fontSize: '0.85rem',
                fontWeight: '600',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '6px'
              }}
            >
              + Add Warehouse
            </button>
          </div>

          {/* Product Selector for the allocation form */}
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
              Select Product to Allocate *
            </label>
            <select
              style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', fontWeight: '500' }}
              value={selectedProductId}
              onChange={(e) => handleProductSelect(e.target.value)}
              required
            >
              <option value="">-- Choose a Product ({products.length} available) --</option>
              {products.map(p => (
                <option key={p.id} value={p.id}>
                  {p.name} {p.sku ? `(${p.sku})` : ''} {p.warehouse_location ? `[Current: ${p.warehouse_location} | ${p.rack_number || 'No Rack'} | ${p.shelf_number || 'No Shelf'}]` : '[Unallocated]'}
                </option>
              ))}
            </select>
          </div>

          {/* 4 COLUMNS RACKBIN ALLOCATION FORM */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '20px', marginBottom: '24px' }}>
            {/* 1. Warehouse */}
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', margin: 0 }}>
                  Warehouse
                </label>
                <button
                  type="button"
                  onClick={() => setShowAddWarehouseModal(true)}
                  style={{ background: 'none', border: 'none', color: '#4338ca', cursor: 'pointer', fontSize: '0.8rem', fontWeight: '600', padding: 0 }}
                >
                  + New
                </button>
              </div>
              <select
                style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                value={warehouseLocation}
                onChange={(e) => setWarehouseLocation(e.target.value)}
              >
                <option value="">Select Warehouse...</option>
                {warehouses.map(w => (
                  <option key={w.id} value={w.name}>
                    {(w.warehouse_code || w.code) ? `[${w.warehouse_code || w.code}] ` : ''}{w.name} {w.is_default ? '★ (Default)' : ''} - ({w.warehouse_type || w.type || 'Warehouse'})
                  </option>
                ))}
              </select>
            </div>

            {/* 2. Rack Number */}
            <div>
              <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                Rack Number
              </label>
              <input
                type="text"
                placeholder="e.g. Rack A-12, R-04"
                style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                value={rackNumber}
                onChange={(e) => setRackNumber(e.target.value)}
              />
            </div>

            {/* 3. Shelf Number */}
            <div>
              <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                Shelf Number
              </label>
              <input
                type="text"
                placeholder="e.g. Shelf 03, S-2"
                style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                value={shelfNumber}
                onChange={(e) => setShelfNumber(e.target.value)}
              />
            </div>

            {/* 4. Bin Location */}
            <div>
              <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                Bin Location
              </label>
              <input
                type="text"
                placeholder="e.g. Bin B-05, BIN-101"
                style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                value={binLocation}
                onChange={(e) => setBinLocation(e.target.value)}
              />
            </div>
          </div>

          {/* Form Actions */}
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px', borderTop: '1px solid #f1f5f9', paddingTop: '16px' }}>
            {selectedProductId && (
              <button
                type="button"
                onClick={() => {
                  setSelectedProductId('');
                  setWarehouseLocation('');
                  setRackNumber('');
                  setShelfNumber('');
                }}
                style={{
                  padding: '9px 18px',
                  backgroundColor: '#f1f5f9',
                  color: '#475569',
                  border: '1px solid #cbd5e1',
                  borderRadius: '8px',
                  fontSize: '0.85rem',
                  fontWeight: '600',
                  cursor: 'pointer'
                }}
              >
                Clear
              </button>
            )}
            <button
              type="submit"
              disabled={isSubmitting}
              style={{
                padding: '9px 24px',
                backgroundColor: '#4338ca',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                fontSize: '0.875rem',
                fontWeight: '600',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                boxShadow: '0 2px 4px rgba(67, 56, 202, 0.2)'
              }}
            >
              {isSubmitting ? 'Saving...' : 'Save Rackbin Allocation'}
            </button>
          </div>
        </form>
      </div>

      {/* RACKBIN ALLOCATION OVERVIEW TABLE */}
      <div style={{ backgroundColor: '#ffffff', borderRadius: '16px', border: '1px solid #e2e8f0', overflow: 'hidden', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.05)' }}>
        <div style={{ padding: '18px 24px', borderBottom: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '14px' }}>
          <div>
            <h3 style={{ margin: 0, fontSize: '1.05rem', fontWeight: '700', color: '#0f172a' }}>
              Allocated Rackbins & Warehouses
            </h3>
            <span style={{ fontSize: '0.8rem', color: '#64748b' }}>
              Showing {filteredProducts.length} of {products.length} products
            </span>
          </div>

          <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
            <select
              value={selectedWarehouseFilter}
              onChange={(e) => setSelectedWarehouseFilter(e.target.value)}
              style={{ padding: '8px 12px', border: '1px solid #cbd5e1', borderRadius: '8px', fontSize: '0.85rem', outline: 'none', backgroundColor: '#f8fafc' }}
            >
              <option value="">All Warehouses</option>
              {warehouses.map(w => (
                <option key={w.id} value={w.name}>{w.name}</option>
              ))}
            </select>

            <div style={{ position: 'relative', width: '240px' }}>
              <Search size={16} color="#94a3b8" style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)' }} />
              <input
                type="text"
                placeholder="Search product, SKU, rack..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                style={{ width: '100%', padding: '8px 12px 8px 32px', border: '1px solid #cbd5e1', borderRadius: '8px', fontSize: '0.85rem', outline: 'none' }}
              />
            </div>
          </div>
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
            <thead>
              <tr style={{ backgroundColor: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>
                <th style={{ padding: '12px 18px', color: '#475569', fontWeight: '600' }}>Product Name</th>
                <th style={{ padding: '12px 18px', color: '#475569', fontWeight: '600' }}>SKU</th>
                <th style={{ padding: '12px 18px', color: '#475569', fontWeight: '600' }}>Warehouse</th>
                <th style={{ padding: '12px 18px', color: '#475569', fontWeight: '600' }}>Rack Number</th>
                <th style={{ padding: '12px 18px', color: '#475569', fontWeight: '600' }}>Shelf Number</th>
                <th style={{ padding: '12px 18px', color: '#475569', fontWeight: '600' }}>Bin Location</th>
                <th style={{ padding: '12px 18px', color: '#475569', fontWeight: '600' }}>Status</th>
                <th style={{ padding: '12px 18px', color: '#475569', fontWeight: '600', textAlign: 'right' }}>Action</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="8" style={{ padding: '40px', textAlign: 'center', color: '#64748b' }}>
                    Loading rackbin details...
                  </td>
                </tr>
              ) : filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan="8" style={{ padding: '40px', textAlign: 'center', color: '#64748b' }}>
                    No products found.
                  </td>
                </tr>
              ) : (
                filteredProducts.map((p) => {
                  const isAllocated = !!(p.warehouse_location || p.rack_number || p.shelf_number || p.bin_location);
                  const isCurrentlySelected = String(p.id) === String(selectedProductId);

                  return (
                    <tr
                      key={p.id}
                      style={{
                        borderBottom: '1px solid #f1f5f9',
                        backgroundColor: isCurrentlySelected ? '#f5f3ff' : 'transparent',
                        transition: 'background-color 0.2s'
                      }}
                    >
                      <td style={{ padding: '14px 18px', fontWeight: '600', color: '#0f172a' }}>
                        {p.name}
                      </td>
                      <td style={{ padding: '14px 18px', color: '#64748b', fontFamily: 'monospace' }}>
                        {p.sku || '-'}
                      </td>
                      <td style={{ padding: '14px 18px' }}>
                        {p.warehouse_location ? (
                          <span style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', color: '#0f172a', fontWeight: '500' }}>
                            <WarehouseIcon size={14} color="#6366f1" />
                            {p.warehouse_location}
                          </span>
                        ) : (
                          <span style={{ color: '#94a3b8', fontStyle: 'italic' }}>Not assigned</span>
                        )}
                      </td>
                      <td style={{ padding: '14px 18px' }}>
                        {p.rack_number ? (
                          <span style={{ backgroundColor: '#e0e7ff', color: '#3730a3', padding: '3px 8px', borderRadius: '6px', fontWeight: '600', fontSize: '0.8rem' }}>
                            {p.rack_number}
                          </span>
                        ) : (
                          <span style={{ color: '#94a3b8' }}>-</span>
                        )}
                      </td>
                      <td style={{ padding: '14px 18px' }}>
                        {p.shelf_number ? (
                          <span style={{ backgroundColor: '#f1f5f9', color: '#334155', padding: '3px 8px', borderRadius: '6px', fontWeight: '600', fontSize: '0.8rem' }}>
                            {p.shelf_number}
                          </span>
                        ) : (
                          <span style={{ color: '#94a3b8' }}>-</span>
                        )}
                      </td>
                      <td style={{ padding: '14px 18px' }}>
                        {p.bin_location ? (
                          <span style={{ backgroundColor: '#f3e8ff', color: '#6b21a8', padding: '3px 8px', borderRadius: '6px', fontWeight: '600', fontSize: '0.8rem' }}>
                            {p.bin_location}
                          </span>
                        ) : (
                          <span style={{ color: '#94a3b8' }}>-</span>
                        )}
                      </td>
                      <td style={{ padding: '14px 18px' }}>
                        {isAllocated ? (
                          <span style={{ backgroundColor: '#dcfce7', color: '#166534', padding: '3px 8px', borderRadius: '12px', fontSize: '0.75rem', fontWeight: '600' }}>
                            Allocated
                          </span>
                        ) : (
                          <span style={{ backgroundColor: '#fef3c7', color: '#92400e', padding: '3px 8px', borderRadius: '12px', fontSize: '0.75rem', fontWeight: '600' }}>
                            Pending
                          </span>
                        )}
                      </td>
                      <td style={{ padding: '14px 18px', textAlign: 'right' }}>
                        <button
                          type="button"
                          onClick={() => handleEditFromTable(p)}
                          style={{
                            padding: '6px 12px',
                            backgroundColor: isCurrentlySelected ? '#4338ca' : '#eef2ff',
                            color: isCurrentlySelected ? 'white' : '#4338ca',
                            border: '1px solid #c7d2fe',
                            borderRadius: '6px',
                            cursor: 'pointer',
                            fontSize: '0.8rem',
                            fontWeight: '600',
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '4px'
                          }}
                        >
                          <Edit2 size={13} /> {isCurrentlySelected ? 'Editing' : 'Load in Form'}
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ADD NEW WAREHOUSE MODAL (EXACT SAME AS IN ADD PRODUCT FORM) */}
      {showAddWarehouseModal && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(15, 23, 42, 0.6)', backdropFilter: 'blur(4px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1300, padding: '20px' }}>
          <div style={{ backgroundColor: 'white', borderRadius: '16px', width: '560px', maxWidth: '95vw', maxHeight: '90vh', display: 'flex', flexDirection: 'column', position: 'relative', boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)', overflow: 'hidden' }}>
            <div style={{ padding: '24px 28px', borderBottom: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h2 style={{ margin: 0, color: '#0f172a', fontSize: '1.25rem', fontWeight: '700' }}>Add New Warehouse</h2>
              <button
                type="button"
                onClick={() => setShowAddWarehouseModal(false)}
                style={{ background: '#f1f5f9', border: 'none', borderRadius: '50%', width: '32px', height: '32px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#64748b' }}
              >
                <X size={18} />
              </button>
            </div>

            <div className="custom-modal-scroll" style={{ padding: '24px 28px', overflowY: 'auto', flex: 1 }}>
              <form onSubmit={submitNewWarehouse}>
                <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 0.8fr', gap: '16px', marginBottom: '16px' }}>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                      Warehouse Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Central Hub"
                      style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhName}
                      onChange={e => setModalWhName(e.target.value)}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                      Code
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. WH-01"
                      style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhCode}
                      onChange={e => setModalWhCode(e.target.value)}
                    />
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                      Warehouse Type
                    </label>
                    <select
                      style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhType}
                      onChange={e => setModalWhType(e.target.value)}
                    >
                      <option value="Central Distribution Center">Central Distribution Center</option>
                      <option value="Regional Warehouse">Regional Warehouse</option>
                      <option value="Transit Hub">Transit Hub</option>
                      <option value="Retail Fulfillment">Retail Fulfillment</option>
                      <option value="Cold Storage">Cold Storage</option>
                      <option value="Bonded Warehouse">Bonded Warehouse</option>
                    </select>
                  </div>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                      Status
                    </label>
                    <select
                      style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhStatus}
                      onChange={e => setModalWhStatus(e.target.value)}
                    >
                      <option value="Active">Active</option>
                      <option value="Inactive">Inactive</option>
                    </select>
                  </div>
                </div>

                <div style={{ marginBottom: '16px' }}>
                  <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                    Address Line 1
                  </label>
                  <input
                    type="text"
                    placeholder="Street address, building, suite..."
                    style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                    value={modalWhAddress}
                    onChange={e => setModalWhAddress(e.target.value)}
                  />
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: '12px', marginBottom: '16px' }}>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>City</label>
                    <input
                      type="text"
                      placeholder="e.g. Mumbai"
                      style={{ width: '100%', padding: '10px 12px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhCity}
                      onChange={e => setModalWhCity(e.target.value)}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>State</label>
                    <input
                      type="text"
                      placeholder="e.g. Maharashtra"
                      style={{ width: '100%', padding: '10px 12px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhState}
                      onChange={e => setModalWhState(e.target.value)}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>Country</label>
                    <input
                      type="text"
                      placeholder="e.g. India"
                      style={{ width: '100%', padding: '10px 12px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhCountry}
                      onChange={e => setModalWhCountry(e.target.value)}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>Pincode</label>
                    <input
                      type="text"
                      placeholder="e.g. 400001"
                      style={{ width: '100%', padding: '10px 12px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhPincode}
                      onChange={e => setModalWhPincode(e.target.value)}
                    />
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '14px', marginBottom: '16px' }}>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                      Contact Person
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. John Doe"
                      style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhManagerName}
                      onChange={e => setModalWhManagerName(e.target.value)}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                      Phone Number
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. +91 9876543210"
                      style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhContactNumber}
                      onChange={e => setModalWhContactNumber(e.target.value)}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                      Email Address
                    </label>
                    <input
                      type="email"
                      placeholder="e.g. wh@company.com"
                      style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhEmail}
                      onChange={e => setModalWhEmail(e.target.value)}
                    />
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 0.8fr', gap: '16px', marginBottom: '22px', alignItems: 'center' }}>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                      Total Capacity
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. 50,000 sq ft or 1,200 pallets"
                      style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhCapacity}
                      onChange={e => setModalWhCapacity(e.target.value)}
                    />
                  </div>
                  <div style={{ paddingTop: '20px' }}>
                    <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontSize: '0.85rem', fontWeight: '600', color: '#1e293b' }}>
                      <input
                        type="checkbox"
                        checked={modalWhIsDefault}
                        onChange={e => setModalWhIsDefault(e.target.checked)}
                        style={{ width: '17px', height: '17px', accentColor: '#4338ca', cursor: 'pointer' }}
                      />
                      Set as Default Warehouse
                    </label>
                  </div>
                </div>

                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px' }}>
                  <button
                    type="button"
                    onClick={() => setShowAddWarehouseModal(false)}
                    style={{ padding: '10px 20px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: 'white', color: '#334155', fontWeight: '600', cursor: 'pointer' }}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    style={{ padding: '10px 24px', border: 'none', borderRadius: '8px', backgroundColor: '#4338ca', color: 'white', fontWeight: '600', cursor: 'pointer' }}
                  >
                    Save Warehouse
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Racking;
