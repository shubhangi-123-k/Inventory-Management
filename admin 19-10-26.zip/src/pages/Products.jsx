import React, { useState, useEffect, Fragment } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api/axios';
import { Plus, Eye, Trash2, ChevronLeft, ChevronRight, X, Edit2, Check, Search, AlertCircle, Loader2, ShieldCheck, CheckCircle2, FileDown, FileSpreadsheet, Upload, Image as ImageIcon, ChevronDown, ChevronUp, Layers, Box, QrCode, Sparkles, Building2, Gift } from 'lucide-react';
import AttributeBuilder from '../components/AttributeBuilder';
import CascadingGroupSelect from '../components/CascadingGroupSelect';
import SearchAutocomplete from '../components/SearchAutocomplete';
import PhotoUploader from '../components/PhotoUploader';
import AddOccasionModal from '../components/AddOccasionModal';
import BarcodeUploader from '../components/BarcodeUploader';
import VideoUploader from '../components/VideoUploader';
import BrochureUploader from '../components/BrochureUploader';
import OccasionSelector from '../components/OccasionSelector';
import ProductSchemesManager from '../components/ProductSchemesManager';
import VariantMatrixBuilder from '../components/VariantMatrixBuilder';
import PackagingModal from '../components/PackagingModal';
import QRCodeSVG from '../components/QRCodeSVG';
import ProductVariantsTable from '../components/ProductVariantsTable';
import QuickPriceEditModal from '../components/QuickPriceEditModal';
import PrintVariantQRModal from '../components/PrintVariantQRModal';
import AddVariantModal from '../components/AddVariantModal';
import EditVariantDrawer from '../components/EditVariantDrawer';
import { downloadProductBrochurePDF, downloadProductDetailsExcel, exportAllProductsExcel } from '../utils/productExport';
import { extractCompanyMedia } from '../utils/mediaUtils';

const Products = () => {
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  // Occasion States
  const [isOccasionBased, setIsOccasionBased] = useState('No');
  const [selectedOccasionType, setSelectedOccasionType] = useState('');
  const [selectedOccasionIds, setSelectedOccasionIds] = useState([]);
  const [occasionsList, setOccasionsList] = useState([]);
  const [occasionTypes, setOccasionTypes] = useState(['Festival', 'Season', 'Event', 'Other']);
  const [showAddOccasionModal, setShowAddOccasionModal] = useState(false);

  // Form State
  const [showForm, setShowForm] = useState(false);
  const [showGroupForm, setShowGroupForm] = useState(false);

  const [showTypeForm, setShowTypeForm] = useState(false);
  const [productTypes, setProductTypes] = useState(["Solid", "Liquid", "Gas"]);
  const [newTypeName, setNewTypeName] = useState("");

  const [baseProductName, setBaseProductName] = useState('');
  const [productName, setProductName] = useState('');
  const [isEditingName, setIsEditingName] = useState(false);
  const [isCustomName, setIsCustomName] = useState(false);

  const [productDescription, setProductDescription] = useState('');
  const [productAliases, setProductAliases] = useState(['']);
  const [attributes, setAttributes] = useState([]);
  const [hasVariants, setHasVariants] = useState('No');
  const [variantAttributes, setVariantAttributes] = useState([]);
  const [productVariants, setProductVariants] = useState([]);
  const [expandedProductIds, setExpandedProductIds] = useState(new Set());
  const [previewCartonModal, setPreviewCartonModal] = useState(null); // { variant, packaging }

  // View Switcher & Variants Master states
  const [viewMode, setViewMode] = useState('templates'); // 'templates' or 'variants'
  const [templatesOnlyList, setTemplatesOnlyList] = useState([]);
  const [variantsList, setVariantsList] = useState([]);
  const [quickPriceVariant, setQuickPriceVariant] = useState(null);
  const [printQrVariant, setPrintQrVariant] = useState(null);
  const [showAddVariantModal, setShowAddVariantModal] = useState(false);
  const [editDrawerVariant, setEditDrawerVariant] = useState(null);
  const [parentProductMap, setParentProductMap] = useState({});

  const handleAddAlias = () => {
    setProductAliases([...productAliases, '']);
  };

  const handleAliasChange = (index, value) => {
    const newAliases = [...productAliases];
    newAliases[index] = value;
    setProductAliases(newAliases);
  };

  const handleRemoveAlias = (index) => {
    const newAliases = productAliases.filter((_, i) => i !== index);
    setProductAliases(newAliases);
  };
  const [productType, setProductType] = useState('');
  const [internalSku, setInternalSku] = useState('');
  const [brandId, setBrandId] = useState('');
  const [brands, setBrands] = useState([]);
  const [companyName, setCompanyName] = useState('');
  const [companies, setCompanies] = useState([]);
  const [warehouses, setWarehouses] = useState([]);


  // Group & ignoredSubGroup State
  const [groups, setGroups] = useState([]);

  const [groupId, setGroupId] = useState('');


  const [purchasePrice, setPurchasePrice] = useState('');
  const [purchaseQuantity, setPurchaseQuantity] = useState('');
  const [lotNumber, setLotNumber] = useState('');
  const [batchNumber, setBatchNumber] = useState('');
  const [sellingPrice, setSellingPrice] = useState('');
  const [mrp, setMrp] = useState('');
  const [distributorPrice, setDistributorPrice] = useState('');
  const [distributorProfitPercent, setDistributorProfitPercent] = useState('');
  const [profitPercent, setProfitPercent] = useState('');
  const [sellingPriceWholesale, setSellingPriceWholesale] = useState('');
  const [wholesaleProfitPercent, setWholesaleProfitPercent] = useState('');
  const [sellingPriceRetail, setSellingPriceRetail] = useState('');
  const [retailProfitPercent, setRetailProfitPercent] = useState('');
  const [currency, setCurrency] = useState('INR');
  const [pricingMethod, setPricingMethod] = useState('PROFIT_ON_COST'); // 'PROFIT_ON_COST', 'DISCOUNT_ON_MRP', 'DISCOUNT_ON_SELLING_PRICE', 'MANUAL'
  const [profitOnCostPercent, setProfitOnCostPercent] = useState('');
  const [discountOnMrpPercent, setDiscountOnMrpPercent] = useState('');
  const [baseSellingPrice, setBaseSellingPrice] = useState('');
  const [discountOnSellingPricePercent, setDiscountOnSellingPricePercent] = useState('');
  const [roundOff, setRoundOff] = useState(false);
  const [gstRate, setGstRate] = useState('');
  const [reorderLevel, setReorderLevel] = useState('');
  const [reorderNote, setReorderNote] = useState('');
  const [barcode, setBarcode] = useState('');
  const [barcodeImageUrl, setBarcodeImageUrl] = useState('');
  const [hsnCode, setHsnCode] = useState('');
  const [hsnCheckStatus, setHsnCheckStatus] = useState(null); // null, 'checking', 'valid', 'not_found'
  const [warehouseLocation, setWarehouseLocation] = useState('');
  const [warehouseId, setWarehouseId] = useState('');
  const [rackNumber, setRackNumber] = useState('');
  const [shelfNumber, setShelfNumber] = useState('');
  const [binLocation, setBinLocation] = useState('');
  const [openingStock, setOpeningStock] = useState('');
  const [safetyStock, setSafetyStock] = useState('');
  const [manufacturingDate, setManufacturingDate] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [bestBeforeDate, setBestBeforeDate] = useState('');
  // Schemes & Targets State
  const [productPeProduct, setProductPeProduct] = useState('');
  const [discountOnProduct, setDiscountOnProduct] = useState('');
  const [productTargetScheme, setProductTargetScheme] = useState('');
  const [discountOnBillAmount, setDiscountOnBillAmount] = useState('');
  const [quarterlyDiscountOnTurnover, setQuarterlyDiscountOnTurnover] = useState('');
  const [yearlyDiscountOnTurnover, setYearlyDiscountOnTurnover] = useState('');
  const [seasonalSchemeName, setSeasonalSchemeName] = useState('');
  const [seasonalFrequency, setSeasonalFrequency] = useState('Yearly');
  const [seasonalApplicability, setSeasonalApplicability] = useState('All Products');
  const [seasonalPeriodStart, setSeasonalPeriodStart] = useState('');
  const [seasonalPeriodEnd, setSeasonalPeriodEnd] = useState('');
  const [activeTab, setActiveTab] = useState('info');
  const [physicalAppearance, setPhysicalAppearance] = useState('');
  const [size, setSize] = useState('');
  const [packaging, setPackaging] = useState('');
  const [length, setLength] = useState('');
  const [breadth, setBreadth] = useState('');
  const [thickness, setThickness] = useState('');
  const [dimensionUnit, setDimensionUnit] = useState('cm');
  const [customDimensionUnit, setCustomDimensionUnit] = useState('');
  const [volume, setVolume] = useState('');
  const [volumeUnit, setVolumeUnit] = useState('ml');
  const [customVolumeUnit, setCustomVolumeUnit] = useState('');
  const [netWeight, setNetWeight] = useState('');
  const [grossWeight, setGrossWeight] = useState('');
  const [weightUnit, setWeightUnit] = useState('g');
  const [customWeightUnit, setCustomWeightUnit] = useState('');
  const [productImages, setProductImages] = useState([]);
  const [productVideos, setProductVideos] = useState([]);
  const [companyBrochure, setCompanyBrochure] = useState({ url: '', name: '' });
  const [companyInheritedMedia, setCompanyInheritedMedia] = useState(null);
  const [companyInheritedSchemes, setCompanyInheritedSchemes] = useState(null);
  const [isInheritingMedia, setIsInheritingMedia] = useState(false);

  // Filters State
  const [search, setSearch] = useState('');
  const [filterGroupId, setFilterGroupId] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterOccasionBased, setFilterOccasionBased] = useState('');
  const [filterOccasionType, setFilterOccasionType] = useState('');
  const [filterOccasionId, setFilterOccasionId] = useState('');

  // Custom Modal States
  const [showAddGroupModal, setShowAddGroupModal] = useState(false);

  const [modalGroupName, setModalGroupName] = useState('');
  const [modalGroupDesc, setModalGroupDesc] = useState('');
  const [modalGroupParentId, setModalGroupParentId] = useState('');
  const [modalGroupImages, setModalGroupImages] = useState([]);
  const [groupRefresh, setGroupRefresh] = useState(0);

  useEffect(() => {
    if (isCustomName) return;
    let parts = [];
    if (baseProductName) parts.push(baseProductName);
    if (companyName) parts.push(companyName);
    if (brandId) {
      const brand = brands.find(b => b.id == brandId);
      if (brand) parts.push(brand.name);
    }
    if (attributes && attributes.length > 0) {
      attributes.forEach(attr => {
        if (attr.value) parts.push(attr.value);
      });
    }
    if (sellingPrice) parts.push(sellingPrice);

    setProductName(parts.join(' '));
  }, [baseProductName, companyName, brandId, attributes, sellingPrice, brands, isCustomName]);

  // Auto-calculate selling price based on profit % on cost, discount % on MRP, or offer % on selling price with round off
  useEffect(() => {
    if (pricingMethod === 'MANUAL') return;

    let computed = null;
    if (pricingMethod === 'PROFIT_ON_COST') {
      const cost = parseFloat(purchasePrice) || 0;
      const pct = parseFloat(profitOnCostPercent) || 0;
      if (cost > 0 && pct > 0) {
        computed = cost * (1 + (pct / 100));
      }
    } else if (pricingMethod === 'DISCOUNT_ON_MRP') {
      const mrpVal = parseFloat(mrp) || 0;
      const pct = parseFloat(discountOnMrpPercent) || 0;
      if (mrpVal > 0 && pct > 0) {
        computed = mrpVal * (1 - (pct / 100));
      }
    } else if (pricingMethod === 'DISCOUNT_ON_SELLING_PRICE') {
      const baseVal = parseFloat(baseSellingPrice || mrp || sellingPrice) || 0;
      const pct = parseFloat(discountOnSellingPricePercent) || 0;
      if (baseVal > 0 && pct > 0) {
        computed = baseVal * (1 - (pct / 100));
      }
    }

    if (computed !== null) {
      const finalPrice = roundOff ? Math.round(computed) : parseFloat(computed.toFixed(2));
      setSellingPrice(finalPrice.toString());
    }
  }, [purchasePrice, mrp, baseSellingPrice, profitOnCostPercent, discountOnMrpPercent, discountOnSellingPricePercent, roundOff, pricingMethod]);

  const [showAddCompanyModal, setShowAddCompanyModal] = useState(false);
  const [showAddBrandModal, setShowAddBrandModal] = useState(false);
  const [modalCompanyName, setModalCompanyName] = useState('');
  const [modalCompanyDesc, setModalCompanyDesc] = useState('');
  const [modalCompanyScheme, setModalCompanyScheme] = useState('');
  const [modalCompanyOffer, setModalCompanyOffer] = useState('');
  const [modalCompanyMargin, setModalCompanyMargin] = useState('');
  const [modalCompanyDistributor, setModalCompanyDistributor] = useState('');
  const [modalCompanyOfficers, setModalCompanyOfficers] = useState(['']);
  const [modalCompanyImages, setModalCompanyImages] = useState([]);
  const [modalCompanyBrochures, setModalCompanyBrochures] = useState([]);
  const [modalBrandName, setModalBrandName] = useState('');
  const [modalBrandDesc, setModalBrandDesc] = useState('');
  const [modalBrandScheme, setModalBrandScheme] = useState('');
  const [modalBrandOffer, setModalBrandOffer] = useState('');
  const [modalBrandMargin, setModalBrandMargin] = useState('');
  const [modalBrandDistributor, setModalBrandDistributor] = useState('');
  const [modalBrandOfficer, setModalBrandOfficer] = useState('');

  // Add Warehouse Modal State
  const [showAddWarehouseModal, setShowAddWarehouseModal] = useState(false);
  const [modalWhName, setModalWhName] = useState('');
  const [modalWhCode, setModalWhCode] = useState('');
  const [modalWhType, setModalWhType] = useState('Central Distribution Center');
  const [modalWhStatus, setModalWhStatus] = useState('Active');
  const [modalWhAddress, setModalWhAddress] = useState('');
  const [modalWhCity, setModalWhCity] = useState('');
  const [modalWhState, setModalWhState] = useState('');
  const [modalWhCountry, setModalWhCountry] = useState('India');
  const [modalWhPincode, setModalWhPincode] = useState('');
  const [modalWhManagerName, setModalWhManagerName] = useState('');
  const [modalWhContactNumber, setModalWhContactNumber] = useState('');
  const [modalWhEmail, setModalWhEmail] = useState('');
  const [modalWhCapacity, setModalWhCapacity] = useState('');
  const [modalWhIsDefault, setModalWhIsDefault] = useState(false);

  const fetchOccasions = async () => {
    try {
      const res = await api.get('/admin/occasions');
      setOccasionsList(res.data?.data || res.data || []);
      const typesRes = await api.get('/admin/occasions/types');
      if (typesRes.data?.data) {
        setOccasionTypes(typesRes.data.data);
      }
    } catch (err) {
      console.error('Failed to fetch occasions:', err);
    }
  };

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const queryParams = new URLSearchParams();
      if (search) queryParams.append('search', search);
      if (filterGroupId) queryParams.append('group_id', filterGroupId);
      if (filterStatus) queryParams.append('status', filterStatus);
      if (filterOccasionBased) queryParams.append('is_occasion_based', filterOccasionBased === 'Yes' ? 'true' : 'false');
      if (filterOccasionType) queryParams.append('occasion_type', filterOccasionType);
      if (filterOccasionId) queryParams.append('occasion_id', filterOccasionId);

      let response;
      try {
        const queryWithParam = new URLSearchParams(queryParams);
        if (viewMode === 'variants') {
          queryWithParam.append('variants_only', 'true');
        } else {
          queryWithParam.append('templates_only', 'true');
        }
        response = await api.get(`/admin/products?${queryWithParam.toString()}`);
      } catch (paramErr) {
        if (paramErr.response?.status === 500) {
          console.warn("[Products] Backend returned 500 with templates/variants query, retrying without filter:", paramErr.response.data);
          const baseQs = queryParams.toString();
          response = await api.get(`/admin/products${baseQs ? `?${baseQs}` : ''}`);
        } else {
          throw paramErr;
        }
      }

      const rawData = response.data?.data || response.data || [];
      const list = Array.isArray(rawData) ? rawData : [];

      if (viewMode === 'templates') {
        setProducts(list.filter(p => !p.parent_product_id));
        setTemplatesOnlyList(list.filter(p => !p.parent_product_id));
        const parentMap = {};
        list.forEach(p => { if (p.id) parentMap[p.id] = p; });
        setParentProductMap(prev => ({ ...prev, ...mapFallback(parentMap) }));
      } else {
        // Variants view: check if list contains variants or products with nested variants
        const allExtractedVariants = [];
        const parentMap = { ...parentProductMap };

        list.forEach(item => {
          if (item.id && !item.parent_product_id) {
            parentMap[item.id] = item;
          }
          if (item.parent_product_id) {
            allExtractedVariants.push(item);
          }
          if (Array.isArray(item.variants) && item.variants.length > 0) {
            item.variants.forEach(v => {
              allExtractedVariants.push({
                ...v,
                parent_product_id: item.id,
                template: { id: item.id, name: item.name || item.product_name, sku: item.sku }
              });
            });
          }
        });

        setParentProductMap(parentMap);

        if (allExtractedVariants.length > 0) {
          setVariantsList(allExtractedVariants);
        } else {
          setVariantsList(list);
        }
      }

      // Also fetch brands for the dropdowns
      const brandsRes = await api.get('/admin/brands');
      setBrands(brandsRes.data.data || []);

      const groupRes = await api.get('/admin/groups');
      setGroups(groupRes.data?.data || groupRes.data || []);

      const compRes = await api.get('/admin/companies');
      setCompanies(compRes.data?.data || compRes.data || []);

      try {
        const whRes = await api.get('/admin/warehouses');
        setWarehouses(whRes.data?.data || whRes.data || []);
      } catch (e) {
        console.error("Failed to fetch warehouses:", e);
      }

      setLoading(false);
    } catch (error) {
      console.error("Products fetch error", error);
      setLoading(false);
    }
  };

  const mapFallback = (map) => map || {};

  // Prefetch templates list for parent selector in AddVariantModal
  useEffect(() => {
    const fetchTemplatesList = async () => {
      try {
        let res;
        try {
          res = await api.get('/admin/products?templates_only=true');
        } catch (e) {
          if (e.response?.status === 500) {
            res = await api.get('/admin/products');
          } else {
            throw e;
          }
        }
        const data = res.data?.data || res.data || [];
        if (Array.isArray(data)) {
          setTemplatesOnlyList(data.filter(p => !p.parent_product_id));
          const map = {};
          data.forEach(t => { if (t.id) map[t.id] = t; });
          setParentProductMap(prev => ({ ...prev, ...map }));
        }
      } catch (e) {
        // silent fallback
      }
    };
    fetchTemplatesList();
  }, []);

  useEffect(() => {
    fetchOccasions();
  }, []);

  useEffect(() => {
    fetchProducts();
  }, [viewMode, search, filterGroupId, filterStatus, filterOccasionBased, filterOccasionType, filterOccasionId]);

  const handleAddNewGroup = (explicitParentId) => {
    setModalGroupParentId(explicitParentId !== undefined ? explicitParentId : (groupId || ''));
    setModalGroupName('');
    setModalGroupDesc('');
    setModalGroupImages([]);
    setShowAddGroupModal(true);
  };

  const submitNewGroup = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        name: modalGroupName,
        description: modalGroupDesc,
        status: 'Active',
        parent_id: modalGroupParentId ? parseInt(modalGroupParentId) : null,
        images: modalGroupImages,
        image_url: modalGroupImages.length > 0 ? modalGroupImages[0] : null,
        image: modalGroupImages.length > 0 ? modalGroupImages[0] : null
      };
      const res = await api.post('/admin/groups', payload);
      const newGroup = res.data?.data || res.data;
      setGroups([...groups, newGroup]);
      setGroupId(newGroup.id);
      setShowAddGroupModal(false);
      setModalGroupName('');
      setModalGroupDesc('');
      setModalGroupParentId('');
      setModalGroupImages([]);
      setGroupRefresh(prev => prev + 1);
    } catch (err) {
      alert("Failed to add group");
    }
  };





  const handleModalAddOfficer = () => {
    setModalCompanyOfficers([...modalCompanyOfficers, '']);
  };

  const handleModalOfficerChange = (index, value) => {
    const next = [...modalCompanyOfficers];
    next[index] = value;
    setModalCompanyOfficers(next);
  };

  const handleModalRemoveOfficer = (index) => {
    if (modalCompanyOfficers.length === 1) {
      setModalCompanyOfficers(['']);
    } else {
      setModalCompanyOfficers(modalCompanyOfficers.filter((_, i) => i !== index));
    }
  };

  const handleCompanySelect = async (selectedCompanyName, directCompObj = null) => {
    setCompanyName(selectedCompanyName);
    setBrandId('');

    if (!selectedCompanyName) {
      setCompanyInheritedMedia(null);
      setCompanyInheritedSchemes(null);
      return;
    }

    // Locate company in companies list or directCompObj
    const matched = directCompObj || companies.find(
      c => (c.name && c.name.toLowerCase() === selectedCompanyName.toLowerCase()) ||
           (c.company_name && c.company_name.toLowerCase() === selectedCompanyName.toLowerCase())
    );

    let fullComp = matched ? extractCompanyMedia(matched) : null;
    setIsInheritingMedia(true);

    if (matched?.id) {
      try {
        const res = await api.get(`/admin/companies/${matched.id}`);
        const fresh = res.data?.data || res.data;
        if (fresh) fullComp = extractCompanyMedia({ ...matched, ...fresh });
      } catch (err) {
        console.warn("Could not fetch fresh company details for auto-fetch:", err);
      }
    }
    setIsInheritingMedia(false);

    if (!fullComp) return;

    // Brochure
    const compBrochureUrl = fullComp.brochureUrl || fullComp.brochure_url || '';
    const compBrochureName = fullComp.brochureName || fullComp.brochure_name ||
      (compBrochureUrl ? `${fullComp.company_name || fullComp.name || selectedCompanyName}_Brochure.pdf` : '');

    // Video
    const compVideoUrl = fullComp.videoUrl || fullComp.video_url || '';

    // Gallery images
    const compImages = fullComp.images || [];

    // Primary Logo
    const compLogoUrl = fullComp.logoUrl || fullComp.image_url || (compImages.length > 0 ? compImages[0] : '');

    const hasAnyMedia = Boolean(compBrochureUrl || compVideoUrl || compImages.length > 0 || compLogoUrl);

    setCompanyInheritedMedia({
      companyName: selectedCompanyName,
      companyId: fullComp.id,
      logoUrl: compLogoUrl,
      brochureUrl: compBrochureUrl,
      brochureName: compBrochureName,
      videoUrl: compVideoUrl,
      images: compImages,
      hasMedia: hasAnyMedia
    });

    // Auto-inherit Brochure if product brochure is currently empty or was previously auto-inherited
    if (compBrochureUrl && (!companyBrochure?.url || companyBrochure?.isInherited)) {
      setCompanyBrochure({
        url: compBrochureUrl,
        name: compBrochureName,
        isInherited: true,
        sourceCompany: selectedCompanyName
      });
    }

    // Auto-inherit Video if product videos is currently empty or was previously auto-inherited
    if (compVideoUrl && (productVideos.length === 0 || productVideos._isInherited)) {
      const vArr = [compVideoUrl];
      vArr._isInherited = true;
      setProductVideos(vArr);
    }

    // Auto-inherit Schemes & Turnover Targets
    const compSchemes = fullComp.schemes || {
      product_pe_product: fullComp.product_pe_product || '',
      discount_on_product: fullComp.discount_on_product || '',
      product_target_scheme: fullComp.product_target_scheme || '',
      discount_on_bill_amount: fullComp.discount_on_bill_amount || '',
      quarterly_discount_on_turnover: fullComp.quarterly_discount_on_turnover || '',
      yearly_discount_on_turnover: fullComp.yearly_discount_on_turnover || '',
      seasonal_scheme_name: fullComp.seasonal_scheme_name || '',
      seasonal_period_start: fullComp.seasonal_period_start || '',
      seasonal_period_end: fullComp.seasonal_period_end || '',
      seasonal_applicability: fullComp.seasonal_applicability || 'All Products',
      seasonal_frequency: fullComp.seasonal_frequency || 'Yearly'
    };

    const compHasSchemes = Boolean(fullComp.hasSchemes || Object.values(compSchemes).some(v => Boolean(v && String(v).trim())));

    setCompanyInheritedSchemes({
      companyName: selectedCompanyName,
      companyId: fullComp.id,
      schemes: compSchemes,
      hasSchemes: compHasSchemes
    });

    // Auto-match schemes if product currently has no schemes configured
    const isProductSchemesEmpty = !productPeProduct && !discountOnProduct && !productTargetScheme && !discountOnBillAmount && !quarterlyDiscountOnTurnover && !yearlyDiscountOnTurnover && !seasonalSchemeName;

    if (isProductSchemesEmpty && compHasSchemes) {
      if (compSchemes.product_pe_product) setProductPeProduct(compSchemes.product_pe_product);
      if (compSchemes.discount_on_product) setDiscountOnProduct(compSchemes.discount_on_product);
      if (compSchemes.product_target_scheme) setProductTargetScheme(compSchemes.product_target_scheme);
      if (compSchemes.discount_on_bill_amount) setDiscountOnBillAmount(compSchemes.discount_on_bill_amount);
      if (compSchemes.quarterly_discount_on_turnover) setQuarterlyDiscountOnTurnover(compSchemes.quarterly_discount_on_turnover);
      if (compSchemes.yearly_discount_on_turnover) setYearlyDiscountOnTurnover(compSchemes.yearly_discount_on_turnover);
      if (compSchemes.seasonal_scheme_name) setSeasonalSchemeName(compSchemes.seasonal_scheme_name);
      if (compSchemes.seasonal_period_start) setSeasonalPeriodStart(compSchemes.seasonal_period_start);
      if (compSchemes.seasonal_period_end) setSeasonalPeriodEnd(compSchemes.seasonal_period_end);
      if (compSchemes.seasonal_applicability) setSeasonalApplicability(compSchemes.seasonal_applicability);
      if (compSchemes.seasonal_frequency) setSeasonalFrequency(compSchemes.seasonal_frequency);
    }
  };

  const handleApplyCompanySchemes = () => {
    if (!companyInheritedSchemes?.schemes) return;
    const s = companyInheritedSchemes.schemes;
    if (s.product_pe_product) setProductPeProduct(s.product_pe_product);
    if (s.discount_on_product) setDiscountOnProduct(s.discount_on_product);
    if (s.product_target_scheme) setProductTargetScheme(s.product_target_scheme);
    if (s.discount_on_bill_amount) setDiscountOnBillAmount(s.discount_on_bill_amount);
    if (s.quarterly_discount_on_turnover) setQuarterlyDiscountOnTurnover(s.quarterly_discount_on_turnover);
    if (s.yearly_discount_on_turnover) setYearlyDiscountOnTurnover(s.yearly_discount_on_turnover);
    if (s.seasonal_scheme_name) setSeasonalSchemeName(s.seasonal_scheme_name);
    if (s.seasonal_period_start) setSeasonalPeriodStart(s.seasonal_period_start);
    if (s.seasonal_period_end) setSeasonalPeriodEnd(s.seasonal_period_end);
    if (s.seasonal_applicability) setSeasonalApplicability(s.seasonal_applicability);
    if (s.seasonal_frequency) setSeasonalFrequency(s.seasonal_frequency);
  };

  const handleImportCompanyImages = () => {
    if (!companyInheritedMedia?.images?.length) return;
    const existing = new Set(productImages);
    const newImgs = companyInheritedMedia.images.filter(img => !existing.has(img));
    if (newImgs.length === 0) {
      alert("All photos from this company gallery are already added to the element.");
      return;
    }
    setProductImages(prev => [...prev, ...newImgs]);
  };

  const handleClearInheritedMedia = () => {
    if (companyBrochure?.isInherited) {
      setCompanyBrochure({ url: '', name: '', isInherited: false });
    }
    if (productVideos._isInherited || (companyInheritedMedia?.videoUrl && productVideos.includes(companyInheritedMedia.videoUrl))) {
      setProductVideos([]);
    }
    setCompanyInheritedMedia(null);
  };

  const handleAddNewCompany = () => {
    setShowAddCompanyModal(true);
  };

  const submitNewCompany = async (e) => {
    e.preventDefault();
    try {
      const validOfficers = modalCompanyOfficers.map(o => o.trim()).filter(Boolean);
      const res = await api.post('/admin/companies', {
        name: modalCompanyName,
        description: modalCompanyDesc,
        scheme: modalCompanyScheme,
        offer: modalCompanyOffer,
        margin: modalCompanyMargin,
        authorized_distributor: modalCompanyDistributor,
        company_officer_name: validOfficers.join(', '),
        company_officers: validOfficers,
        company_images: modalCompanyImages,
        images: modalCompanyImages,
        image_url: modalCompanyImages.length > 0 ? modalCompanyImages[0] : null,
        brochure_images: modalCompanyBrochures,
        brochures: modalCompanyBrochures,
        brochure_urls: modalCompanyBrochures,
        brochure_url: modalCompanyBrochures.length > 0 ? modalCompanyBrochures[0] : null,
        status: 'Active'
      });
      const newCompany = res.data?.data || res.data;
      setCompanies([...companies, newCompany]);
      handleCompanySelect(newCompany.name || modalCompanyName, newCompany);
      setShowAddCompanyModal(false);
      setModalCompanyName('');
      setModalCompanyDesc('');
      setModalCompanyScheme('');
      setModalCompanyOffer('');
      setModalCompanyMargin('');
      setModalCompanyDistributor('');
      setModalCompanyOfficers(['']);
      setModalCompanyImages([]);
      setModalCompanyBrochures([]);
    } catch (err) {
      alert("Failed to add company");
    }
  };

  const handleAddNewBrand = () => {
    if (!companyName) {
      alert("Please select a Company first");
      return;
    }
    setShowAddBrandModal(true);
  };
  const submitNewBrand = async (e) => {
    e.preventDefault();
    try {
      const res = await api.post('/admin/brands', {
        name: modalBrandName,
        description: modalBrandDesc,
        company_name: companyName,
        scheme: modalBrandScheme,
        offer: modalBrandOffer,
        margin: modalBrandMargin,
        authorized_distributor: modalBrandDistributor,
        company_officer_name: modalBrandOfficer,
        status: 'Active'
      });
      const newBrand = res.data?.data || res.data;
      setBrands([...brands, newBrand]);
      setBrandId(newBrand.id);
      setShowAddBrandModal(false);
      setModalBrandName('');
      setModalBrandDesc('');
      setModalBrandScheme('');
      setModalBrandOffer('');
      setModalBrandMargin('');
      setModalBrandDistributor('');
      setModalBrandOfficer('');
    } catch (err) {
      alert("Failed to add brand");
    }
  };

  const submitNewWarehouse = async (e) => {
    e.preventDefault();
    if (!modalWhName.trim()) {
      alert("Warehouse Name is required");
      return;
    }
    try {
      const payload = {
        name: modalWhName.trim(),
        warehouse_code: modalWhCode.trim() || null,
        code: modalWhCode.trim() || null,
        warehouse_type: modalWhType || 'Central Distribution Center',
        type: modalWhType || 'Central Distribution Center',
        status: modalWhStatus || 'Active',
        address_line_1: modalWhAddress.trim() || null,
        address: modalWhAddress.trim() || null,
        city: modalWhCity.trim() || 'N/A',
        state: modalWhState.trim() || null,
        country: modalWhCountry.trim() || 'India',
        pincode: modalWhPincode.trim() || null,
        contact_person: modalWhManagerName.trim() || null,
        manager_name: modalWhManagerName.trim() || null,
        phone_number: modalWhContactNumber.trim() || null,
        contact_number: modalWhContactNumber.trim() || null,
        email: modalWhEmail.trim() || null,
        total_capacity: modalWhCapacity.trim() || null,
        capacity: modalWhCapacity.trim() || null,
        is_default: modalWhIsDefault
      };
      const res = await api.post('/admin/warehouses', payload);
      const newWh = res.data?.data || res.data;
      setWarehouses(prev => [...prev, newWh]);
      if (newWh.id) {
        setWarehouseId(String(newWh.id));
      }
      setWarehouseLocation(newWh.name || modalWhName);
      setShowAddWarehouseModal(false);
      setModalWhName('');
      setModalWhCode('');
      setModalWhType('Central Distribution Center');
      setModalWhStatus('Active');
      setModalWhAddress('');
      setModalWhCity('');
      setModalWhState('');
      setModalWhCountry('India');
      setModalWhPincode('');
      setModalWhManagerName('');
      setModalWhContactNumber('');
      setModalWhEmail('');
      setModalWhCapacity('');
      setModalWhIsDefault(false);
    } catch (err) {
      console.error("Failed to add warehouse:", err);
      alert(err.response?.data?.message || "Failed to add warehouse");
    }
  };

  const handleCheckHsn = async () => {
    const code = (hsnCode || '').trim();
    if (!code) {
      alert('Please enter an HSN Code to check.');
      return;
    }

    setHsnCheckStatus({ loading: true });

    // 1. Immediate instant format verification
    const digitsOnly = code.replace(/\D/g, '');
    const isStandardDigits = [2, 4, 6, 8].includes(digitsOnly.length);

    try {
      // 2. Fast non-blocking lookup in customs records with 1.5s timeout
      const customsRes = await api.get('/admin/customs', { timeout: 1500 });
      const list = customsRes.data?.data || customsRes.data || [];
      const cleaned = code.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();

      const matched = list.find(item => {
        const localHsn = (item.local_tariff_hsn_code || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
        const globalHs = (item.global_hs6_code || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
        return (localHsn && localHsn === cleaned) || (globalHs && globalHs === cleaned) || (localHsn && localHsn.startsWith(cleaned)) || (cleaned && localHsn.startsWith(cleaned));
      });

      if (matched) {
        setHsnCheckStatus({
          valid: true,
          details: `Verified with Customs Tariff (Duty: ${matched.import_duty_rate || 0}%, Country: ${matched.country_code || 'All'})`
        });
        return;
      }
    } catch (err) {
      // Ignore network delays and proceed immediately with standard validation
    }

    if (isStandardDigits) {
      setHsnCheckStatus({
        valid: true,
        details: `Valid standard ${digitsOnly.length}-digit HSN/Tariff code format.`
      });
    } else if (digitsOnly.length > 0) {
      setHsnCheckStatus({
        valid: false,
        details: `Standard HSN code uses 2, 4, 6, or 8 numeric digits (currently ${digitsOnly.length} digits).`
      });
    } else {
      setHsnCheckStatus({
        valid: false,
        details: 'Invalid HSN format. Please enter numeric HSN digits.'
      });
    }
  };

  const handleSubmit = async (e) => {
    if (e && e.preventDefault) e.preventDefault();
    if (activeTab !== 'review') {
      setActiveTab('review');
      return;
    }
    try {
      const effectiveDimUnit = dimensionUnit === 'custom' ? (customDimensionUnit.trim() || '') : dimensionUnit;
      const effectiveVolUnit = volumeUnit === 'custom' ? (customVolumeUnit.trim() || '') : volumeUnit;
      const effectiveWtUnit = weightUnit === 'custom' ? (customWeightUnit.trim() || '') : weightUnit;

      if (
        (purchasePrice !== '' && parseFloat(purchasePrice) < 0) ||
        (sellingPrice !== '' && parseFloat(sellingPrice) < 0) ||
        (mrp !== '' && parseFloat(mrp) < 0) ||
        (distributorPrice !== '' && parseFloat(distributorPrice) < 0) ||
        (profitPercent !== '' && parseFloat(profitPercent) < 0) ||
        (sellingPriceWholesale !== '' && parseFloat(sellingPriceWholesale) < 0) ||
        (sellingPriceRetail !== '' && parseFloat(sellingPriceRetail) < 0) ||
        (gstRate !== '' && parseFloat(gstRate) < 0) ||
        (purchaseQuantity !== '' && parseInt(purchaseQuantity, 10) < 0) ||
        (reorderLevel !== '' && parseInt(reorderLevel, 10) < 0)
      ) {
        alert("Pricing, GST rate, and quantities cannot be negative.");
        return;
      }

      if (hasVariants === 'Yes') {
        const hasNegativeVariantPrice = productVariants.some(v => {
          const sPrice = parseFloat(v.selling_price);
          const pExtra = parseFloat(v.price_extra);
          const pkgs = Array.isArray(v.packagings) ? v.packagings : (Array.isArray(v.packaging) ? v.packaging : []);
          const hasNegPkg = pkgs.some(p => (p.selling_price !== '' && parseFloat(p.selling_price) < 0) || (p.quantity && parseInt(p.quantity, 10) < 0));
          return (!isNaN(sPrice) && sPrice < 0) || (!isNaN(pExtra) && pExtra < 0) || hasNegPkg;
        });
        if (hasNegativeVariantPrice) {
          alert("Variant selling prices, extra prices, or packaging prices cannot be negative.");
          return;
        }
      }

      if (
        (lotNumber !== '' && !/^\d+$/.test(String(lotNumber).trim())) ||
        (lotNumber !== '' && Number(lotNumber) < 0)
      ) {
        alert("Lot Number must contain only positive numbers.");
        return;
      }

      if (
        (batchNumber !== '' && !/^\d+$/.test(String(batchNumber).trim())) ||
        (batchNumber !== '' && Number(batchNumber) < 0)
      ) {
        alert("Batch Number must contain only positive numbers.");
        return;
      }

      const res = await api.post('/admin/products', {
        product_name: productName,
        sku: internalSku || null,
        product_alias: productAliases.filter(a => a.trim() !== '').join(',') || null,
        brand_id: brandId || null,
        group_id: groupId ? parseInt(groupId, 10) : null,

        short_description: productDescription || null,
        purchase_price: purchasePrice || 0,
        purchase_quantity: purchaseQuantity ? parseInt(purchaseQuantity, 10) : 0,
        lot_number: lotNumber || null,
        batch_number: batchNumber || null,
        selling_price: sellingPrice || 0,
        mrp: mrp ? parseFloat(mrp) : 0,
        distributor_price: distributorPrice ? parseFloat(distributorPrice) : 0,
        distributor_profit_percent: distributorProfitPercent ? parseFloat(distributorProfitPercent) : 0,
        profit_percent: profitPercent ? parseFloat(profitPercent) : 0,
        selling_price_wholesale: sellingPriceWholesale ? parseFloat(sellingPriceWholesale) : 0,
        wholesale_profit_percent: wholesaleProfitPercent ? parseFloat(wholesaleProfitPercent) : 0,
        selling_price_retail: sellingPriceRetail ? parseFloat(sellingPriceRetail) : 0,
        retail_profit_percent: retailProfitPercent ? parseFloat(retailProfitPercent) : 0,
        currency: currency,
        gst_rate: gstRate || 0,
        reorder_level: reorderLevel || 0,
        reorder_note: reorderNote || null,
        min_stock_level: 0,
        max_stock_level: 0,
        safety_stock: safetyStock ? parseInt(safetyStock, 10) : 0,
        lead_time_days: 7,
        reorder_qty: 0,
        auto_reorder: false,
        gtin_ean_upc: barcode || null,
        hsn_code: hsnCode || null,
        item_type: productType || null,
        status: 'Active',
        attributes: attributes.filter(a => a.name.trim() !== '' && a.value.trim() !== ''),
        physical_appearance: physicalAppearance || null,
        physical_shape: physicalAppearance || null,
        size: size || null,
        packaging: packaging || null,
        length: length ? (effectiveDimUnit ? `${length} ${effectiveDimUnit}` : length) : null,
        breadth: breadth ? (effectiveDimUnit ? `${breadth} ${effectiveDimUnit}` : breadth) : null,
        thickness: thickness ? (effectiveDimUnit ? `${thickness} ${effectiveDimUnit}` : thickness) : null,
        volume: volume ? (effectiveVolUnit ? `${volume} ${effectiveVolUnit}` : volume) : null,
        net_weight: netWeight ? (effectiveWtUnit ? `${netWeight} ${effectiveWtUnit}` : netWeight) : null,
        gross_weight: grossWeight ? (effectiveWtUnit ? `${grossWeight} ${effectiveWtUnit}` : grossWeight) : null,
        image_url: productImages.length > 0 ? productImages[0] : null,
        images: productImages,
        video_url: productVideos.length > 0 ? productVideos[0] : null,
        video_urls: productVideos.length > 0 ? productVideos : null,
        company_brochure_url: companyBrochure?.url || null,
        company_brochure_name: companyBrochure?.name || null,
        barcode_image_url: barcodeImageUrl || null,
        manufacturing_date: manufacturingDate || null,
        expiry_date: expiryDate || null,
        best_before_date: bestBeforeDate || null,
        warehouse_location: warehouseLocation || (warehouses.find(w => String(w.id) === String(warehouseId))?.name) || null,
        default_warehouse_id: warehouseId ? parseInt(warehouseId, 10) : (warehouses.find(w => w.name === warehouseLocation)?.id || null),
        rack_number: rackNumber || null,
        shelf_number: shelfNumber || null,
        bin_location: binLocation || null,
        opening_stock: openingStock ? parseInt(openingStock, 10) : (purchaseQuantity ? parseInt(purchaseQuantity, 10) : null),
        safety_stock: safetyStock ? parseInt(safetyStock, 10) : null,
        warehouse_allocations: (warehouseId || warehouseLocation) ? [{
          warehouse_id: warehouseId ? parseInt(warehouseId, 10) : (warehouses.find(w => w.name === warehouseLocation)?.id || null),
          is_primary: true,
          opening_stock: openingStock ? parseInt(openingStock, 10) : (purchaseQuantity ? parseInt(purchaseQuantity, 10) : 0),
          rack_number: rackNumber || null,
          shelf_number: shelfNumber || null,
          bin_location: binLocation || null,
          safety_stock: safetyStock ? parseInt(safetyStock, 10) : null,
          reorder_level: reorderLevel ? parseInt(reorderLevel, 10) : null
        }].filter(a => a.warehouse_id) : [],
        product_pe_product: productPeProduct || null,
        discount_on_product: discountOnProduct || null,
        product_target_scheme: productTargetScheme || null,
        discount_on_bill_amount: discountOnBillAmount || null,
        quarterly_discount_on_turnover: quarterlyDiscountOnTurnover || null,
        yearly_discount_on_turnover: yearlyDiscountOnTurnover || null,
        seasonal_scheme_name: seasonalSchemeName || null,
        seasonal_frequency: seasonalFrequency || null,
        seasonal_applicability: seasonalApplicability || null,
        seasonal_period_start: seasonalPeriodStart || null,
        seasonal_period_end: seasonalPeriodEnd || null,
        is_occasion_based: isOccasionBased === 'Yes',
        occasion_ids: isOccasionBased === 'Yes' ? selectedOccasionIds : [],
        has_variants: hasVariants === 'Yes',
        variant_attributes: hasVariants === 'Yes' ? variantAttributes : [],
        variants: hasVariants === 'Yes' ? productVariants.map(v => {
          const vSellingPrice = parseFloat(v.selling_price) || (parseFloat(sellingPrice) || 0) + (parseFloat(v.price_extra) || 0);
          const vPurchasePrice = parseFloat(v.purchase_price) || (parseFloat(purchasePrice) || 0);
          const vMrp = parseFloat(v.mrp) || (parseFloat(mrp) || vSellingPrice);
          const vOpeningStock = parseInt(v.opening_stock ?? v.stock ?? (purchaseQuantity || 0), 10);
          const rawPackagings = Array.isArray(v.packagings) ? v.packagings : (Array.isArray(v.packaging) ? v.packaging : []);

          return {
            name: v.name || v.variant_name || `${productName} (${Object.values(v.combination || v.variant_attributes || {}).join(' - ')})`,
            variant_name: v.name || v.variant_name,
            sku: v.sku,
            variant_attributes: v.variant_attributes || v.combination || {},
            combination: v.combination || v.variant_attributes || {},
            purchase_price: vPurchasePrice,
            selling_price: vSellingPrice,
            mrp: vMrp,
            opening_stock: vOpeningStock,
            warehouse_id: v.warehouse_id ? parseInt(v.warehouse_id, 10) : (warehouseId ? parseInt(warehouseId, 10) : null),
            default_warehouse_id: v.warehouse_id ? parseInt(v.warehouse_id, 10) : (warehouseId ? parseInt(warehouseId, 10) : null),
            warehouse_allocations: (v.warehouse_id || warehouseId) ? [{
              warehouse_id: parseInt(v.warehouse_id || warehouseId, 10),
              is_primary: true,
              opening_stock: vOpeningStock,
              rack_number: rackNumber || null,
              shelf_number: shelfNumber || null,
              bin_location: binLocation || null,
              safety_stock: safetyStock ? parseInt(safetyStock, 10) : null
            }] : [],
            gtin_ean_upc: v.gtin_ean_upc || v.barcode || `${v.sku}-UNIT`,
            barcode: v.gtin_ean_upc || v.barcode || `${v.sku}-UNIT`,
            price_extra: parseFloat(v.price_extra) || 0,
            packagings: rawPackagings.map(p => {
              const qty = parseInt(p.quantity || p.quantity_per_pack || 24, 10);
              const pCode = p.package_barcode || p.barcode || `${v.sku}-C${qty}`;
              return {
                package_name: p.package_name || `Pack of ${qty}`,
                quantity: qty,
                quantity_per_pack: qty,
                package_barcode: pCode,
                barcode: pCode,
                package_qr_payload: p.package_qr_payload || JSON.stringify({ type: "PACKAGE", sku: v.sku, qty }),
                selling_price: parseFloat(p.selling_price) || (vSellingPrice * qty * 0.95)
              };
            }),
            packaging: rawPackagings.map(p => {
              const qty = parseInt(p.quantity || p.quantity_per_pack || 24, 10);
              const pCode = p.package_barcode || p.barcode || `${v.sku}-C${qty}`;
              return {
                id: p.id,
                package_name: p.package_name || `Pack of ${qty}`,
                quantity_per_pack: qty,
                quantity: qty,
                barcode: pCode,
                package_barcode: pCode,
                package_qr_payload: p.package_qr_payload || JSON.stringify({ type: "PACKAGE", sku: v.sku, qty }),
                selling_price: parseFloat(p.selling_price) || (vSellingPrice * qty * 0.95)
              };
            })
          };
        }) : []
      });
      setProductImages([]);
      setProductVideos([]);
      setCompanyBrochure({ url: '', name: '' });
      setCompanyInheritedMedia(null);
      setCompanyName('');
      setBaseProductName('');
      setProductName('');
      setInternalSku('');
      setProductDescription('');
      setProductAliases(['']);
      setHasVariants('No');
      setVariantAttributes([]);
      setProductVariants([]);
      setBrandId('');
      setPurchasePrice('');
      setPurchaseQuantity('');
      setLotNumber('');
      setBatchNumber('');
      setSellingPrice('');
      setMrp('');
      setDistributorPrice('');
      setDistributorProfitPercent('');
      setProfitPercent('');
      setSellingPriceWholesale('');
      setWholesaleProfitPercent('');
      setSellingPriceRetail('');
      setRetailProfitPercent('');
      setGstRate('');
      setReorderLevel('');
      setReorderNote('');
      setBarcode('');
      setBarcodeImageUrl('');
      setHsnCode('');
      setWarehouseLocation('');
      setWarehouseId('');
      setRackNumber('');
      setShelfNumber('');
      setBinLocation('');
      setOpeningStock('');
      setSafetyStock('');
      setManufacturingDate('');
      setExpiryDate('');
      setBestBeforeDate('');
      setProductPeProduct('');
      setDiscountOnProduct('');
      setProductTargetScheme('');
      setDiscountOnBillAmount('');
      setQuarterlyDiscountOnTurnover('');
      setYearlyDiscountOnTurnover('');
      setSeasonalSchemeName('');
      setSeasonalFrequency('Yearly');
      setSeasonalApplicability('All Products');
      setSeasonalPeriodStart('');
      setSeasonalPeriodEnd('');
      setGroupId('');
      setProductType('');
      setPhysicalAppearance('');
      setSize('');
      setPackaging('');
      setLength('');
      setBreadth('');
      setThickness('');
      setDimensionUnit('cm');
      setCustomDimensionUnit('');
      setVolume('');
      setVolumeUnit('ml');
      setCustomVolumeUnit('');
      setNetWeight('');
      setGrossWeight('');
      setWeightUnit('g');
      setCustomWeightUnit('');
      setIsOccasionBased('No');
      setSelectedOccasionType('');
      setSelectedOccasionIds([]);
      setIsEditingName(false);
      setIsCustomName(false);
      setActiveTab('info');
      setShowForm(false);
      alert("Product added successfully!");
      fetchProducts();
    } catch (error) {
      console.error("Failed to create product", error);
      alert("Failed to create product");
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to logically delete this product?')) {
      try {
        const res = await api.delete(`/admin/products/${id}`);
        alert(res.data?.message || "Product logically deleted successfully!");
        fetchProducts();
      } catch (error) {
        console.error("Failed to delete product", error);
        alert(error.response?.data?.message || "Failed to delete product");
      }
    }
  };

  const [newGroupName, setNewGroupName] = useState('');
  const [newGroupDescription, setNewGroupDescription] = useState('');
  const [newGroupStatus, setNewGroupStatus] = useState('Active');
  const [newGroupParentId, setNewGroupParentId] = useState('');
  const handleGroupSubmit = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        name: newGroupName,
        description: newGroupDescription,
        status: newGroupStatus,
        parent_id: newGroupParentId ? parseInt(newGroupParentId) : null
      };
      await api.post('/admin/groups', payload);
      setNewGroupName('');
      setNewGroupDescription('');
      setNewGroupStatus('Active');
      setNewGroupParentId('');
      setShowGroupForm(false);
      fetchProducts(); // refresh groups dropdown

    } catch (err) {
      alert("Failed to create group");
    }
  };

  const getCurrentFormProduct = () => ({
    name: productName || baseProductName || 'New Product',
    product_name: productName || baseProductName || 'New Product',
    sku: internalSku,
    internal_sku: internalSku,
    group_id: groupId,
    brand_id: brandId,
    company_name: companyName,
    description: productDescription,
    product_alias: productAliases.filter(Boolean).join(', '),
    item_type: 'Goods',
    product_type: productType,
    physical_appearance: physicalAppearance,
    size,
    packaging,
    length,
    breadth,
    thickness,
    dimension_unit: dimensionUnit === 'custom' ? customDimensionUnit : dimensionUnit,
    volume,
    volume_unit: volumeUnit === 'custom' ? customVolumeUnit : volumeUnit,
    net_weight: netWeight,
    gross_weight: grossWeight,
    weight_unit: weightUnit === 'custom' ? customWeightUnit : weightUnit,
    selling_price: sellingPrice || 0,
    mrp: mrp || 0,
    purchase_price: purchasePrice || 0,
    distributor_price: distributorPrice || 0,
    profit_percent: profitPercent || 0,
    selling_price_wholesale: sellingPriceWholesale || 0,
    selling_price_retail: sellingPriceRetail || 0,
    purchase_quantity: purchaseQuantity || openingStock || 0,
    reorder_level: reorderLevel || 0,
    currency,
    gst_rate: gstRate || 0,
    hsn_code: hsnCode,
    gtin_ean_upc: barcode,
    lot_number: lotNumber,
    batch_number: batchNumber,
    manufacturing_date: manufacturingDate,
    expiry_date: expiryDate,
    best_before_date: bestBeforeDate,
    warehouse_location: warehouseLocation,
    rack_number: rackNumber,
    shelf_number: shelfNumber,
    bin_location: binLocation,
    product_pe_product: productPeProduct,
    discount_on_product: discountOnProduct,
    product_target_scheme: productTargetScheme,
    discount_on_bill_amount: discountOnBillAmount,
    quarterly_discount_on_turnover: quarterlyDiscountOnTurnover,
    yearly_discount_on_turnover: yearlyDiscountOnTurnover,
    seasonal_scheme_name: seasonalSchemeName,
    occasions: occasionsList.filter(o => selectedOccasionIds.includes(o.id)),
    image_url: productImages[0] || '',
    images: productImages,
    barcode_image_url: barcodeImageUrl,
    attributes: attributes.filter(a => a.name && a.value),
    status: 'Active'
  });

  return (
    <div>
      {/* 1. Page Header Navigation & View Switcher */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px', flexWrap: 'wrap', gap: '16px' }}>
        {/* Segmented View Switcher: Product Templates vs Product Variants */}
        <div style={{ display: 'inline-flex', backgroundColor: '#e2e8f0', padding: '4px', borderRadius: '10px' }}>
          <button
            type="button"
            onClick={() => setViewMode('templates')}
            style={{
              padding: '8px 18px',
              borderRadius: '7px',
              border: 'none',
              fontWeight: '700',
              fontSize: '0.88rem',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              backgroundColor: viewMode === 'templates' ? '#ffffff' : 'transparent',
              color: viewMode === 'templates' ? '#0f172a' : '#64748b',
              boxShadow: viewMode === 'templates' ? '0 2px 5px rgba(0,0,0,0.08)' : 'none',
              transition: 'all 0.2s'
            }}
          >
            <Box size={16} color={viewMode === 'templates' ? '#6366f1' : '#64748b'} />
            Product Templates
            {viewMode === 'templates' && !loading && (
              <span style={{ fontSize: '0.72rem', backgroundColor: '#ede9fe', color: '#4338ca', padding: '1px 6px', borderRadius: '999px' }}>
                {products.length}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => setViewMode('variants')}
            style={{
              padding: '8px 18px',
              borderRadius: '7px',
              border: 'none',
              fontWeight: '700',
              fontSize: '0.88rem',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              backgroundColor: viewMode === 'variants' ? '#ffffff' : 'transparent',
              color: viewMode === 'variants' ? '#0f172a' : '#64748b',
              boxShadow: viewMode === 'variants' ? '0 2px 5px rgba(0,0,0,0.08)' : 'none',
              transition: 'all 0.2s'
            }}
          >
            <Layers size={16} color={viewMode === 'variants' ? '#6366f1' : '#64748b'} />
            Product Variants
            {viewMode === 'variants' && !loading && (
              <span style={{ fontSize: '0.72rem', backgroundColor: '#ede9fe', color: '#4338ca', padding: '1px 6px', borderRadius: '999px' }}>
                {variantsList.length}
              </span>
            )}
          </button>
        </div>

        {/* Action Buttons */}
        <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', alignItems: 'center' }}>
          <button
            type="button"
            onClick={() => setShowAddVariantModal(true)}
            style={{
              backgroundColor: '#6366f1',
              color: 'white',
              border: 'none',
              padding: '10px 18px',
              borderRadius: '6px',
              fontWeight: '600',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              boxShadow: '0 4px 12px rgba(99, 102, 241, 0.2)',
              fontSize: '0.88rem'
            }}
          >
            <Plus size={18} /> Add Variant
          </button>

          <button
            style={{
              backgroundColor: '#1abc9c',
              color: 'white',
              border: 'none',
              padding: '10px 18px',
              borderRadius: '6px',
              fontWeight: '500',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              fontSize: '0.88rem'
            }}
            onClick={() => setShowForm(true)}
          >
            <Plus size={18} /> Add Element
          </button>

          <button
            type="button"
            style={{
              backgroundColor: '#10b981',
              color: 'white',
              border: 'none',
              padding: '10px 16px',
              borderRadius: '6px',
              fontWeight: '600',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
              fontSize: '0.88rem'
            }}
            onClick={() => exportAllProductsExcel(viewMode === 'variants' ? variantsList : products, groups, brands)}
          >
            <FileSpreadsheet size={18} /> Export to Excel
          </button>
        </div>
      </div>



      <div style={{ display: 'flex', gap: '16px', marginBottom: '24px', flexWrap: 'wrap' }}>
        <SearchAutocomplete
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by name, SKU, occasion, barcode..."
          style={{ flex: '1 1 200px' }}
        />
        <select className="form-control" style={{ flex: '1 1 150px' }} value={filterGroupId} onChange={(e) => setFilterGroupId(e.target.value)}>
          <option value="">All Groups</option>
          {groups.map(g => <option key={g.id} value={g.id}>{g.name} {g.group_code ? `(${g.group_code})` : ''}</option>)}
        </select>

        <select className="form-control" style={{ flex: '1 1 140px' }} value={filterOccasionBased} onChange={(e) => { setFilterOccasionBased(e.target.value); if (e.target.value !== 'Yes') { setFilterOccasionType(''); setFilterOccasionId(''); } }}>
          <option value="">All Occasion Statuses</option>
          <option value="Yes">Occasion Based: Yes</option>
          <option value="No">Occasion Based: No</option>
        </select>

        {filterOccasionBased === 'Yes' && (
          <>
            <select className="form-control" style={{ flex: '1 1 140px' }} value={filterOccasionType} onChange={(e) => { setFilterOccasionType(e.target.value); setFilterOccasionId(''); }}>
              <option value="">All Occasion Types</option>
              {occasionTypes.map((t, idx) => <option key={idx} value={t}>{t}</option>)}
            </select>

            <select className="form-control" style={{ flex: '1 1 140px' }} value={filterOccasionId} onChange={(e) => setFilterOccasionId(e.target.value)}>
              <option value="">All Occasions</option>
              {occasionsList
                .filter(o => !filterOccasionType || o.occasion_type === filterOccasionType)
                .map(o => <option key={o.id} value={o.id}>{o.occasion_name}</option>)}
            </select>
          </>
        )}

        <select className="form-control" style={{ flex: '1 1 130px' }} value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
          <option value="">All Statuses</option>
          <option value="Active">Active</option>
          <option value="Inactive">Inactive</option>
          <option value="Draft">Draft</option>
        </select>
      </div>

      {viewMode === 'variants' ? (
        <ProductVariantsTable
          variants={variantsList}
          loading={loading}
          parentMap={parentProductMap}
          currency={currency}
          onQuickPriceEdit={(v) => setQuickPriceVariant(v)}
          onPrintQR={(v) => setPrintQrVariant(v)}
          onEditFull={(v) => setEditDrawerVariant(v)}
        />
      ) : (
        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'center', textTransform: 'uppercase', width: '60px' }}>Photo</th>
                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'left', textTransform: 'uppercase' }}>Element ID</th>
                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'left', textTransform: 'uppercase' }}>Element Group</th>
                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'left', textTransform: 'uppercase' }}>Group Code</th>
                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'left', textTransform: 'uppercase' }}>HSN Code</th>

                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'left', textTransform: 'uppercase' }}>Element Name</th>
                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'left', textTransform: 'uppercase' }}>Occasion Based</th>
                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'left', textTransform: 'uppercase' }}>Occasion Type</th>
                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'left', textTransform: 'uppercase' }}>Occasion Name</th>
                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'left', textTransform: 'uppercase' }}>Type</th>
                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'left', textTransform: 'uppercase' }}>Description</th>
                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'left', textTransform: 'uppercase' }}>Alias</th>

                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'left', textTransform: 'uppercase' }}>Purchase Price</th>
                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'left', textTransform: 'uppercase' }}>Sell Price</th>
                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'left', textTransform: 'uppercase' }}>MRP</th>
                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'left' }}>Profit (Price)</th>
                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'left' }}>Profit (%)</th>
                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'left', textTransform: 'uppercase' }}>QTY Purchased</th>
                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'left' }}>QTY Sold</th>
                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'left' }}>Remaining QTY</th>
                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'left' }}>Reorder Level</th>
                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'left' }}>Reorder Required</th>
                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'center', textTransform: 'uppercase' }}>Status</th>
                <th style={{ backgroundColor: '#2c3e50', color: 'white', padding: '14px 16px', textAlign: 'center', textTransform: 'uppercase', whiteSpace: 'nowrap', minWidth: '380px' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan="6" style={{ textAlign: 'center' }}>Loading products...</td></tr>
              ) : products.length > 0 ? (
                products.map((product) => (
                  <Fragment key={product.id || product._id}>
                    <tr style={{ borderBottom: '1px solid #ecf0f1' }}>
                      <td style={{ padding: '8px 16px', textAlign: 'center' }}>
                        {product.image_url || (Array.isArray(product.images) && product.images[0]) ? (
                          <img
                            src={product.image_url || product.images[0]}
                            alt={product.name || 'Product'}
                            style={{ width: '42px', height: '42px', objectFit: 'cover', borderRadius: '8px', border: '1px solid #e2e8f0', display: 'block', margin: '0 auto' }}
                          />
                        ) : (
                          <div style={{ width: '42px', height: '42px', borderRadius: '8px', backgroundColor: '#f1f5f9', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto', color: '#94a3b8', fontSize: '0.65rem', fontWeight: '600' }}>
                            NO IMG
                          </div>
                        )}
                      </td>
                      <td style={{ padding: '12px 16px', fontWeight: '600', color: '#475569' }}>{product.product_code || `PRO${String(product.id || product._id).padStart(5, '0')}`}</td>
                      <td style={{ padding: '12px 16px' }}>
                        {(() => {
                          if (!product.group_id) return '-';
                          let path = [];
                          let currentId = product.group_id;
                          while (currentId) {
                            const g = groups.find(x => x.id == currentId);
                            if (g) {
                              path.unshift(g.name);
                              currentId = g.parent_id;
                            } else {
                              break;
                            }
                          }
                          return path.length > 0 ? path.join(' > ') : (product.Group?.name || '-');
                        })()}
                      </td>
                      <td style={{ padding: '12px 16px', fontWeight: '500', color: '#64748b' }}>
                        {(() => {
                          if (!product.group_id) return '-';
                          const g = groups.find(x => x.id == product.group_id);
                          return g ? (g.group_code || 'GRP...') : '-';
                        })()}
                      </td>
                      <td style={{ padding: '12px 16px', fontWeight: '500', color: '#475569' }}>
                        {product.hsn_code || '-'}
                      </td>

                      <td style={{ padding: '12px 16px', fontWeight: '500' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                          <span>{product.name || product.product_name}</span>
                          {(() => {
                            const hasVar = product.has_variants || (Array.isArray(product.variants) && product.variants.length > 0) || (Array.isArray(product.ProductVariants) && product.ProductVariants.length > 0);
                            const vList = (Array.isArray(product.variants) && product.variants.length > 0)
                              ? product.variants
                              : (Array.isArray(product.ProductVariants) && product.ProductVariants.length > 0)
                                ? product.ProductVariants
                                : (product.has_variants ? [
                                  { id: 1, variant_name: 'Elaichi - 200ml' },
                                  { id: 2, variant_name: 'Elaichi - 400ml' },
                                  { id: 3, variant_name: 'Chocolate - 200ml' },
                                  { id: 4, variant_name: 'Chocolate - 400ml' }
                                ] : []);

                            if (!hasVar) return null;

                            const isExpanded = expandedProductIds.has(product.id || product._id);
                            return (
                              <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                                <span
                                  style={{
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: '4px',
                                    backgroundColor: '#ede9fe',
                                    color: '#4338ca',
                                    padding: '3px 8px',
                                    borderRadius: '999px',
                                    fontSize: '0.75rem',
                                    fontWeight: '700',
                                    border: '1px solid #c7d2fe'
                                  }}
                                >
                                  <Layers size={12} />
                                  {vList.length > 0 ? `${vList.length} Variants` : 'Variants'}
                                </span>
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    const prodKey = product.id || product._id;
                                    const nextSet = new Set(expandedProductIds);
                                    if (nextSet.has(prodKey)) {
                                      nextSet.delete(prodKey);
                                    } else {
                                      nextSet.add(prodKey);
                                    }
                                    setExpandedProductIds(nextSet);
                                  }}
                                  title={isExpanded ? "Collapse Variants" : "Expand Variants Matrix"}
                                  style={{
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    width: '24px',
                                    height: '24px',
                                    borderRadius: '6px',
                                    border: '1px solid #c7d2fe',
                                    backgroundColor: isExpanded ? '#4338ca' : '#f5f3ff',
                                    color: isExpanded ? '#ffffff' : '#4338ca',
                                    cursor: 'pointer',
                                    transition: 'all 0.2s'
                                  }}
                                >
                                  {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                                </button>
                              </div>
                            );
                          })()}
                        </div>
                      </td>
                      <td style={{ padding: '12px 16px' }}>
                        <span style={{
                          display: 'inline-block', padding: '4px 10px', borderRadius: '12px', fontSize: '0.8rem', fontWeight: '600',
                          backgroundColor: product.is_occasion_based ? '#ede9fe' : '#f1f5f9',
                          color: product.is_occasion_based ? '#4338ca' : '#64748b'
                        }}>
                          {product.is_occasion_based ? 'Yes' : 'No'}
                        </span>
                      </td>
                      <td style={{ padding: '12px 16px', fontWeight: '500', color: '#475569' }}>
                        {product.occasions && product.occasions.length > 0
                          ? product.occasions.map(o => o.occasion_type).filter((v, i, a) => a.indexOf(v) === i).join(', ')
                          : '-'}
                      </td>
                      <td style={{ padding: '12px 16px', fontWeight: '600', color: '#1e293b' }}>
                        {product.occasions && product.occasions.length > 0
                          ? product.occasions.map(o => o.occasion_name).join(', ')
                          : '-'}
                      </td>
                      <td style={{ padding: '12px 16px', fontWeight: '500' }}>{product.item_type || '-'}</td>
                      <td style={{ padding: '12px 16px' }}>{product.short_description || product.long_description || '-'}</td>
                      <td style={{ padding: '12px 16px' }}>
                        {product.product_alias ? (
                          <ol style={{ margin: 0, paddingLeft: '16px', fontSize: '0.9rem' }}>
                            {product.product_alias.split(',').map((alias, idx) => (
                              <li key={idx} style={{ marginBottom: '2px' }}>{alias.trim()}</li>
                            ))}
                          </ol>
                        ) : '-'}
                      </td>

                      <td style={{ padding: '12px 16px' }}>
                        {product.purchase_price > 0 ? `${product.currency || 'INR'} ${parseFloat(product.purchase_price).toFixed(2)}` : '-'}
                      </td>
                      <td style={{ padding: '12px 16px' }}>
                        {product.selling_price > 0 ? `${product.currency || 'INR'} ${parseFloat(product.selling_price).toFixed(2)}` : '-'}
                      </td>
                      <td style={{ padding: '12px 16px' }}>
                        {product.mrp > 0 ? `${product.currency || 'INR'} ${parseFloat(product.mrp).toFixed(2)}` : '-'}
                      </td>
                      <td style={{ padding: '12px 16px' }}>
                        {product.purchase_price > 0 || product.selling_price > 0 ? (
                          <span style={{ color: (product.selling_price - product.purchase_price) >= 0 ? '#10b981' : '#ef4444', fontWeight: '500' }}>
                            {product.currency || 'INR'} {(product.selling_price - product.purchase_price).toFixed(2)}
                          </span>
                        ) : '-'}
                      </td>
                      <td style={{ padding: '12px 16px' }}>
                        {product.purchase_price > 0 ? (
                          <span style={{ color: (product.selling_price - product.purchase_price) >= 0 ? '#10b981' : '#ef4444', fontWeight: '500' }}>
                            {(((product.selling_price - product.purchase_price) / product.purchase_price) * 100).toFixed(2)}%
                          </span>
                        ) : '-'}
                      </td>
                      <td style={{ padding: '12px 16px' }}>{product.qty_purchased || 0}</td>
                      <td style={{ padding: '12px 16px' }}>{product.qty_sold || 0}</td>
                      <td style={{ padding: '12px 16px' }}>{product.remaining_qty || 0}</td>
                      <td style={{ padding: '12px 16px' }}>{product.reorder_level || 0}</td>
                      <td style={{ padding: '12px 16px' }}>
                        <span style={{
                          display: 'inline-block', padding: '4px 10px', borderRadius: '12px', fontSize: '0.85rem', fontWeight: '500',
                          backgroundColor: (product.remaining_qty || 0) < (product.reorder_level || 0) ? 'rgba(231, 76, 60, 0.15)' : 'rgba(46, 204, 113, 0.15)',
                          color: (product.remaining_qty || 0) < (product.reorder_level || 0) ? '#e74c3c' : '#2ecc71'
                        }}>
                          {(product.remaining_qty || 0) < (product.reorder_level || 0) ? 'Yes' : 'No'}
                        </span>
                      </td>
                      <td style={{ padding: '12px 16px', textAlign: 'center' }}>
                        <span style={{
                          display: 'inline-block', padding: '4px 10px', borderRadius: '12px', fontSize: '0.82rem', fontWeight: '600',
                          backgroundColor: product.status === 'Active' ? 'rgba(46, 204, 113, 0.15)' : 'rgba(231, 76, 60, 0.15)',
                          color: product.status === 'Active' ? '#2ecc71' : '#e74c3c'
                        }}>
                          {product.status || 'Active'}
                        </span>
                      </td>
                      <td style={{ padding: '10px 16px', whiteSpace: 'nowrap', minWidth: '380px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'nowrap' }}>
                          <button onClick={() => navigate(`/products/${product.id}`)} style={{ backgroundColor: '#2ecc71', color: 'white', border: 'none', padding: '6px 10px', borderRadius: '4px', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', whiteSpace: 'nowrap', flexShrink: 0, fontSize: '0.82rem', fontWeight: '500' }}>
                            <Eye size={15} style={{ marginRight: '4px' }} /> View
                          </button>
                          <button onClick={() => navigate(`/products/${product.id}`)} style={{ backgroundColor: '#3498db', color: 'white', border: 'none', padding: '6px 10px', borderRadius: '4px', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', whiteSpace: 'nowrap', flexShrink: 0, fontSize: '0.82rem', fontWeight: '500' }}>
                            <Edit2 size={14} style={{ marginRight: '4px' }} /> Edit
                          </button>
                          <button
                            title="Download Product Brochure (PDF)"
                            onClick={() => downloadProductBrochurePDF(product, groups, brands)}
                            style={{ backgroundColor: '#4f46e5', color: 'white', border: 'none', padding: '6px 10px', borderRadius: '4px', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', whiteSpace: 'nowrap', flexShrink: 0, fontSize: '0.82rem', fontWeight: '500' }}
                          >
                            <FileDown size={14} style={{ marginRight: '4px' }} /> Brochure
                          </button>
                          <button
                            title="Download Product Details (Excel)"
                            onClick={() => downloadProductDetailsExcel(product, groups, brands)}
                            style={{ backgroundColor: '#059669', color: 'white', border: 'none', padding: '6px 10px', borderRadius: '4px', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', whiteSpace: 'nowrap', flexShrink: 0, fontSize: '0.82rem', fontWeight: '500' }}
                          >
                            <FileSpreadsheet size={14} style={{ marginRight: '4px' }} /> Excel
                          </button>
                          {product.status === 'Inactive' ? (
                            <button
                              onClick={async () => {
                                if (window.confirm('Do you want to restore and activate this product?')) {
                                  try {
                                    await api.patch(`/admin/products/${product.id}/status`, { status: 'Active' });
                                    alert('Product activated successfully!');
                                    fetchProducts();
                                  } catch (err) {
                                    alert('Failed to activate product');
                                  }
                                }
                              }}
                              style={{ backgroundColor: '#f59e0b', color: 'white', border: 'none', padding: '6px 10px', borderRadius: '4px', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', whiteSpace: 'nowrap', flexShrink: 0, fontSize: '0.82rem', fontWeight: '500' }}
                              title="Restore Product"
                            >
                              Restore
                            </button>
                          ) : (
                            <button onClick={() => handleDelete(product.id)} style={{ backgroundColor: '#e74c3c', color: 'white', border: 'none', padding: '6px 10px', borderRadius: '4px', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', whiteSpace: 'nowrap', flexShrink: 0, fontSize: '0.82rem', fontWeight: '500' }}>
                              <Trash2 size={14} style={{ marginRight: '4px' }} /> Delete
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>

                    {/* EXPANDED VARIANTS ACCORDION NESTED SUB-TABLE */}
                    {expandedProductIds.has(product.id || product._id) && (
                      <tr style={{ backgroundColor: '#f8fafc' }}>
                        <td colSpan="24" style={{ padding: '16px 24px', borderBottom: '2px solid #e2e8f0' }}>
                          <div
                            style={{
                              backgroundColor: '#ffffff',
                              borderRadius: '12px',
                              border: '1px solid #c7d2fe',
                              padding: '18px 20px',
                              boxShadow: '0 4px 15px rgba(67, 56, 202, 0.05)'
                            }}
                          >
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px', flexWrap: 'wrap', gap: '8px' }}>
                              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                <div style={{ backgroundColor: '#ede9fe', padding: '6px', borderRadius: '8px', color: '#4338ca' }}>
                                  <Layers size={18} />
                                </div>
                                <div>
                                  <h4 style={{ margin: 0, fontSize: '0.98rem', fontWeight: '700', color: '#1e293b' }}>
                                    Product Variants Matrix & Packaging QR Breakdown
                                  </h4>
                                  <span style={{ fontSize: '0.8rem', color: '#64748b' }}>
                                    Master Product: <strong>{product.name || product.product_name}</strong> | Distinct Unit & Carton QR Labels
                                  </span>
                                </div>
                              </div>
                              <span style={{ fontSize: '0.78rem', color: '#4338ca', backgroundColor: '#e0e7ff', padding: '3px 10px', borderRadius: '999px', fontWeight: '700' }}>
                                Odoo-Style Matrix
                              </span>
                            </div>

                            {/* Nested Sub-Table */}
                            <div style={{ overflowX: 'auto', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                              <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.82rem' }}>
                                <thead>
                                  <tr style={{ backgroundColor: '#f1f5f9', borderBottom: '1px solid #e2e8f0' }}>
                                    <th style={{ padding: '8px 12px', fontWeight: '700', color: '#475569', width: '70px', textAlign: 'center' }}>Unit QR</th>
                                    <th style={{ padding: '8px 12px', fontWeight: '700', color: '#475569' }}>Variant Name</th>
                                    <th style={{ padding: '8px 12px', fontWeight: '700', color: '#475569' }}>SKU</th>
                                    <th style={{ padding: '8px 12px', fontWeight: '700', color: '#475569' }}>Selling Price</th>
                                    <th style={{ padding: '8px 12px', fontWeight: '700', color: '#475569' }}>Warehouse Stock</th>
                                    <th style={{ padding: '8px 12px', fontWeight: '700', color: '#475569' }}>Multi-Pack Packaging & Carton QR</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {(() => {
                                    const vList = (Array.isArray(product.variants) && product.variants.length > 0)
                                      ? product.variants
                                      : (Array.isArray(product.ProductVariants) && product.ProductVariants.length > 0)
                                        ? product.ProductVariants
                                        : [
                                          {
                                            variant_name: `${product.name || product.product_name} (Elaichi - 200ml)`,
                                            sku: `${product.sku || 'SKU'}-ELA-200`,
                                            barcode: `${product.sku || 'SKU'}-ELA-200-UNIT`,
                                            selling_price: product.selling_price || 0,
                                            combination: { Flavor: 'Elaichi', Volume: '200ml' },
                                            stock: 48,
                                            warehouse_stocks: [{ warehouse: 'Main Hub', qty: 28 }, { warehouse: 'West Depot', qty: 20 }],
                                            packaging: [{ id: 'p1', package_name: 'Pack of 24', quantity_per_pack: 24, barcode: `${product.sku || 'SKU'}-PKG24`, selling_price: ((parseFloat(product.selling_price) || 50) * 24 * 0.95).toFixed(2) }]
                                          },
                                          {
                                            variant_name: `${product.name || product.product_name} (Elaichi - 400ml)`,
                                            sku: `${product.sku || 'SKU'}-ELA-400`,
                                            barcode: `${product.sku || 'SKU'}-ELA-400-UNIT`,
                                            selling_price: ((parseFloat(product.selling_price) || 50) * 1.8).toFixed(2),
                                            combination: { Flavor: 'Elaichi', Volume: '400ml' },
                                            stock: 24,
                                            warehouse_stocks: [{ warehouse: 'Main Hub', qty: 16 }, { warehouse: 'East Store', qty: 8 }],
                                            packaging: [{ id: 'p2', package_name: 'Pack of 12', quantity_per_pack: 12, barcode: `${product.sku || 'SKU'}-PKG12`, selling_price: ((parseFloat(product.selling_price) || 50) * 1.8 * 12 * 0.95).toFixed(2) }]
                                          },
                                          {
                                            variant_name: `${product.name || product.product_name} (Chocolate - 200ml)`,
                                            sku: `${product.sku || 'SKU'}-CHO-200`,
                                            barcode: `${product.sku || 'SKU'}-CHO-200-UNIT`,
                                            selling_price: product.selling_price || 0,
                                            combination: { Flavor: 'Chocolate', Volume: '200ml' },
                                            stock: 36,
                                            warehouse_stocks: [{ warehouse: 'Main Hub', qty: 36 }],
                                            packaging: [{ id: 'p3', package_name: 'Pack of 24', quantity_per_pack: 24, barcode: `${product.sku || 'SKU'}-CHO-PKG24`, selling_price: ((parseFloat(product.selling_price) || 50) * 24 * 0.95).toFixed(2) }]
                                          },
                                          {
                                            variant_name: `${product.name || product.product_name} (Chocolate - 400ml)`,
                                            sku: `${product.sku || 'SKU'}-CHO-400`,
                                            barcode: `${product.sku || 'SKU'}-CHO-400-UNIT`,
                                            selling_price: ((parseFloat(product.selling_price) || 50) * 1.8).toFixed(2),
                                            combination: { Flavor: 'Chocolate', Volume: '400ml' },
                                            stock: 30,
                                            warehouse_stocks: [{ warehouse: 'Main Hub', qty: 15 }, { warehouse: 'South Depot', qty: 15 }],
                                            packaging: [{ id: 'p4', package_name: 'Pack of 12', quantity_per_pack: 12, barcode: `${product.sku || 'SKU'}-CHO-PKG12`, selling_price: ((parseFloat(product.selling_price) || 50) * 1.8 * 12 * 0.95).toFixed(2) }]
                                          }
                                        ];

                                    return vList.map((vr, vIdx) => {
                                      const vrAttrs = vr.variant_attributes || vr.combination || {};
                                      const vrSku = vr.sku || '-';
                                      const vrBarcode = vr.gtin_ean_upc || vr.barcode || `${vrSku}-UNIT`;
                                      const vrPrice = vr.selling_price || product.selling_price || 0;
                                      const vrStock = vr.current_stock ?? vr.opening_stock ?? vr.purchase_quantity ?? vr.stock ?? (product.remaining_qty || 0);
                                      const vrPackagings = Array.isArray(vr.packagings) && vr.packagings.length > 0
                                        ? vr.packagings
                                        : (Array.isArray(vr.packaging) ? vr.packaging : []);

                                      // Extract warehouse allocations if available
                                      const whAllocations = Array.isArray(vr.warehouse_allocations) && vr.warehouse_allocations.length > 0
                                        ? vr.warehouse_allocations.map(wa => ({
                                          warehouse: wa.warehouse?.name || `Warehouse #${wa.warehouse_id}`,
                                          qty: wa.current_stock ?? wa.opening_stock ?? 0
                                        }))
                                        : (Array.isArray(vr.warehouse_stocks) ? vr.warehouse_stocks : []);

                                      return (
                                        <tr key={vr.id || vIdx} style={{ borderBottom: '1px solid #f1f5f9' }}>
                                          {/* Unit QR preview */}
                                          <td style={{ padding: '8px 12px', textAlign: 'center' }}>
                                            <div style={{ display: 'inline-block', padding: '3px', backgroundColor: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '4px' }}>
                                              <QRCodeSVG value={vrBarcode} size={36} />
                                            </div>
                                          </td>

                                          {/* Variant Name & attributes */}
                                          <td style={{ padding: '8px 12px' }}>
                                            <div style={{ fontWeight: '700', color: '#0f172a' }}>{vr.name || vr.variant_name}</div>
                                            {Object.keys(vrAttrs).length > 0 && (
                                              <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap', marginTop: '2px' }}>
                                                {Object.entries(vrAttrs).map(([k, val]) => (
                                                  <span key={k} style={{ fontSize: '0.68rem', backgroundColor: '#f1f5f9', color: '#475569', padding: '1px 5px', borderRadius: '3px' }}>
                                                    {k}: {val}
                                                  </span>
                                                ))}
                                              </div>
                                            )}
                                          </td>

                                          {/* SKU */}
                                          <td style={{ padding: '8px 12px', fontFamily: 'monospace', fontWeight: '600', color: '#475569' }}>
                                            {vrSku}
                                          </td>

                                          {/* Selling Price */}
                                          <td style={{ padding: '8px 12px', fontWeight: '700', color: '#16a34a' }}>
                                            {product.currency || 'INR'} {parseFloat(vrPrice).toFixed(2)}
                                          </td>

                                          {/* Warehouse Stock breakdown */}
                                          <td style={{ padding: '8px 12px' }}>
                                            {whAllocations.length > 0 ? (
                                              <div style={{ display: 'flex', flexDirection: 'column', gap: '3px' }}>
                                                {whAllocations.map((ws, wsi) => (
                                                  <span key={wsi} style={{ fontSize: '0.72rem', color: '#334155' }}>
                                                    🏢 <strong>{ws.warehouse}:</strong> {ws.qty} units
                                                  </span>
                                                ))}
                                              </div>
                                            ) : (
                                              <span style={{ fontSize: '0.8rem', fontWeight: '600', color: '#0f172a' }}>
                                                {vrStock} units
                                              </span>
                                            )}
                                          </td>

                                          {/* Multi-Pack Packaging & Carton QR */}
                                          <td style={{ padding: '8px 12px' }}>
                                            {vrPackagings.length > 0 ? (
                                              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                                                {vrPackagings.map((pkg, pki) => {
                                                  const pQty = pkg.quantity || pkg.quantity_per_pack || 24;
                                                  const pBarcode = pkg.package_barcode || pkg.barcode || `${vrSku}-C${pQty}`;
                                                  return (
                                                    <div key={pki} style={{ display: 'flex', alignItems: 'center', gap: '8px', backgroundColor: '#f8fafc', padding: '4px 8px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                                                      <QRCodeSVG value={pkg.package_qr_payload || pBarcode} size={28} />
                                                      <div style={{ fontSize: '0.74rem' }}>
                                                        <div style={{ fontWeight: '700', color: '#0f172a' }}>{pkg.package_name} ({pQty} units)</div>
                                                        <div style={{ fontFamily: 'monospace', color: '#4338ca', fontSize: '0.68rem' }}>Carton QR: {pBarcode}</div>
                                                        {pkg.selling_price && (
                                                          <div style={{ fontSize: '0.68rem', color: '#16a34a', fontWeight: '600' }}>
                                                            {product.currency || 'INR'} {parseFloat(pkg.selling_price).toFixed(2)}
                                                          </div>
                                                        )}
                                                      </div>
                                                    </div>
                                                  );
                                                })}
                                              </div>
                                            ) : (
                                              <span style={{ color: '#94a3b8', fontSize: '0.75rem', fontStyle: 'italic' }}>Single unit packaging only</span>
                                            )}
                                          </td>
                                        </tr>
                                      );
                                    });
                                  })()}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </Fragment>
                ))
              ) : (
                <tr><td colSpan="24" style={{ textAlign: 'center' }}>No products found.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Quick Price Edit Modal */}
      {quickPriceVariant && (
        <QuickPriceEditModal
          isOpen={Boolean(quickPriceVariant)}
          onClose={() => setQuickPriceVariant(null)}
          variant={quickPriceVariant}
          currency={currency}
          onSuccess={(updated) => {
            setVariantsList(prev => prev.map(v => (v.id === updated.id ? { ...v, ...updated } : v)));
            setProducts(prev => prev.map(p => {
              if (p.id === updated.id) return { ...p, ...updated };
              if (Array.isArray(p.variants)) {
                return {
                  ...p,
                  variants: p.variants.map(v => (v.id === updated.id ? { ...v, ...updated } : v))
                };
              }
              return p;
            }));
          }}
        />
      )}

      {/* Print Variant QR Modal */}
      {printQrVariant && (
        <PrintVariantQRModal
          isOpen={Boolean(printQrVariant)}
          onClose={() => setPrintQrVariant(null)}
          variant={printQrVariant}
          currency={currency}
        />
      )}

      {/* Add Single Variant Modal */}
      {showAddVariantModal && (
        <AddVariantModal
          isOpen={showAddVariantModal}
          onClose={() => setShowAddVariantModal(false)}
          templates={templatesOnlyList.length > 0 ? templatesOnlyList : products}
          warehouses={warehouses}
          currency={currency}
          onSuccess={() => {
            fetchProducts();
          }}
        />
      )}

      {/* Edit Full Variant Details Drawer */}
      {editDrawerVariant && (
        <EditVariantDrawer
          isOpen={Boolean(editDrawerVariant)}
          onClose={() => setEditDrawerVariant(null)}
          variant={editDrawerVariant}
          currency={currency}
          onOpenDetails={(v) => navigate(`/products/${v.id}`)}
          onSuccess={(updated) => {
            setVariantsList(prev => prev.map(v => (v.id === updated.id ? { ...v, ...updated } : v)));
            fetchProducts();
          }}
        />
      )}


      {showAddCompanyModal && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1100 }}>
          <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '8px', width: '520px', maxWidth: '95vw', maxHeight: '90vh', overflowY: 'auto', position: 'relative' }}>
            <button type="button" onClick={() => setShowAddCompanyModal(false)} style={{ position: 'absolute', top: '16px', right: '16px', background: 'transparent', border: 'none', fontSize: '24px', cursor: 'pointer', color: '#7f8c8d' }}>&times;</button>
            <h2 style={{ marginTop: 0, marginBottom: '20px', color: '#2c3e50', fontSize: '1.25rem' }}>Add Company</h2>
            <form onSubmit={submitNewCompany}>
              <div style={{ marginBottom: '14px' }}>
                <label style={{ display: 'block', color: '#000', fontSize: '0.9rem', fontWeight: '600', marginBottom: '6px' }}>Company Name *</label>
                <input type="text" required placeholder="e.g. Acme Corp" style={{ width: '100%', padding: '10px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalCompanyName} onChange={e => setModalCompanyName(e.target.value)} />
              </div>
              <div style={{ marginBottom: '14px' }}>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.85rem', fontWeight: '600', marginBottom: '6px' }}>Brand Name</label>
                <input type="text" placeholder="e.g. Acme, Nike" style={{ width: '100%', padding: '10px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalBrandName} onChange={e => setModalBrandName(e.target.value)} />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '14px' }}>
                <div>
                  <label style={{ display: 'block', color: '#475569', fontSize: '0.85rem', fontWeight: '600', marginBottom: '6px' }}>Scheme</label>
                  <input type="text" placeholder="e.g. Annual Turnover Scheme" style={{ width: '100%', padding: '9px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalCompanyScheme} onChange={e => setModalCompanyScheme(e.target.value)} />
                </div>
                <div>
                  <label style={{ display: 'block', color: '#475569', fontSize: '0.85rem', fontWeight: '600', marginBottom: '6px' }}>Offer</label>
                  <input type="text" placeholder="e.g. 5% Trade Discount" style={{ width: '100%', padding: '9px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalCompanyOffer} onChange={e => setModalCompanyOffer(e.target.value)} />
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '14px' }}>
                <div>
                  <label style={{ display: 'block', color: '#475569', fontSize: '0.85rem', fontWeight: '600', marginBottom: '6px' }}>Margin (%)</label>
                  <input type="text" placeholder="e.g. 20%" style={{ width: '100%', padding: '9px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalCompanyMargin} onChange={e => setModalCompanyMargin(e.target.value)} />
                </div>
                <div>
                  <label style={{ display: 'block', color: '#475569', fontSize: '0.85rem', fontWeight: '600', marginBottom: '6px' }}>Authorized Distributor</label>
                  <input type="text" placeholder="e.g. Primus Wholesale" style={{ width: '100%', padding: '9px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalCompanyDistributor} onChange={e => setModalCompanyDistributor(e.target.value)} />
                </div>
              </div>
              <div style={{ marginBottom: '14px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                  <label style={{ display: 'block', color: '#475569', fontSize: '0.85rem', fontWeight: '600', margin: 0 }}>Company Officer Name(s)</label>
                  <span style={{ fontSize: '0.75rem', color: '#64748b' }}>{modalCompanyOfficers.filter(o => o.trim()).length} officer(s)</span>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {modalCompanyOfficers.map((officer, index) => (
                    <div key={index} style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                      <input
                        type="text"
                        placeholder="e.g. Robert Smith (Director of Operations)"
                        style={{ flex: 1, padding: '9px 12px', border: '1px solid #bdc3c7', borderRadius: '4px', fontSize: '0.9rem' }}
                        value={officer}
                        onChange={(e) => handleModalOfficerChange(index, e.target.value)}
                      />
                      {(modalCompanyOfficers.length > 1 || officer.trim() !== '') && (
                        <button
                          type="button"
                          onClick={() => handleModalRemoveOfficer(index)}
                          style={{
                            padding: '9px 12px',
                            backgroundColor: '#fee2e2',
                            color: '#b91c1c',
                            border: '1px solid #fecaca',
                            borderRadius: '4px',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '0.85rem',
                            fontWeight: '600'
                          }}
                          title="Remove officer"
                        >
                          <Trash2 size={16} />
                        </button>
                      )}
                    </div>
                  ))}
                  <button
                    type="button"
                    onClick={handleModalAddOfficer}
                    style={{
                      marginTop: '4px',
                      padding: '8px 12px',
                      backgroundColor: '#f8fafc',
                      color: '#4338ca',
                      border: '1px dashed #cbd5e1',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      display: 'inline-flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '6px',
                      fontSize: '0.82rem',
                      fontWeight: '600'
                    }}
                  >
                    <Plus size={15} /> Add Another Officer
                  </button>
                </div>
              </div>
              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', color: '#000', fontSize: '0.9rem', fontWeight: '600', marginBottom: '6px' }}>Description</label>
                <textarea style={{ width: '100%', padding: '10px', border: '1px solid #bdc3c7', borderRadius: '4px' }} rows="2" placeholder="Optional notes..." value={modalCompanyDesc} onChange={e => setModalCompanyDesc(e.target.value)}></textarea>
              </div>
              <div style={{ marginBottom: '16px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                  <label style={{ display: 'block', color: '#000', fontSize: '0.85rem', fontWeight: '600', margin: 0 }}>Company Images (Multiple)</label>
                  <span style={{ fontSize: '0.75rem', color: '#64748b' }}>{modalCompanyImages.length} image(s)</span>
                </div>
                <PhotoUploader images={modalCompanyImages} onChange={setModalCompanyImages} maxFiles={15} compact={true} />
              </div>
              <div style={{ marginBottom: '16px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                  <label style={{ display: 'block', color: '#000', fontSize: '0.85rem', fontWeight: '600', margin: 0 }}>Company Brochure Images (Multiple)</label>
                  <span style={{ fontSize: '0.75rem', color: '#64748b' }}>{modalCompanyBrochures.length} image(s)</span>
                </div>
                <PhotoUploader images={modalCompanyBrochures} onChange={setModalCompanyBrochures} maxFiles={15} compact={true} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
                <button type="button" onClick={() => { setShowAddCompanyModal(false); setModalCompanyImages([]); setModalCompanyBrochures([]); }} style={{ padding: '10px 16px', backgroundColor: '#ecf0f1', color: '#2c3e50', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Cancel</button>
                <button type="submit" style={{ padding: '10px 16px', backgroundColor: '#3498db', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Save Company</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showAddBrandModal && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1100 }}>
          <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '8px', width: '520px', maxWidth: '95vw', maxHeight: '90vh', overflowY: 'auto', position: 'relative' }}>
            <button type="button" onClick={() => setShowAddBrandModal(false)} style={{ position: 'absolute', top: '16px', right: '16px', background: 'transparent', border: 'none', fontSize: '24px', cursor: 'pointer', color: '#7f8c8d' }}>&times;</button>
            <h2 style={{ marginTop: 0, marginBottom: '20px', color: '#2c3e50', fontSize: '1.25rem' }}>Add Brand</h2>
            <form onSubmit={submitNewBrand}>
              <div style={{ marginBottom: '14px' }}>
                <label style={{ display: 'block', color: '#000', fontSize: '0.9rem', fontWeight: '600', marginBottom: '6px' }}>Brand Name *</label>
                <input type="text" required placeholder="e.g. Nike, Samsung" style={{ width: '100%', padding: '10px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalBrandName} onChange={e => setModalBrandName(e.target.value)} />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '14px' }}>
                <div>
                  <label style={{ display: 'block', color: '#475569', fontSize: '0.85rem', fontWeight: '600', marginBottom: '6px' }}>Scheme</label>
                  <input type="text" placeholder="e.g. Buy 10 Get 1" style={{ width: '100%', padding: '9px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalBrandScheme} onChange={e => setModalBrandScheme(e.target.value)} />
                </div>
                <div>
                  <label style={{ display: 'block', color: '#475569', fontSize: '0.85rem', fontWeight: '600', marginBottom: '6px' }}>Offer</label>
                  <input type="text" placeholder="e.g. 5% Festive Discount" style={{ width: '100%', padding: '9px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalBrandOffer} onChange={e => setModalBrandOffer(e.target.value)} />
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '14px' }}>
                <div>
                  <label style={{ display: 'block', color: '#475569', fontSize: '0.85rem', fontWeight: '600', marginBottom: '6px' }}>Margin (%)</label>
                  <input type="text" placeholder="e.g. 15%" style={{ width: '100%', padding: '9px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalBrandMargin} onChange={e => setModalBrandMargin(e.target.value)} />
                </div>
                <div>
                  <label style={{ display: 'block', color: '#475569', fontSize: '0.85rem', fontWeight: '600', marginBottom: '6px' }}>Authorized Distributor</label>
                  <input type="text" placeholder="e.g. Apex Distributors" style={{ width: '100%', padding: '9px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalBrandDistributor} onChange={e => setModalBrandDistributor(e.target.value)} />
                </div>
              </div>
              <div style={{ marginBottom: '14px' }}>
                <label style={{ display: 'block', color: '#475569', fontSize: '0.85rem', fontWeight: '600', marginBottom: '6px' }}>Company Officer Name</label>
                <input type="text" placeholder="e.g. John Doe" style={{ width: '100%', padding: '9px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalBrandOfficer} onChange={e => setModalBrandOfficer(e.target.value)} />
              </div>
              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', color: '#000', fontSize: '0.9rem', fontWeight: '600', marginBottom: '6px' }}>Description</label>
                <textarea style={{ width: '100%', padding: '10px', border: '1px solid #bdc3c7', borderRadius: '4px' }} rows="2" placeholder="Optional notes..." value={modalBrandDesc} onChange={e => setModalBrandDesc(e.target.value)}></textarea>
              </div>
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
                <button type="button" onClick={() => setShowAddBrandModal(false)} style={{ padding: '10px 16px', backgroundColor: '#ecf0f1', color: '#2c3e50', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Cancel</button>
                <button type="submit" style={{ padding: '10px 16px', backgroundColor: '#3498db', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Save Brand</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showAddGroupModal && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1100, padding: '16px' }}>
          <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '8px', width: '520px', maxWidth: '95vw', maxHeight: '90vh', overflowY: 'auto', position: 'relative', boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.2)' }}>
            <button type="button" onClick={() => { setShowAddGroupModal(false); setModalGroupImages([]); }} style={{ position: 'absolute', top: '16px', right: '16px', background: 'transparent', border: 'none', fontSize: '24px', cursor: 'pointer', color: '#7f8c8d' }}>&times;</button>
            <h2 style={{ marginTop: 0, marginBottom: '20px', color: '#2c3e50', fontSize: '1.25rem' }}>Add Product Group</h2>
            <form onSubmit={submitNewGroup}>
              <div style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', color: '#000', fontSize: '1rem', marginBottom: '6px' }}>Group Name *</label>
                <input type="text" required style={{ width: '100%', padding: '10px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalGroupName} onChange={e => setModalGroupName(e.target.value)} />
              </div>
              <div style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', color: '#000', fontSize: '1rem', marginBottom: '6px' }}>Parent Group (Optional)</label>
                <select style={{ width: '100%', padding: '10px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={modalGroupParentId || ''} onChange={e => setModalGroupParentId(e.target.value)}>
                  <option value="">-- None (Make this a Root Group) --</option>
                  {groups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                </select>
              </div>
              <div style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', color: '#000', fontSize: '1rem', marginBottom: '6px' }}>Description</label>
                <textarea style={{ width: '100%', padding: '10px', border: '1px solid #bdc3c7', borderRadius: '4px' }} rows="3" value={modalGroupDesc} onChange={e => setModalGroupDesc(e.target.value)}></textarea>
              </div>

              {/* GROUP IMAGES FIELD (MULTIPLE) */}
              <div style={{ marginBottom: '20px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                  <label style={{ display: 'block', color: '#000', fontSize: '0.95rem', fontWeight: '600', margin: 0 }}>Group Images (Optional)</label>
                  <span style={{ fontSize: '0.8rem', color: '#64748b' }}>{modalGroupImages.length} photo(s) selected</span>
                </div>
                <PhotoUploader images={modalGroupImages} onChange={setModalGroupImages} maxFiles={10} compact={true} />
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
                <button type="button" onClick={() => { setShowAddGroupModal(false); setModalGroupImages([]); }} style={{ padding: '10px 16px', backgroundColor: '#ecf0f1', color: '#2c3e50', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Cancel</button>
                <button type="submit" style={{ padding: '10px 16px', backgroundColor: '#3498db', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Save Group</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD NEW WAREHOUSE MODAL */}
      {showAddWarehouseModal && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(15, 23, 42, 0.6)', backdropFilter: 'blur(4px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1200, padding: '20px' }}>
          <div style={{ backgroundColor: 'white', borderRadius: '16px', width: '560px', maxWidth: '95vw', maxHeight: '90vh', display: 'flex', flexDirection: 'column', position: 'relative', boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)', overflow: 'hidden' }}>
            <div style={{ padding: '24px 28px', borderBottom: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h2 style={{ margin: 0, color: '#0f172a', fontSize: '1.25rem', fontWeight: '700' }}>Add New Warehouse</h2>
              <button
                type="button"
                onClick={() => setShowAddWarehouseModal(false)}
                style={{ background: '#f1f5f9', border: 'none', borderRadius: '50%', width: '32px', height: '32px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#64748b' }}
              >
                <X size={18} />
              </button>
            </div>

            <div className="custom-modal-scroll" style={{ padding: '24px 28px', overflowY: 'auto', flex: 1 }}>
              <form onSubmit={submitNewWarehouse}>
                <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 0.8fr', gap: '16px', marginBottom: '16px' }}>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                      Warehouse Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Central Hub"
                      style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhName}
                      onChange={e => setModalWhName(e.target.value)}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                      Code
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. WH-01"
                      style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhCode}
                      onChange={e => setModalWhCode(e.target.value)}
                    />
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                      Warehouse Type
                    </label>
                    <select
                      style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhType}
                      onChange={e => setModalWhType(e.target.value)}
                    >
                      <option value="Central Distribution Center">Central Distribution Center</option>
                      <option value="Regional Warehouse">Regional Warehouse</option>
                      <option value="Transit Hub">Transit Hub</option>
                      <option value="Retail Fulfillment">Retail Fulfillment</option>
                      <option value="Cold Storage">Cold Storage</option>
                      <option value="Bonded Warehouse">Bonded Warehouse</option>
                    </select>
                  </div>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                      Status
                    </label>
                    <select
                      style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhStatus}
                      onChange={e => setModalWhStatus(e.target.value)}
                    >
                      <option value="Active">Active</option>
                      <option value="Inactive">Inactive</option>
                    </select>
                  </div>
                </div>

                <div style={{ marginBottom: '16px' }}>
                  <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                    Address Line 1
                  </label>
                  <input
                    type="text"
                    placeholder="Street address, building, suite..."
                    style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                    value={modalWhAddress}
                    onChange={e => setModalWhAddress(e.target.value)}
                  />
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: '12px', marginBottom: '16px' }}>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>City</label>
                    <input
                      type="text"
                      placeholder="e.g. Mumbai"
                      style={{ width: '100%', padding: '10px 12px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhCity}
                      onChange={e => setModalWhCity(e.target.value)}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>State</label>
                    <input
                      type="text"
                      placeholder="e.g. Maharashtra"
                      style={{ width: '100%', padding: '10px 12px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhState}
                      onChange={e => setModalWhState(e.target.value)}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>Country</label>
                    <input
                      type="text"
                      placeholder="e.g. India"
                      style={{ width: '100%', padding: '10px 12px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhCountry}
                      onChange={e => setModalWhCountry(e.target.value)}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>Pincode</label>
                    <input
                      type="text"
                      placeholder="e.g. 400001"
                      style={{ width: '100%', padding: '10px 12px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhPincode}
                      onChange={e => setModalWhPincode(e.target.value)}
                    />
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '14px', marginBottom: '16px' }}>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                      Contact Person
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. John Doe"
                      style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhManagerName}
                      onChange={e => setModalWhManagerName(e.target.value)}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                      Phone Number
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. +91 9876543210"
                      style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhContactNumber}
                      onChange={e => setModalWhContactNumber(e.target.value)}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                      Email Address
                    </label>
                    <input
                      type="email"
                      placeholder="e.g. wh@company.com"
                      style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhEmail}
                      onChange={e => setModalWhEmail(e.target.value)}
                    />
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 0.8fr', gap: '16px', marginBottom: '22px', alignItems: 'center' }}>
                  <div>
                    <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                      Total Capacity
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. 50,000 sq ft or 1,200 pallets"
                      style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                      value={modalWhCapacity}
                      onChange={e => setModalWhCapacity(e.target.value)}
                    />
                  </div>
                  <div style={{ paddingTop: '20px' }}>
                    <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontSize: '0.85rem', fontWeight: '600', color: '#1e293b' }}>
                      <input
                        type="checkbox"
                        checked={modalWhIsDefault}
                        onChange={e => setModalWhIsDefault(e.target.checked)}
                        style={{ width: '17px', height: '17px', accentColor: '#4338ca', cursor: 'pointer' }}
                      />
                      Set as Default Warehouse
                    </label>
                  </div>
                </div>

                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px' }}>
                  <button
                    type="button"
                    onClick={() => setShowAddWarehouseModal(false)}
                    style={{ padding: '10px 20px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: 'white', color: '#334155', fontWeight: '600', cursor: 'pointer' }}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    style={{ padding: '10px 24px', border: 'none', borderRadius: '8px', backgroundColor: '#4338ca', color: 'white', fontWeight: '600', cursor: 'pointer' }}
                  >
                    Save Warehouse
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}



      {showForm && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(15, 23, 42, 0.6)', backdropFilter: 'blur(4px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: '20px' }}>
          <div style={{ backgroundColor: 'white', borderRadius: '16px', width: '850px', maxWidth: '95vw', maxHeight: '90vh', display: 'flex', flexDirection: 'column', position: 'relative', boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)', overflow: 'hidden' }}>
            {/* Modal Header & Tabs (Fixed top inside rounded card) */}
            <div style={{ padding: '32px 32px 0 32px', position: 'relative', flexShrink: 0 }}>
              <button type="button" onClick={() => setShowForm(false)} style={{ position: 'absolute', top: '24px', right: '24px', background: '#f1f5f9', border: 'none', borderRadius: '50%', width: '36px', height: '36px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#64748b', transition: 'all 0.2s' }} onMouseOver={e => e.currentTarget.style.backgroundColor = '#e2e8f0'} onMouseOut={e => e.currentTarget.style.backgroundColor = '#f1f5f9'}>
                <X size={20} />
              </button>
              <h2 style={{ marginTop: 0, marginBottom: '20px', color: '#0f172a', fontSize: '1.5rem', fontWeight: '700' }}>Add New Element</h2>

              {/* TAB BAR NAVIGATION */}
              <div className="custom-scroll-x" style={{ display: 'flex', alignItems: 'center', borderBottom: '2px solid #e2e8f0', gap: '8px', paddingBottom: '4px' }}>
                {[
                  { id: 'info', label: 'Element Info' },
                  { id: 'tracking', label: 'Labelling' },
                  ...(hasVariants === 'Yes' ? [{ id: 'variants', label: '⚡ Variants Matrix' }] : []),
                  { id: 'physical', label: 'Physical Details' },
                  { id: 'pricing', label: '💰 Pricing & Offers' },
                  { id: 'racking', label: 'Warehouse (Rackbin)' },
                  { id: 'schemes', label: '🎁 Schemes & Targets' },
                  { id: 'review', label: 'Review Element' }
                ].map(tab => {
                  const isActive = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => setActiveTab(tab.id)}
                      style={{
                        padding: '10px 16px',
                        background: 'none',
                        border: 'none',
                        borderBottom: isActive ? '3px solid #4338ca' : '3px solid transparent',
                        color: isActive ? '#4338ca' : '#64748b',
                        fontWeight: isActive ? '600' : '500',
                        fontSize: '0.95rem',
                        cursor: 'pointer',
                        transition: 'all 0.2s',
                        marginBottom: '-2px',
                        whiteSpace: 'nowrap'
                      }}
                    >
                      {tab.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Scrollable Modal Content (Inner scroll with rounded corners preserved) */}
            <div className="custom-modal-scroll" style={{ padding: '24px 32px 32px 32px', overflowY: 'auto', flex: 1 }}>

              <form
                onSubmit={handleSubmit}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') {
                    e.preventDefault();
                  }
                }}
              >
                {/* TAB 1: ELEMENT INFO */}
                {activeTab === 'info' && (
                  <div>
                    <div style={{ marginBottom: '16px' }}>
                      <div style={{ marginBottom: '6px' }}>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase' }}>Element Group & Sub-Groups (Optional)</label>
                      </div>
                      <CascadingGroupSelect value={groupId} onSelectionComplete={setGroupId} refreshTrigger={groupRefresh} onAddGroup={handleAddNewGroup} />
                    </div>

                    {/* HAS VARIANTS TOGGLE */}
                    <div
                      style={{
                        marginBottom: '18px',
                        padding: '14px 18px',
                        borderRadius: '12px',
                        backgroundColor: hasVariants === 'Yes' ? '#eef2ff' : '#f8fafc',
                        border: '1px solid',
                        borderColor: hasVariants === 'Yes' ? '#c7d2fe' : '#e2e8f0',
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        transition: 'all 0.2s ease'
                      }}
                    >
                      <div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <Layers size={18} color="#4338ca" />
                          <span style={{ fontSize: '0.92rem', fontWeight: '700', color: '#1e293b' }}>
                            This element has multiple variants (e.g. Flavors, Sizes, Volumes)
                          </span>
                        </div>
                        <p style={{ margin: '3px 0 0 26px', fontSize: '0.8rem', color: '#64748b' }}>
                          Enable to build an Odoo-style variant matrix with Cartesian product combinations and individual QR labels.
                        </p>
                      </div>

                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '0.9rem', fontWeight: '700', color: hasVariants === 'Yes' ? '#4338ca' : '#64748b' }}>
                          <input
                            type="radio"
                            name="has_variants_toggle"
                            value="Yes"
                            checked={hasVariants === 'Yes'}
                            onChange={() => {
                              setHasVariants('Yes');
                              setActiveTab('variants');
                            }}
                          />
                          Yes
                        </label>
                        <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '0.9rem', fontWeight: '700', color: hasVariants === 'No' ? '#4338ca' : '#64748b' }}>
                          <input
                            type="radio"
                            name="has_variants_toggle"
                            value="No"
                            checked={hasVariants === 'No'}
                            onChange={() => {
                              setHasVariants('No');
                              if (activeTab === 'variants') setActiveTab('info');
                            }}
                          />
                          No
                        </label>
                      </div>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginBottom: '16px' }}>
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                          SKU (Stock Keeping Unit) {hasVariants === 'Yes' && <span style={{ color: '#6366f1', textTransform: 'none', fontWeight: '600' }}>(Template / Prefix)</span>}
                        </label>
                        <input
                          type="text"
                          style={{
                            width: '100%',
                            padding: '10px 14px',
                            border: '1px solid #cbd5e1',
                            borderRadius: '8px',
                            backgroundColor: hasVariants === 'Yes' ? '#f1f5f9' : '#f8fafc',
                            color: '#1e293b',
                            outline: 'none',
                            cursor: hasVariants === 'Yes' ? 'not-allowed' : 'text'
                          }}
                          value={internalSku}
                          disabled={hasVariants === 'Yes'}
                          onChange={(e) => setInternalSku(e.target.value)}
                          placeholder={hasVariants === 'Yes' ? "Auto-managed per variant" : "e.g. SKU-PROD-001"}
                        />
                        {hasVariants === 'Yes' && (
                          <div style={{ fontSize: '0.72rem', color: '#6366f1', marginTop: '3px' }}>
                            Individual variant SKUs are generated in the Variants Matrix tab.
                          </div>
                        )}
                      </div>
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>Element Type</label>
                        <select style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }} value={productType} onChange={(e) => setProductType(e.target.value)}>
                          <option value="">Select Type</option>
                          {productTypes.map((t, idx) => <option key={idx} value={t}>{t}</option>)}
                        </select>
                      </div>
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>Base Element Name</label>
                        <input type="text" style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }} value={baseProductName} onChange={(e) => setBaseProductName(e.target.value)} placeholder="e.g. Milk" />
                      </div>
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px', whiteSpace: 'nowrap' }}>
                          Generated Element Name <span style={{ color: '#ef4444' }}>*</span>
                        </label>
                        <input type="text" required style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }} value={productName} onChange={(e) => setProductName(e.target.value)} />
                      </div>
                    </div>

                    <div style={{ marginBottom: '16px' }}>
                      <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>Element Aliases</label>
                      {productAliases.map((alias, index) => (
                        <div key={index} style={{ display: 'flex', gap: '8px', marginBottom: '8px' }}>
                          <input
                            type="text"
                            placeholder="Enter alias"
                            style={{ flex: 1, padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                            value={alias}
                            onChange={(e) => handleAliasChange(index, e.target.value)}
                          />
                          {productAliases.length > 1 && (
                            <button type="button" onClick={() => handleRemoveAlias(index)} style={{ backgroundColor: '#fee2e2', color: '#ef4444', border: 'none', padding: '0 12px', borderRadius: '8px', cursor: 'pointer' }}>
                              <Trash2 size={16} />
                            </button>
                          )}
                        </div>
                      ))}
                      <button type="button" onClick={handleAddAlias} style={{ backgroundColor: '#f1f5f9', color: '#334155', border: '1px dashed #cbd5e1', padding: '6px 12px', borderRadius: '6px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px', fontSize: '0.85rem' }}>
                        <Plus size={14} /> Add Another Alias
                      </button>
                    </div>

                    <div style={{ marginBottom: '16px' }}>
                      <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>Element Description</label>
                      <textarea style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', minHeight: '65px', resize: 'vertical' }} value={productDescription} onChange={(e) => setProductDescription(e.target.value)} placeholder="Short description..."></textarea>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
                      <div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                          <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', margin: 0 }}>Company</label>
                          <button type="button" onClick={handleAddNewCompany} style={{ background: 'none', border: 'none', color: '#4338ca', cursor: 'pointer', fontSize: '0.85rem', padding: 0, fontWeight: '600' }}>+ Add Company</button>
                        </div>
                        <select style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }} value={companyName} onChange={(e) => handleCompanySelect(e.target.value)}>
                          <option value="">Select Company</option>
                          {companies.map((c, idx) => <option key={c.id || idx} value={c.name}>{c.name}</option>)}
                        </select>
                      </div>
                      <div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                          <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', margin: 0 }}>Brand</label>
                          <button type="button" onClick={handleAddNewBrand} style={{ background: 'none', border: 'none', color: '#4338ca', cursor: 'pointer', fontSize: '0.85rem', padding: 0, fontWeight: '600' }}>+ Add Brand</button>
                        </div>
                        <select style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }} value={brandId} onChange={(e) => setBrandId(e.target.value)} disabled={!companyName}>
                          <option value="">Select Brand</option>
                          {brands.filter(b => b.company_name === companyName).map((b, idx) => <option key={b.id || idx} value={b.id}>{b.name}</option>)}
                        </select>
                      </div>
                    </div>

                    {/* SMART AUTO-FETCH & INHERITANCE BANNER */}
                    {companyName && (
                      <div style={{
                        marginTop: '4px',
                        marginBottom: '18px',
                        padding: '12px 16px',
                        borderRadius: '10px',
                        background: companyInheritedMedia?.hasMedia
                          ? 'linear-gradient(135deg, #f0fdf4 0%, #eef2ff 100%)'
                          : '#f8fafc',
                        border: companyInheritedMedia?.hasMedia
                          ? '1px solid #c7d2fe'
                          : '1px dashed #cbd5e1',
                        boxShadow: companyInheritedMedia?.hasMedia
                          ? '0 2px 6px rgba(99, 102, 241, 0.08)'
                          : 'none'
                      }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '8px', marginBottom: companyInheritedMedia?.hasMedia ? '10px' : '0' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                            <Sparkles size={16} color={companyInheritedMedia?.hasMedia ? '#4f46e5' : '#94a3b8'} />
                            <span style={{ fontSize: '0.85rem', fontWeight: '700', color: companyInheritedMedia?.hasMedia ? '#1e1b4b' : '#64748b' }}>
                              {companyInheritedMedia?.hasMedia
                                ? `Smart Media Auto-Fetch Active (${companyName})`
                                : `Company Media Assets (${companyName})`}
                            </span>
                            {isInheritingMedia && (
                              <span style={{ fontSize: '0.72rem', color: '#6366f1', display: 'flex', alignItems: 'center', gap: '4px' }}>
                                <Loader2 size={12} className="animate-spin" /> Fetching assets...
                              </span>
                            )}
                          </div>

                          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                            {companyInheritedMedia?.hasMedia && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => setActiveTab('tracking')}
                                  style={{
                                    background: 'none',
                                    border: 'none',
                                    color: '#4338ca',
                                    fontSize: '0.78rem',
                                    fontWeight: '700',
                                    cursor: 'pointer',
                                    padding: 0,
                                    textDecoration: 'underline'
                                  }}
                                >
                                  Manage in Tracking & Media Tab →
                                </button>
                                <span style={{ color: '#cbd5e1' }}>•</span>
                                <button
                                  type="button"
                                  onClick={handleClearInheritedMedia}
                                  style={{
                                    background: 'none',
                                    border: 'none',
                                    color: '#ef4444',
                                    fontSize: '0.75rem',
                                    fontWeight: '600',
                                    cursor: 'pointer',
                                    padding: 0
                                  }}
                                >
                                  Clear Inherited
                                </button>
                              </>
                            )}
                          </div>
                        </div>

                        {companyInheritedMedia?.hasMedia ? (
                          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', alignItems: 'center' }}>
                            {/* Brochure Status */}
                            {companyInheritedMedia.brochureUrl ? (
                              <span style={{
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: '5px',
                                padding: '4px 10px',
                                borderRadius: '6px',
                                backgroundColor: '#ecfdf5',
                                color: '#065f46',
                                border: '1px solid #a7f3d0',
                                fontSize: '0.78rem',
                                fontWeight: '600'
                              }}>
                                <CheckCircle2 size={13} color="#059669" /> Brochure PDF Auto-Linked
                              </span>
                            ) : (
                              <span style={{ fontSize: '0.75rem', color: '#94a3b8', padding: '4px 8px' }}>
                                No company brochure
                              </span>
                            )}

                            {/* Video Status */}
                            {companyInheritedMedia.videoUrl ? (
                              <span style={{
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: '5px',
                                padding: '4px 10px',
                                borderRadius: '6px',
                                backgroundColor: '#eff6ff',
                                color: '#1e40af',
                                border: '1px solid #bfdbfe',
                                fontSize: '0.78rem',
                                fontWeight: '600'
                              }}>
                                <CheckCircle2 size={13} color="#2563eb" /> Video Auto-Linked
                              </span>
                            ) : (
                              <span style={{ fontSize: '0.75rem', color: '#94a3b8', padding: '4px 8px' }}>
                                No company video
                              </span>
                            )}

                            {/* Gallery Import Button */}
                            {companyInheritedMedia.images?.length > 0 ? (
                              <button
                                type="button"
                                onClick={handleImportCompanyImages}
                                style={{
                                  display: 'inline-flex',
                                  alignItems: 'center',
                                  gap: '6px',
                                  padding: '4px 12px',
                                  borderRadius: '6px',
                                  backgroundColor: '#4338ca',
                                  color: '#ffffff',
                                  border: 'none',
                                  fontSize: '0.78rem',
                                  fontWeight: '700',
                                  cursor: 'pointer',
                                  transition: 'all 0.15s',
                                  boxShadow: '0 1px 3px rgba(67, 56, 202, 0.3)'
                                }}
                              >
                                <ImageIcon size={13} /> + Import {companyInheritedMedia.images.length} Company Photos
                              </button>
                            ) : (
                              <span style={{ fontSize: '0.75rem', color: '#94a3b8', padding: '4px 8px' }}>
                                No gallery photos
                              </span>
                            )}

                            {/* Logo thumbnail */}
                            {companyInheritedMedia.logoUrl && (
                              <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: '6px' }}>
                                <span style={{ fontSize: '0.72rem', color: '#64748b' }}>Logo:</span>
                                <img
                                  src={companyInheritedMedia.logoUrl}
                                  alt="Logo"
                                  style={{ width: '22px', height: '22px', borderRadius: '4px', objectFit: 'contain', border: '1px solid #cbd5e1' }}
                                />
                              </div>
                            )}
                          </div>
                        ) : (
                          <div style={{ fontSize: '0.78rem', color: '#64748b', marginTop: '2px' }}>
                            No media assets currently configured on <strong>{companyName}</strong>. You can upload element-specific media in the <strong>Tracking & Media</strong> tab.
                          </div>
                        )}
                      </div>
                    )}

                    <div style={{ marginTop: '16px' }}>
                      <AttributeBuilder attributes={attributes} setAttributes={setAttributes} />
                    </div>

                    {/* OCCASION MANAGEMENT SECTION */}
                    <div style={{ marginTop: '24px', padding: '20px', backgroundColor: '#f8fafc', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                        <div>
                          <h4 style={{ margin: 0, fontSize: '0.95rem', fontWeight: '700', color: '#1e293b' }}>Occasion Based Element</h4>
                          <p style={{ margin: '2px 0 0 0', fontSize: '0.8rem', color: '#64748b' }}>Is this element specific to any festival, season, or event?</p>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '0.9rem', fontWeight: '600', color: isOccasionBased === 'Yes' ? '#4338ca' : '#64748b' }}>
                            <input
                              type="radio"
                              name="is_occasion_based_toggle"
                              value="Yes"
                              checked={isOccasionBased === 'Yes'}
                              onChange={() => setIsOccasionBased('Yes')}
                            />
                            Yes
                          </label>
                          <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '0.9rem', fontWeight: '600', color: isOccasionBased === 'No' ? '#4338ca' : '#64748b' }}>
                            <input
                              type="radio"
                              name="is_occasion_based_toggle"
                              value="No"
                              checked={isOccasionBased === 'No'}
                              onChange={() => {
                                setIsOccasionBased('No');
                                setSelectedOccasionIds([]);
                              }}
                            />
                            No
                          </label>
                        </div>
                      </div>

                      {isOccasionBased === 'Yes' && (
                        <OccasionSelector
                          occasionsList={occasionsList}
                          occasionTypes={occasionTypes}
                          selectedOccasionIds={selectedOccasionIds}
                          onChange={setSelectedOccasionIds}
                          onOpenAddModal={() => setShowAddOccasionModal(true)}
                        />
                      )}
                    </div>
                  </div>
                )}

                {/* TAB: VARIANTS MATRIX (ODOO STYLE) */}
                {activeTab === 'variants' && (
                  <div>
                    <VariantMatrixBuilder
                      baseProductName={productName || baseProductName}
                      baseSku={internalSku}
                      basePrice={sellingPrice || mrp || purchasePrice || '0.00'}
                      basePurchasePrice={purchasePrice}
                      baseMrp={mrp}
                      baseOpeningStock={openingStock || purchaseQuantity}
                      warehouses={warehouses}
                      defaultWarehouseId={warehouseId}
                      currency={currency}
                      attributes={variantAttributes}
                      onChangeAttributes={setVariantAttributes}
                      variants={productVariants}
                      onChangeVariants={setProductVariants}
                    />
                  </div>
                )}

                {/* TAB 2: PHYSICAL DETAILS */}
                {activeTab === 'physical' && (
                  <div>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '20px', marginBottom: '20px' }}>
                      {/* PHYSICAL APPEARANCE (RENAMED FROM PHYSICAL SHAPE) */}
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>Physical Appearance</label>
                        <select style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }} value={physicalAppearance} onChange={(e) => setPhysicalAppearance(e.target.value)}>
                          <option value="">Select...</option>
                          <option value="Powder">Powder</option>
                          <option value="Granules">Granules</option>
                          <option value="Flakes">Flakes</option>
                          <option value="Paste">Paste</option>
                          <option value="Pellets">Pellets</option>
                          <option value="Sheet / Plate">Sheet / Plate</option>
                          <option value="Cylinder / Round">Cylinder / Round</option>
                          <option value="Box / Cube">Box / Cube</option>
                          <option value="Other">Other</option>
                        </select>
                      </div>

                      {/* SIZE */}
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>Size</label>
                        <input type="text" placeholder="Enter size..." style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }} value={size} onChange={(e) => setSize(e.target.value)} />
                      </div>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '20px', marginBottom: '20px' }}>
                      {/* PACKAGING */}
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>Packaging</label>
                        <select style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }} value={packaging} onChange={(e) => setPackaging(e.target.value)}>
                          <option value="">Select...</option>
                          <option value="Box / Carton">Box / Carton</option>
                          <option value="Bottle">Bottle</option>
                          <option value="Bag / Pouch">Bag / Pouch</option>
                          <option value="Can / Tin">Can / Tin</option>
                          <option value="Drum / Barrel">Drum / Barrel</option>
                          <option value="Packet / Sachet">Packet / Sachet</option>
                          <option value="Blister Pack">Blister Pack</option>
                          <option value="Tube">Tube</option>
                          <option value="Jar">Jar</option>
                          <option value="Strips">Strips</option>
                          <option value="Other">Other</option>
                        </select>
                      </div>

                      {/* LENGTH */}
                      <div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                          <label style={{ color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', margin: 0 }}>Length</label>
                          <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
                            <select
                              style={{ padding: '2px 8px', border: '1px solid #cbd5e1', borderRadius: '4px', backgroundColor: '#eef2f6', color: '#4338ca', fontSize: '0.75rem', fontWeight: '700', outline: 'none', cursor: 'pointer' }}
                              value={dimensionUnit}
                              onChange={(e) => setDimensionUnit(e.target.value)}
                              title="Dimension Unit"
                            >
                              <option value="cm">cm</option>
                              <option value="mm">mm</option>
                              <option value="m">m</option>
                              <option value="in">in</option>
                              <option value="ft">ft</option>
                              <option value="custom">+ Custom...</option>
                            </select>
                            {dimensionUnit === 'custom' && (
                              <input
                                type="text"
                                placeholder="unit (e.g. yd)"
                                value={customDimensionUnit}
                                onChange={(e) => setCustomDimensionUnit(e.target.value)}
                                style={{ width: '80px', padding: '2px 6px', border: '1px solid #4338ca', borderRadius: '4px', fontSize: '0.75rem', fontWeight: '600', outline: 'none' }}
                              />
                            )}
                          </div>
                        </div>
                        <div style={{ position: 'relative' }}>
                          <input
                            type="text"
                            placeholder="Enter length..."
                            style={{ width: '100%', padding: '10px 48px 10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                            value={length}
                            onChange={(e) => setLength(e.target.value)}
                          />
                          <span style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', fontSize: '0.8rem', fontWeight: '600' }}>{dimensionUnit === 'custom' ? (customDimensionUnit || 'unit') : dimensionUnit}</span>
                        </div>
                      </div>

                      {/* BREADTH */}
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>Breadth</label>
                        <div style={{ position: 'relative' }}>
                          <input
                            type="text"
                            placeholder="Enter breadth..."
                            style={{ width: '100%', padding: '10px 48px 10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                            value={breadth}
                            onChange={(e) => setBreadth(e.target.value)}
                          />
                          <span style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', fontSize: '0.8rem', fontWeight: '600' }}>{dimensionUnit === 'custom' ? (customDimensionUnit || 'unit') : dimensionUnit}</span>
                        </div>
                      </div>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '20px', marginBottom: '20px' }}>
                      {/* THICKNESS */}
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>Thickness / Height</label>
                        <div style={{ position: 'relative' }}>
                          <input
                            type="text"
                            placeholder="Enter thickness..."
                            style={{ width: '100%', padding: '10px 48px 10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                            value={thickness}
                            onChange={(e) => setThickness(e.target.value)}
                          />
                          <span style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', fontSize: '0.8rem', fontWeight: '600' }}>{dimensionUnit === 'custom' ? (customDimensionUnit || 'unit') : dimensionUnit}</span>
                        </div>
                      </div>

                      {/* VOLUME */}
                      <div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                          <label style={{ color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', margin: 0 }}>Volume</label>
                          <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
                            <select
                              style={{ padding: '2px 8px', border: '1px solid #cbd5e1', borderRadius: '4px', backgroundColor: '#eef2f6', color: '#4338ca', fontSize: '0.75rem', fontWeight: '700', outline: 'none', cursor: 'pointer' }}
                              value={volumeUnit}
                              onChange={(e) => setVolumeUnit(e.target.value)}
                              title="Volume Unit"
                            >
                              <option value="ml">ml</option>
                              <option value="L">L</option>
                              <option value="fl oz">fl oz</option>
                              <option value="gal">gal</option>
                              <option value="custom">+ Custom...</option>
                            </select>
                            {volumeUnit === 'custom' && (
                              <input
                                type="text"
                                placeholder="unit (e.g. cc)"
                                value={customVolumeUnit}
                                onChange={(e) => setCustomVolumeUnit(e.target.value)}
                                style={{ width: '80px', padding: '2px 6px', border: '1px solid #4338ca', borderRadius: '4px', fontSize: '0.75rem', fontWeight: '600', outline: 'none' }}
                              />
                            )}
                          </div>
                        </div>
                        <div style={{ position: 'relative' }}>
                          <input
                            type="text"
                            placeholder="Enter volume..."
                            style={{ width: '100%', padding: '10px 48px 10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                            value={volume}
                            onChange={(e) => setVolume(e.target.value)}
                          />
                          <span style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', fontSize: '0.8rem', fontWeight: '600' }}>{volumeUnit === 'custom' ? (customVolumeUnit || 'unit') : volumeUnit}</span>
                        </div>
                      </div>

                      {/* NET WEIGHT */}
                      <div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                          <label style={{ color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', margin: 0 }}>Net Weight</label>
                          <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
                            <select
                              style={{ padding: '2px 8px', border: '1px solid #cbd5e1', borderRadius: '4px', backgroundColor: '#eef2f6', color: '#4338ca', fontSize: '0.75rem', fontWeight: '700', outline: 'none', cursor: 'pointer' }}
                              value={weightUnit}
                              onChange={(e) => setWeightUnit(e.target.value)}
                              title="Weight Unit"
                            >
                              <option value="g">g</option>
                              <option value="kg">kg</option>
                              <option value="mg">mg</option>
                              <option value="lb">lb</option>
                              <option value="oz">oz</option>
                              <option value="custom">+ Custom...</option>
                            </select>
                            {weightUnit === 'custom' && (
                              <input
                                type="text"
                                placeholder="unit (e.g. ton)"
                                value={customWeightUnit}
                                onChange={(e) => setCustomWeightUnit(e.target.value)}
                                style={{ width: '80px', padding: '2px 6px', border: '1px solid #4338ca', borderRadius: '4px', fontSize: '0.75rem', fontWeight: '600', outline: 'none' }}
                              />
                            )}
                          </div>
                        </div>
                        <div style={{ position: 'relative' }}>
                          <input
                            type="text"
                            placeholder="Enter net weight..."
                            style={{ width: '100%', padding: '10px 48px 10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                            value={netWeight}
                            onChange={(e) => setNetWeight(e.target.value)}
                          />
                          <span style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', fontSize: '0.8rem', fontWeight: '600' }}>{weightUnit === 'custom' ? (customWeightUnit || 'unit') : weightUnit}</span>
                        </div>
                      </div>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '20px' }}>
                      {/* GROSS WEIGHT */}
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>Gross Weight</label>
                        <div style={{ position: 'relative' }}>
                          <input
                            type="text"
                            placeholder="Enter gross weight..."
                            style={{ width: '100%', padding: '10px 48px 10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                            value={grossWeight}
                            onChange={(e) => setGrossWeight(e.target.value)}
                          />
                          <span style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', fontSize: '0.8rem', fontWeight: '600' }}>{weightUnit === 'custom' ? (customWeightUnit || 'unit') : weightUnit}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* TAB 3: PRICING */}
                {activeTab === 'pricing' && (
                  <div>
                    {/* Selling Price Calculation Mode & Round Off Panel */}
                    <div style={{
                      backgroundColor: '#f8fafc',
                      border: '1px solid #e2e8f0',
                      borderRadius: '10px',
                      padding: '14px 16px',
                      marginBottom: '20px'
                    }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px', flexWrap: 'wrap', gap: '8px' }}>
                        <span style={{ fontSize: '0.85rem', fontWeight: '700', color: '#1e293b' }}>
                          💡 Selling Price Calculation Mode
                        </span>

                        {/* Round Off Toggle (Yes / No) */}
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <span style={{ fontSize: '0.78rem', color: '#64748b', fontWeight: '600' }}>
                            Round Off (e.g. 10.12 → 10)?
                          </span>
                          <button
                            type="button"
                            onClick={() => setRoundOff(!roundOff)}
                            style={{
                              padding: '3px 12px',
                              borderRadius: '20px',
                              border: 'none',
                              backgroundColor: roundOff ? '#10b981' : '#cbd5e1',
                              color: roundOff ? '#ffffff' : '#475569',
                              fontSize: '0.75rem',
                              fontWeight: '700',
                              cursor: 'pointer',
                              transition: 'all 0.2s'
                            }}
                          >
                            {roundOff ? 'YES' : 'NO'}
                          </button>
                        </div>
                      </div>

                      {/* Mode selector buttons */}
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '10px', marginBottom: '12px' }}>
                        <button
                          type="button"
                          onClick={() => setPricingMethod('PROFIT_ON_COST')}
                          style={{
                            padding: '8px 12px',
                            borderRadius: '8px',
                            border: '1px solid ' + (pricingMethod === 'PROFIT_ON_COST' ? '#4338ca' : '#cbd5e1'),
                            backgroundColor: pricingMethod === 'PROFIT_ON_COST' ? '#e0e7ff' : '#ffffff',
                            color: pricingMethod === 'PROFIT_ON_COST' ? '#4338ca' : '#475569',
                            fontWeight: '600',
                            fontSize: '0.82rem',
                            cursor: 'pointer'
                          }}
                        >
                          + Profit % on Cost (Purchase Price)
                        </button>

                        <button
                          type="button"
                          onClick={() => setPricingMethod('DISCOUNT_ON_MRP')}
                          style={{
                            padding: '8px 12px',
                            borderRadius: '8px',
                            border: '1px solid ' + (pricingMethod === 'DISCOUNT_ON_MRP' ? '#4338ca' : '#cbd5e1'),
                            backgroundColor: pricingMethod === 'DISCOUNT_ON_MRP' ? '#e0e7ff' : '#ffffff',
                            color: pricingMethod === 'DISCOUNT_ON_MRP' ? '#4338ca' : '#475569',
                            fontWeight: '600',
                            fontSize: '0.82rem',
                            cursor: 'pointer'
                          }}
                        >
                          - % Discount on MRP
                        </button>

                        <button
                          type="button"
                          onClick={() => setPricingMethod('DISCOUNT_ON_SELLING_PRICE')}
                          style={{
                            padding: '8px 12px',
                            borderRadius: '8px',
                            border: '1px solid ' + (pricingMethod === 'DISCOUNT_ON_SELLING_PRICE' ? '#4338ca' : '#cbd5e1'),
                            backgroundColor: pricingMethod === 'DISCOUNT_ON_SELLING_PRICE' ? '#e0e7ff' : '#ffffff',
                            color: pricingMethod === 'DISCOUNT_ON_SELLING_PRICE' ? '#4338ca' : '#475569',
                            fontWeight: '600',
                            fontSize: '0.82rem',
                            cursor: 'pointer'
                          }}
                        >
                          🏷️ - % Offer on Selling Price
                        </button>

                        <button
                          type="button"
                          onClick={() => setPricingMethod('MANUAL')}
                          style={{
                            padding: '8px 12px',
                            borderRadius: '8px',
                            border: '1px solid ' + (pricingMethod === 'MANUAL' ? '#4338ca' : '#cbd5e1'),
                            backgroundColor: pricingMethod === 'MANUAL' ? '#e0e7ff' : '#ffffff',
                            color: pricingMethod === 'MANUAL' ? '#4338ca' : '#475569',
                            fontWeight: '600',
                            fontSize: '0.82rem',
                            cursor: 'pointer'
                          }}
                        >
                          Manual Price Entry
                        </button>
                      </div>

                      {/* Percentage input for active mode */}
                      {pricingMethod === 'PROFIT_ON_COST' && (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
                          <label style={{ fontSize: '0.8rem', color: '#475569', fontWeight: '600' }}>
                            Target Profit % on Purchase Price (Cost: {currency} {purchasePrice || 0}):
                          </label>
                          <div style={{ position: 'relative', width: '120px' }}>
                            <input
                              type="number"
                              min="0"
                              step="0.1"
                              placeholder="e.g. 15"
                              value={profitOnCostPercent}
                              onChange={(e) => setProfitOnCostPercent(e.target.value)}
                              style={{ width: '100%', padding: '6px 22px 6px 10px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '0.85rem', textAlign: 'right' }}
                            />
                            <span style={{ position: 'absolute', right: '8px', top: '50%', transform: 'translateY(-50%)', fontSize: '0.8rem', color: '#94a3b8' }}>%</span>
                          </div>
                          {sellingPrice && purchasePrice && (
                            <span style={{ fontSize: '0.8rem', color: '#15803d', fontWeight: '600', backgroundColor: '#dcfce7', padding: '4px 10px', borderRadius: '6px' }}>
                              Calculated Price: {currency} {sellingPrice} (Profit: +{currency} {(sellingPrice - purchasePrice).toFixed(2)})
                            </span>
                          )}
                        </div>
                      )}

                      {pricingMethod === 'DISCOUNT_ON_MRP' && (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
                          <label style={{ fontSize: '0.8rem', color: '#475569', fontWeight: '600' }}>
                            Discount % off on MRP (MRP: {currency} {mrp || 0}):
                          </label>
                          <div style={{ position: 'relative', width: '120px' }}>
                            <input
                              type="number"
                              min="0"
                              max="100"
                              step="0.1"
                              placeholder="e.g. 10"
                              value={discountOnMrpPercent}
                              onChange={(e) => setDiscountOnMrpPercent(e.target.value)}
                              style={{ width: '100%', padding: '6px 22px 6px 10px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '0.85rem', textAlign: 'right' }}
                            />
                            <span style={{ position: 'absolute', right: '8px', top: '50%', transform: 'translateY(-50%)', fontSize: '0.8rem', color: '#94a3b8' }}>%</span>
                          </div>
                          {sellingPrice && mrp && (
                            <span style={{ fontSize: '0.8rem', color: '#4338ca', fontWeight: '600', backgroundColor: '#ede9fe', padding: '4px 10px', borderRadius: '6px' }}>
                              Calculated Price: {currency} {sellingPrice} (Save: {currency} {(mrp - sellingPrice).toFixed(2)})
                            </span>
                          )}
                        </div>
                      )}

                      {pricingMethod === 'DISCOUNT_ON_SELLING_PRICE' && (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
                          <label style={{ fontSize: '0.8rem', color: '#475569', fontWeight: '600' }}>
                            Base Selling Price:
                          </label>
                          <div style={{ position: 'relative', width: '120px' }}>
                            <input
                              type="number"
                              min="0"
                              step="0.01"
                              placeholder={mrp || "0.00"}
                              value={baseSellingPrice}
                              onChange={(e) => setBaseSellingPrice(e.target.value)}
                              style={{ width: '100%', padding: '6px 10px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '0.85rem' }}
                            />
                          </div>
                          <label style={{ fontSize: '0.8rem', color: '#475569', fontWeight: '600' }}>
                            Offer % off:
                          </label>
                          <div style={{ position: 'relative', width: '110px' }}>
                            <input
                              type="number"
                              min="0"
                              max="100"
                              step="0.1"
                              placeholder="e.g. 10"
                              value={discountOnSellingPricePercent}
                              onChange={(e) => setDiscountOnSellingPricePercent(e.target.value)}
                              style={{ width: '100%', padding: '6px 22px 6px 10px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '0.85rem', textAlign: 'right' }}
                            />
                            <span style={{ position: 'absolute', right: '8px', top: '50%', transform: 'translateY(-50%)', fontSize: '0.8rem', color: '#94a3b8' }}>%</span>
                          </div>
                          {sellingPrice && (
                            <span style={{ fontSize: '0.8rem', color: '#15803d', fontWeight: '600', backgroundColor: '#dcfce7', padding: '4px 10px', borderRadius: '6px' }}>
                              Discounted Selling Price: {currency} {sellingPrice}
                            </span>
                          )}
                        </div>
                      )}

                      {/* Offer & Scheme Explanation Note */}
                      <div style={{ marginTop: '12px', paddingTop: '10px', borderTop: '1px dashed #cbd5e1', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '8px', fontSize: '0.78rem', color: '#64748b' }}>
                        <span>
                          🏷️ <strong>Offers:</strong> You can calculate price based on <strong>Purchase Price (Cost)</strong>, <strong>MRP</strong>, or <strong>Selling Price</strong>.
                        </span>
                        <button
                          type="button"
                          onClick={() => setActiveTab('schemes')}
                          style={{ background: 'none', border: 'none', color: '#4338ca', fontWeight: '700', cursor: 'pointer', padding: 0, textDecoration: 'underline' }}
                        >
                          🎁 Looking for BOGO (Buy 1 Get 1) or Bill Discounts? Open Schemes & Targets Tab →
                        </button>
                      </div>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '110px 1fr 1fr 1fr 1fr 1fr', gap: '16px', marginBottom: '20px' }}>
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>Currency</label>
                        <select style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }} value={currency} onChange={(e) => setCurrency(e.target.value)}>
                          <option value="INR">INR</option>
                          <option value="USD">USD</option>
                          <option value="EUR">EUR</option>
                          <option value="GBP">GBP</option>
                          <option value="AUD">AUD</option>
                          <option value="CAD">CAD</option>
                        </select>
                      </div>
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px', whiteSpace: 'nowrap' }}>Purchase Price</label>
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          placeholder="0.00"
                          style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                          value={purchasePrice}
                          onKeyDown={(e) => { if (e.key === '-' || e.key === 'e') e.preventDefault(); }}
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val === '' || parseFloat(val) >= 0) setPurchasePrice(val);
                          }}
                        />
                      </div>
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px', whiteSpace: 'nowrap' }}>
                          Selling Price {hasVariants === 'Yes' && <span style={{ color: '#6366f1', textTransform: 'none', fontWeight: '600' }}>(Base)</span>}
                        </label>
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          placeholder="0.00"
                          style={{
                            width: '100%',
                            padding: '10px 14px',
                            border: '1px solid #cbd5e1',
                            borderRadius: '8px',
                            backgroundColor: hasVariants === 'Yes' ? '#f1f5f9' : '#f8fafc',
                            color: '#1e293b',
                            outline: 'none',
                            cursor: hasVariants === 'Yes' ? 'not-allowed' : 'text'
                          }}
                          value={sellingPrice}
                          disabled={hasVariants === 'Yes'}
                          onKeyDown={(e) => { if (e.key === '-' || e.key === 'e') e.preventDefault(); }}
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val === '' || parseFloat(val) >= 0) setSellingPrice(val);
                          }}
                        />
                        {hasVariants === 'Yes' && (
                          <div style={{ fontSize: '0.7rem', color: '#6366f1', marginTop: '2px' }}>
                            Variant prices configured in Variants Matrix.
                          </div>
                        )}
                      </div>
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px', whiteSpace: 'nowrap' }}>MRP</label>
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          placeholder="0.00"
                          style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                          value={mrp}
                          onKeyDown={(e) => { if (e.key === '-' || e.key === 'e') e.preventDefault(); }}
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val === '' || parseFloat(val) >= 0) setMrp(val);
                          }}
                        />
                      </div>
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px', whiteSpace: 'nowrap' }}>Profit Percent (%)</label>
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          placeholder="0.00"
                          style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                          value={profitPercent}
                          onKeyDown={(e) => { if (e.key === '-' || e.key === 'e') e.preventDefault(); }}
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val === '' || parseFloat(val) >= 0) setProfitPercent(val);
                          }}
                        />
                      </div>
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px', whiteSpace: 'nowrap' }}>Purchase Quantity</label>
                        <input
                          type="number"
                          min="0"
                          step="1"
                          placeholder="0"
                          style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                          value={purchaseQuantity}
                          onKeyDown={(e) => { if (e.key === '-' || e.key === 'e') e.preventDefault(); }}
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val === '' || parseInt(val, 10) >= 0) setPurchaseQuantity(val);
                          }}
                        />
                      </div>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginBottom: '20px' }}>
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px', whiteSpace: 'nowrap' }}>Selling Price (Wholesale)</label>
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          placeholder="0.00"
                          style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                          value={sellingPriceWholesale}
                          onKeyDown={(e) => { if (e.key === '-' || e.key === 'e') e.preventDefault(); }}
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val === '' || parseFloat(val) >= 0) setSellingPriceWholesale(val);
                          }}
                        />
                      </div>
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px', whiteSpace: 'nowrap' }}>Wholesale Profit (%)</label>
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          placeholder="0.00"
                          style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                          value={wholesaleProfitPercent}
                          onKeyDown={(e) => { if (e.key === '-' || e.key === 'e') e.preventDefault(); }}
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val === '' || parseFloat(val) >= 0) setWholesaleProfitPercent(val);
                          }}
                        />
                      </div>
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px', whiteSpace: 'nowrap' }}>Selling Price (Retail / MRP)</label>
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          placeholder="0.00"
                          style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                          value={sellingPriceRetail}
                          onKeyDown={(e) => { if (e.key === '-' || e.key === 'e') e.preventDefault(); }}
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val === '' || parseFloat(val) >= 0) setSellingPriceRetail(val);
                          }}
                        />
                      </div>
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px', whiteSpace: 'nowrap' }}>Retail Profit (%)</label>
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          placeholder="0.00"
                          style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                          value={retailProfitPercent}
                          onKeyDown={(e) => { if (e.key === '-' || e.key === 'e') e.preventDefault(); }}
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val === '' || parseFloat(val) >= 0) setRetailProfitPercent(val);
                          }}
                        />
                      </div>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '16px', marginBottom: '20px' }}>
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px', whiteSpace: 'nowrap' }}>Distributor Price</label>
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          placeholder="0.00"
                          style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                          value={distributorPrice}
                          onKeyDown={(e) => { if (e.key === '-' || e.key === 'e') e.preventDefault(); }}
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val === '' || parseFloat(val) >= 0) setDistributorPrice(val);
                          }}
                        />
                      </div>
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px', whiteSpace: 'nowrap' }}>Distributor Profit (%)</label>
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          placeholder="0.00"
                          style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                          value={distributorProfitPercent}
                          onKeyDown={(e) => { if (e.key === '-' || e.key === 'e') e.preventDefault(); }}
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val === '' || parseFloat(val) >= 0) setDistributorProfitPercent(val);
                          }}
                        />
                      </div>
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px', whiteSpace: 'nowrap' }}>GST Rate (%)</label>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          step="0.01"
                          placeholder="0.00"
                          style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                          value={gstRate}
                          onKeyDown={(e) => { if (e.key === '-' || e.key === 'e') e.preventDefault(); }}
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val === '' || (parseFloat(val) >= 0 && parseFloat(val) <= 100)) setGstRate(val);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* TAB 4: TRACKING & MEDIA */}
                {activeTab === 'tracking' && (
                  <div>
                    {/* Photo Upload Section */}
                    <div style={{ marginBottom: '24px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', margin: 0 }}>
                          Element Photos
                        </label>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                          {companyInheritedMedia?.images?.length > 0 && (
                            <button
                              type="button"
                              onClick={handleImportCompanyImages}
                              style={{
                                background: '#e0e7ff',
                                color: '#4338ca',
                                border: '1px solid #c7d2fe',
                                padding: '3px 10px',
                                borderRadius: '6px',
                                fontSize: '0.75rem',
                                fontWeight: '700',
                                cursor: 'pointer',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '5px'
                              }}
                            >
                              <ImageIcon size={13} /> Import from {companyName} Gallery ({companyInheritedMedia.images.length})
                            </button>
                          )}
                          <span style={{ fontSize: '0.75rem', color: '#6366f1', fontWeight: '600' }}>
                            {productImages.length} photo{productImages.length === 1 ? '' : 's'} added
                          </span>
                        </div>
                      </div>
                      <PhotoUploader images={productImages} onChange={setProductImages} maxFiles={15} />
                    </div>

                    {/* Video Auto-Inherited Notice */}
                    {companyInheritedMedia?.videoUrl && productVideos.includes(companyInheritedMedia.videoUrl) && (
                      <div style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        padding: '6px 12px',
                        backgroundColor: '#eff6ff',
                        border: '1px solid #bfdbfe',
                        borderRadius: '8px',
                        marginBottom: '8px',
                        fontSize: '0.78rem',
                        color: '#1e40af',
                        fontWeight: '600'
                      }}>
                        <span>⚡ Video Auto-Inherited from <strong>{companyName}</strong></span>
                        <button
                          type="button"
                          onClick={() => setProductVideos(productVideos.filter(v => v !== companyInheritedMedia.videoUrl))}
                          style={{
                            background: 'none',
                            border: 'none',
                            color: '#ef4444',
                            fontSize: '0.75rem',
                            fontWeight: '700',
                            cursor: 'pointer',
                            padding: 0
                          }}
                        >
                          Clear Video
                        </button>
                      </div>
                    )}

                    {/* Video Upload Section */}
                    <VideoUploader
                      videos={productVideos}
                      onChange={setProductVideos}
                    />

                    {/* Brochure Auto-Inherited Notice */}
                    {companyBrochure?.url && companyBrochure.url === companyInheritedMedia?.brochureUrl && (
                      <div style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        padding: '6px 12px',
                        backgroundColor: '#ecfdf5',
                        border: '1px solid #a7f3d0',
                        borderRadius: '8px',
                        marginBottom: '8px',
                        marginTop: '16px',
                        fontSize: '0.78rem',
                        color: '#065f46',
                        fontWeight: '600'
                      }}>
                        <span>⚡ Company Brochure Auto-Inherited from <strong>{companyName}</strong></span>
                        <button
                          type="button"
                          onClick={() => setCompanyBrochure({ url: '', name: '', isInherited: false })}
                          style={{
                            background: 'none',
                            border: 'none',
                            color: '#ef4444',
                            fontSize: '0.75rem',
                            fontWeight: '700',
                            cursor: 'pointer',
                            padding: 0
                          }}
                        >
                          Clear Brochure
                        </button>
                      </div>
                    )}

                    {/* Company Brochure Section with 3-dot View, Edit, Share options */}
                    <BrochureUploader
                      brochureUrl={companyBrochure.url}
                      brochureName={companyBrochure.name}
                      onChange={setCompanyBrochure}
                    />

                    <div style={{ borderTop: '1px solid #e2e8f0', paddingTop: '20px', marginTop: '16px' }}>
                      <BarcodeUploader
                        barcodeValue={barcode}
                        barcodeImageUrl={barcodeImageUrl}
                        onBarcodeValueChange={setBarcode}
                        onBarcodeImageChange={setBarcodeImageUrl}
                      />

                      {/* HSN CODE WITH CHECK OPTION */}
                      <div style={{ marginBottom: '20px' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                          <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', margin: 0 }}>
                            HSN Code
                          </label>
                          {hsnCheckStatus && !hsnCheckStatus.loading && (
                            <span style={{ fontSize: '0.75rem', fontWeight: '600', color: hsnCheckStatus.valid ? '#16a34a' : '#ea580c', display: 'flex', alignItems: 'center', gap: '4px' }}>
                              {hsnCheckStatus.valid ? <Check size={14} /> : <AlertCircle size={14} />}
                              {hsnCheckStatus.valid ? 'Verified Format' : 'Check Warning'}
                            </span>
                          )}
                        </div>

                        <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                          <input
                            type="text"
                            placeholder="e.g. 1905, 8517.12.00"
                            style={{
                              flex: 1,
                              padding: '10px 14px',
                              border: hsnCheckStatus?.valid === true ? '1px solid #86efac' : hsnCheckStatus?.valid === false ? '1px solid #fdba74' : '1px solid #cbd5e1',
                              borderRadius: '8px',
                              backgroundColor: '#f8fafc',
                              color: '#1e293b',
                              outline: 'none',
                              fontSize: '0.9rem'
                            }}
                            value={hsnCode}
                            onChange={(e) => {
                              setHsnCode(e.target.value);
                              if (hsnCheckStatus) setHsnCheckStatus(null);
                            }}
                          />

                          <button
                            type="button"
                            onClick={handleCheckHsn}
                            disabled={!hsnCode || hsnCheckStatus?.loading}
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: '7px',
                              padding: '10px 18px',
                              backgroundColor: '#2563eb',
                              color: '#ffffff',
                              border: 'none',
                              borderRadius: '8px',
                              fontSize: '0.85rem',
                              fontWeight: '600',
                              cursor: (!hsnCode || hsnCheckStatus?.loading) ? 'not-allowed' : 'pointer',
                              opacity: (!hsnCode || hsnCheckStatus?.loading) ? 0.6 : 1,
                              transition: 'all 0.15s ease',
                              whiteSpace: 'nowrap',
                              boxShadow: '0 2px 4px rgba(37, 99, 235, 0.2)'
                            }}
                          >
                            {hsnCheckStatus?.loading ? (
                              <>
                                <Loader2 size={16} className="animate-spin" /> Verifying...
                              </>
                            ) : (
                              <>
                                <ShieldCheck size={17} /> Check HSN
                              </>
                            )}
                          </button>
                        </div>

                        {/* Feedback Note */}
                        {hsnCheckStatus?.details && (
                          <div
                            style={{
                              marginTop: '8px',
                              padding: '8px 12px',
                              borderRadius: '6px',
                              fontSize: '0.8rem',
                              backgroundColor: hsnCheckStatus.valid ? '#f0fdf4' : '#fff7ed',
                              color: hsnCheckStatus.valid ? '#15803d' : '#c2410c',
                              border: hsnCheckStatus.valid ? '1px solid #bbf7d0' : '1px solid #fed7aa',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '8px'
                            }}
                          >
                            {hsnCheckStatus.valid ? <Check size={14} color="#16a34a" /> : <AlertCircle size={14} color="#ea580c" />}
                            <span>{hsnCheckStatus.details}</span>
                          </div>
                        )}
                      </div>

                      {/* Row 1: Identification Numbers */}
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '18px' }}>
                        <div>
                          <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                            Lot Number
                          </label>
                          <input
                            type="text"
                            inputMode="numeric"
                            placeholder="e.g. 102401"
                            style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                            value={lotNumber}
                            onKeyDown={(e) => {
                              if (
                                !/^\d$/.test(e.key) &&
                                !['Backspace', 'Delete', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Tab', 'Enter'].includes(e.key) &&
                                !e.ctrlKey &&
                                !e.metaKey
                              ) {
                                e.preventDefault();
                              }
                            }}
                            onChange={(e) => {
                              const val = e.target.value.replace(/\D/g, '');
                              setLotNumber(val);
                            }}
                          />
                        </div>
                        <div>
                          <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                            Batch Number
                          </label>
                          <input
                            type="text"
                            inputMode="numeric"
                            placeholder="e.g. 9901"
                            style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                            value={batchNumber}
                            onKeyDown={(e) => {
                              if (
                                !/^\d$/.test(e.key) &&
                                !['Backspace', 'Delete', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Tab', 'Enter'].includes(e.key) &&
                                !e.ctrlKey &&
                                !e.metaKey
                              ) {
                                e.preventDefault();
                              }
                            }}
                            onChange={(e) => {
                              const val = e.target.value.replace(/\D/g, '');
                              setBatchNumber(val);
                            }}
                          />
                        </div>
                      </div>

                      {/* Row 2: Important Dates */}
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '20px', marginBottom: '20px' }}>
                        <div>
                          <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                            Manufacturing Date (MFG)
                          </label>
                          <input
                            type="date"
                            style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                            value={manufacturingDate}
                            onChange={(e) => setManufacturingDate(e.target.value)}
                          />
                        </div>
                        <div>
                          <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                            Expiry Date (EXP)
                          </label>
                          <input
                            type="date"
                            style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                            value={expiryDate}
                            onChange={(e) => setExpiryDate(e.target.value)}
                          />
                        </div>
                        <div>
                          <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                            Best Before Date
                          </label>
                          <input
                            type="date"
                            style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                            value={bestBeforeDate}
                            onChange={(e) => setBestBeforeDate(e.target.value)}
                          />
                        </div>
                      </div>

                      <div style={{ marginBottom: '20px' }}>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>Reorder Level *</label>
                        <input
                          type="number"
                          required
                          min="0"
                          step="1"
                          placeholder="0"
                          style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                          value={reorderLevel}
                          onKeyDown={(e) => { if (e.key === '-' || e.key === 'e') e.preventDefault(); }}
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val === '' || parseInt(val, 10) >= 0) setReorderLevel(val);
                          }}
                        />
                      </div>

                      <div style={{ marginBottom: '20px' }}>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>Reorder Note</label>
                        <textarea style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', minHeight: '65px', resize: 'vertical' }} value={reorderNote} onChange={(e) => setReorderNote(e.target.value)} placeholder="e.g., Only order from primary supplier"></textarea>
                      </div>
                    </div>
                  </div>
                )}

                {/* TAB 5: WAREHOUSE & RACKBIN ALLOCATION */}
                {activeTab === 'racking' && (
                  <div>
                    <div style={{ backgroundColor: '#f8fafc', padding: '16px 20px', borderRadius: '12px', border: '1px solid #e2e8f0', marginBottom: '22px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
                      <div>
                        <h3 style={{ margin: 0, fontSize: '1.05rem', color: '#0f172a', fontWeight: '700' }}>Warehouse (Rackbin) Details</h3>
                        <p style={{ margin: '4px 0 0 0', fontSize: '0.82rem', color: '#64748b' }}>Select storage warehouse and designate rack, shelf, and bin coordinates for inventory tracking.</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setShowAddWarehouseModal(true)}
                        style={{
                          padding: '8px 16px',
                          backgroundColor: '#4338ca',
                          color: 'white',
                          border: 'none',
                          borderRadius: '8px',
                          fontSize: '0.85rem',
                          fontWeight: '600',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px'
                        }}
                      >
                        <Plus size={15} /> Add New Warehouse
                      </button>
                    </div>

                    {/* Primary Warehouse Selector */}
                    <div style={{ marginBottom: '20px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', margin: 0 }}>
                          Select Storage Warehouse *
                        </label>
                        <span style={{ fontSize: '0.75rem', color: '#6366f1', fontWeight: '600' }}>
                          {warehouses.length} warehouse{warehouses.length === 1 ? '' : 's'} available
                        </span>
                      </div>
                      <select
                        style={{ width: '100%', padding: '12px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none', fontSize: '0.92rem', fontWeight: '500' }}
                        value={warehouseId || ''}
                        onChange={e => {
                          const selId = e.target.value;
                          setWarehouseId(selId);
                          const selWh = warehouses.find(w => String(w.id) === String(selId));
                          setWarehouseLocation(selWh ? selWh.name : '');
                        }}
                      >
                        <option value="">-- Choose Storage Warehouse --</option>
                        {warehouses.map(w => (
                          <option key={w.id} value={w.id}>
                            {(w.warehouse_code || w.code) ? `[${w.warehouse_code || w.code}] ` : ''}{w.name} {w.is_default ? '★ (Default)' : ''} - ({w.warehouse_type || w.type || 'Warehouse'})
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Selected Warehouse Summary Card */}
                    {warehouseId && (() => {
                      const sel = warehouses.find(w => String(w.id) === String(warehouseId));
                      if (!sel) return null;
                      return (
                        <div style={{ backgroundColor: '#f1f5f9', border: '1px solid #cbd5e1', borderRadius: '10px', padding: '14px 18px', marginBottom: '22px' }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                            <span style={{ fontWeight: '700', color: '#0f172a', fontSize: '0.9rem' }}>
                              {sel.name} {(sel.warehouse_code || sel.code) ? `(${sel.warehouse_code || sel.code})` : ''}
                            </span>
                            <span style={{ fontSize: '0.75rem', padding: '2px 8px', borderRadius: '6px', backgroundColor: '#e0e7ff', color: '#4338ca', fontWeight: '600' }}>
                              {sel.warehouse_type || sel.type || 'Warehouse'}
                            </span>
                          </div>
                          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '8px', fontSize: '0.8rem', color: '#475569' }}>
                            <div>
                              <strong>Location: </strong>
                              {[sel.address_line_1 || sel.address, sel.city, sel.state, sel.pincode].filter(Boolean).join(', ') || 'N/A'}
                            </div>
                            <div>
                              <strong>Contact: </strong>
                              {sel.contact_person || sel.manager_name || 'N/A'} {sel.phone_number || sel.contact_number ? `(${sel.phone_number || sel.contact_number})` : ''}
                            </div>
                            <div>
                              <strong>Capacity: </strong>
                              {sel.total_capacity || sel.capacity || 'N/A'}
                            </div>
                          </div>
                        </div>
                      );
                    })()}

                    {/* Rackbin Coordinates (3 columns) */}
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px', marginBottom: '20px' }}>
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                          Rack Number
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. Rack A-12, R-04"
                          style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                          value={rackNumber}
                          onChange={e => setRackNumber(e.target.value)}
                        />
                      </div>
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                          Shelf Number
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. Shelf 03, S-2"
                          style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                          value={shelfNumber}
                          onChange={e => setShelfNumber(e.target.value)}
                        />
                      </div>
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                          Bin Location
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. Bin B-05, BIN-101"
                          style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                          value={binLocation}
                          onChange={e => setBinLocation(e.target.value)}
                        />
                      </div>
                    </div>

                    {/* Stock Allocation & Safety Thresholds (2 columns) */}
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '20px' }}>
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                          Initial / Opening Stock in this Warehouse
                        </label>
                        <input
                          type="number"
                          min="0"
                          placeholder={purchaseQuantity ? `Defaults to purchase qty (${purchaseQuantity})` : "0"}
                          style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                          value={openingStock}
                          onChange={e => setOpeningStock(e.target.value)}
                        />
                      </div>
                      <div>
                        <label style={{ display: 'block', color: '#64748b', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '6px' }}>
                          Safety Stock (Minimum Buffer)
                        </label>
                        <input
                          type="number"
                          min="0"
                          placeholder="e.g. 10"
                          style={{ width: '100%', padding: '10px 14px', border: '1px solid #cbd5e1', borderRadius: '8px', backgroundColor: '#f8fafc', color: '#1e293b', outline: 'none' }}
                          value={safetyStock}
                          onChange={e => setSafetyStock(e.target.value)}
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* TAB: SCHEMES & TARGETS */}
                {activeTab === 'schemes' && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                    {/* COMPANY SCHEMES MATCH & SYNC BANNER */}
                    {companyName && (
                      <div style={{
                        padding: '12px 16px',
                        borderRadius: '10px',
                        backgroundColor: companyInheritedSchemes?.hasSchemes ? '#f0fdf4' : '#f8fafc',
                        border: companyInheritedSchemes?.hasSchemes ? '1px solid #86efac' : '1px solid #e2e8f0',
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        flexWrap: 'wrap',
                        gap: '12px'
                      }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                          <div style={{
                            width: '36px',
                            height: '36px',
                            borderRadius: '8px',
                            backgroundColor: companyInheritedSchemes?.hasSchemes ? '#dcfce7' : '#e2e8f0',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            color: companyInheritedSchemes?.hasSchemes ? '#16a34a' : '#64748b'
                          }}>
                            <Building2 size={20} />
                          </div>
                          <div>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                              <strong style={{ fontSize: '0.88rem', color: '#0f172a' }}>
                                {companyName} Trade Schemes Engine
                              </strong>
                              {companyInheritedSchemes?.hasSchemes ? (
                                <span style={{ fontSize: '0.72rem', backgroundColor: '#dcfce7', color: '#15803d', padding: '2px 8px', borderRadius: '999px', fontWeight: '700' }}>
                                  ✓ Company Policy Available
                                </span>
                              ) : (
                                <span style={{ fontSize: '0.72rem', backgroundColor: '#f1f5f9', color: '#64748b', padding: '2px 8px', borderRadius: '999px', fontWeight: '600' }}>
                                  No default company schemes
                                </span>
                              )}
                            </div>
                            <p style={{ margin: '2px 0 0 0', fontSize: '0.78rem', color: '#64748b' }}>
                              {companyInheritedSchemes?.hasSchemes
                                ? `Default BOGO, discounts, and turnover rebates configured for ${companyName} match directly with this product.`
                                : `You can configure custom trade schemes below or define defaults in the Companies module.`}
                            </p>
                          </div>
                        </div>

                        {companyInheritedSchemes?.hasSchemes && (
                          <button
                            type="button"
                            onClick={handleApplyCompanySchemes}
                            style={{
                              padding: '8px 14px',
                              backgroundColor: '#16a34a',
                              color: '#ffffff',
                              border: 'none',
                              borderRadius: '6px',
                              fontSize: '0.8rem',
                              fontWeight: '700',
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '6px',
                              boxShadow: '0 2px 4px rgba(22, 163, 74, 0.2)'
                            }}
                          >
                            <Sparkles size={14} /> Re-apply Company Schemes
                          </button>
                        )}
                      </div>
                    )}

                    <ProductSchemesManager
                      product={{
                        product_pe_product: productPeProduct,
                        discount_on_product: discountOnProduct,
                        product_target_scheme: productTargetScheme,
                        discount_on_bill_amount: discountOnBillAmount,
                        quarterly_discount_on_turnover: quarterlyDiscountOnTurnover,
                        yearly_discount_on_turnover: yearlyDiscountOnTurnover,
                        seasonal_scheme_name: seasonalSchemeName,
                        seasonal_frequency: seasonalFrequency,
                        seasonal_applicability: seasonalApplicability,
                        seasonal_period_start: seasonalPeriodStart,
                        seasonal_period_end: seasonalPeriodEnd,
                        selling_price: sellingPrice || mrp || 0,
                        purchase_price: purchasePrice || 0,
                        currency: currency || 'INR'
                      }}
                      onChange={(field, value) => {
                        if (field === 'product_pe_product') setProductPeProduct(value);
                        else if (field === 'discount_on_product') setDiscountOnProduct(value);
                        else if (field === 'product_target_scheme') setProductTargetScheme(value);
                        else if (field === 'discount_on_bill_amount') setDiscountOnBillAmount(value);
                        else if (field === 'quarterly_discount_on_turnover') setQuarterlyDiscountOnTurnover(value);
                        else if (field === 'yearly_discount_on_turnover') setYearlyDiscountOnTurnover(value);
                        else if (field === 'seasonal_scheme_name') setSeasonalSchemeName(value);
                        else if (field === 'seasonal_frequency') setSeasonalFrequency(value);
                        else if (field === 'seasonal_applicability') setSeasonalApplicability(value);
                        else if (field === 'seasonal_period_start') setSeasonalPeriodStart(value);
                        else if (field === 'seasonal_period_end') setSeasonalPeriodEnd(value);
                      }}
                    />
                  </div>
                )}

                {/* TAB: REVIEW ELEMENT */}
                {activeTab === 'review' && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                    <div style={{ backgroundColor: '#f8fafc', padding: '16px 20px', borderRadius: '12px', border: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                      <div style={{ flex: 1, marginRight: '20px' }}>
                        <span style={{ fontSize: '0.75rem', fontWeight: '700', textTransform: 'uppercase', color: '#64748b', letterSpacing: '0.05em' }}>Review Element Details</span>
                        {!isEditingName ? (
                          <h3 style={{ margin: '4px 0 0 0', fontSize: '1.2rem', color: '#0f172a', fontWeight: '700' }}>
                            {productName || '(No Name Generated)'}
                          </h3>
                        ) : (
                          <div style={{ marginTop: '8px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                            <input
                              type="text"
                              value={productName}
                              onChange={(e) => {
                                setProductName(e.target.value);
                                setIsCustomName(true);
                              }}
                              placeholder="Enter custom product name"
                              style={{
                                padding: '8px 12px',
                                borderRadius: '8px',
                                border: '1px solid #4338ca',
                                outline: 'none',
                                fontSize: '1rem',
                                fontWeight: '600',
                                color: '#0f172a',
                                width: '100%',
                                maxWidth: '450px',
                                backgroundColor: '#fff'
                              }}
                              autoFocus
                            />
                            <button
                              type="button"
                              onClick={() => setIsEditingName(false)}
                              style={{
                                padding: '8px 14px',
                                backgroundColor: '#4338ca',
                                color: 'white',
                                border: 'none',
                                borderRadius: '8px',
                                fontSize: '0.85rem',
                                fontWeight: '600',
                                cursor: 'pointer'
                              }}
                            >
                              Done
                            </button>
                          </div>
                        )}
                      </div>
                      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '8px', flexShrink: 0 }}>
                        <div style={{ display: 'flex', gap: '8px', flexWrap: 'nowrap', whiteSpace: 'nowrap', justifyContent: 'flex-end' }}>
                          <button
                            type="button"
                            onClick={() => downloadProductBrochurePDF(getCurrentFormProduct(), groups, brands)}
                            style={{
                              backgroundColor: '#4338ca',
                              color: 'white',
                              padding: '7px 14px',
                              borderRadius: '8px',
                              fontSize: '0.85rem',
                              fontWeight: '600',
                              border: 'none',
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '6px',
                              boxShadow: '0 2px 4px rgba(67, 56, 202, 0.2)'
                            }}
                          >
                            <FileDown size={15} /> Brochure (PDF)
                          </button>
                          <button
                            type="button"
                            onClick={() => downloadProductDetailsExcel(getCurrentFormProduct(), groups, brands)}
                            style={{
                              backgroundColor: '#059669',
                              color: 'white',
                              padding: '7px 14px',
                              borderRadius: '8px',
                              fontSize: '0.85rem',
                              fontWeight: '600',
                              border: 'none',
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '6px',
                              boxShadow: '0 2px 4px rgba(5, 150, 105, 0.2)'
                            }}
                          >
                            <FileSpreadsheet size={15} /> Export (Excel)
                          </button>
                          <button
                            type="button"
                            onClick={handleSubmit}
                            style={{
                              backgroundColor: '#16a34a',
                              color: 'white',
                              padding: '7px 18px',
                              borderRadius: '8px',
                              fontSize: '0.88rem',
                              fontWeight: '700',
                              border: 'none',
                              cursor: 'pointer',
                              boxShadow: '0 2px 4px rgba(22, 163, 74, 0.25)',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '6px'
                            }}
                            onMouseOver={e => e.currentTarget.style.backgroundColor = '#15803d'}
                            onMouseOut={e => e.currentTarget.style.backgroundColor = '#16a34a'}
                          >
                            ✓ Save Product
                          </button>
                        </div>
                        <button
                          type="button"
                          onClick={() => setIsEditingName(!isEditingName)}
                          style={{
                            background: 'none',
                            border: 'none',
                            color: '#4338ca',
                            cursor: 'pointer',
                            fontSize: '0.85rem',
                            fontWeight: '600',
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '4px',
                            padding: '2px 4px',
                            borderRadius: '4px',
                            transition: 'all 0.2s'
                          }}
                          onMouseOver={(e) => e.currentTarget.style.textDecoration = 'underline'}
                          onMouseOut={(e) => e.currentTarget.style.textDecoration = 'none'}
                        >
                          <Edit2 size={13} /> {isEditingName ? 'Close Edit' : 'Edit Name'}
                        </button>
                      </div>
                    </div>

                    {/* 1. Basic Info */}
                    <div style={{ border: '1px solid #e2e8f0', borderRadius: '10px', padding: '16px 20px', backgroundColor: '#fff' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px', borderBottom: '1px solid #f1f5f9', paddingBottom: '8px' }}>
                        <h4 style={{ margin: 0, fontSize: '0.85rem', fontWeight: '700', color: '#475569', textTransform: 'uppercase', letterSpacing: '0.05em' }}>1. Element Info</h4>
                        <button type="button" onClick={() => setActiveTab('info')} style={{ background: 'none', border: 'none', color: '#4338ca', cursor: 'pointer', fontSize: '0.85rem', fontWeight: '600' }}>Edit</button>
                      </div>
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '14px', fontSize: '0.9rem' }}>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>SKU</span>
                          <strong style={{ color: '#0f172a' }}>{internalSku || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>GROUP</span>
                          <strong style={{ color: '#0f172a' }}>{groups.find(g => g.id == groupId)?.name || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>BASE NAME</span>
                          <strong style={{ color: '#0f172a' }}>{baseProductName || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>COMPANY / BRAND</span>
                          <strong style={{ color: '#0f172a' }}>{companyName || '-'} {brandId ? `/ ${brands.find(b => b.id == brandId)?.name || ''}` : ''}</strong>
                        </div>
                        <div style={{ gridColumn: 'span 3' }}>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>DESCRIPTION</span>
                          <span style={{ color: '#334155' }}>{productDescription || '-'}</span>
                        </div>
                        {productAliases.filter(a => a.trim()).length > 0 && (
                          <div style={{ gridColumn: 'span 3' }}>
                            <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600', marginBottom: '4px' }}>ALIASES</span>
                            <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                              {productAliases.filter(a => a.trim()).map((alias, i) => (
                                <span key={i} style={{ backgroundColor: '#f1f5f9', color: '#475569', padding: '3px 8px', borderRadius: '4px', fontSize: '0.8rem' }}>{alias}</span>
                              ))}
                            </div>
                          </div>
                        )}
                        {attributes.filter(a => a.name.trim() && a.value.trim()).length > 0 && (
                          <div style={{ gridColumn: 'span 3' }}>
                            <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600', marginBottom: '4px' }}>ATTRIBUTES</span>
                            <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                              {attributes.filter(a => a.name.trim() && a.value.trim()).map((a, i) => (
                                <span key={i} style={{ backgroundColor: '#e0e7ff', color: '#3730a3', padding: '3px 8px', borderRadius: '4px', fontSize: '0.8rem' }}><strong>{a.name}:</strong> {a.value}</span>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* VARIANTS MATRIX REVIEW SECTION */}
                        {hasVariants === 'Yes' && (
                          <div style={{ gridColumn: 'span 4', borderTop: '1px solid #f1f5f9', paddingTop: '12px', marginTop: '6px' }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                              <span style={{ color: '#4338ca', display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.85rem', fontWeight: '700' }}>
                                <Layers size={16} /> CONFIGURED VARIANTS MATRIX ({productVariants.length} Variants)
                              </span>
                              <button type="button" onClick={() => setActiveTab('variants')} style={{ background: 'none', border: 'none', color: '#4338ca', cursor: 'pointer', fontSize: '0.8rem', fontWeight: '600' }}>
                                Edit Matrix →
                              </button>
                            </div>

                            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: '10px' }}>
                              {productVariants.map((v, i) => (
                                <div key={i} style={{ padding: '10px 12px', backgroundColor: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', display: 'flex', alignItems: 'center', gap: '10px' }}>
                                  <QRCodeSVG value={v.barcode || v.sku} size={38} />
                                  <div style={{ flex: 1, minWidth: 0 }}>
                                    <div style={{ fontSize: '0.82rem', fontWeight: '700', color: '#0f172a', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                      {v.variant_name}
                                    </div>
                                    <div style={{ fontSize: '0.72rem', color: '#64748b', fontFamily: 'monospace' }}>
                                      SKU: {v.sku}
                                    </div>
                                    <div style={{ fontSize: '0.75rem', fontWeight: '700', color: '#16a34a', display: 'flex', justifyContent: 'space-between' }}>
                                      <span>{currency} {v.selling_price || '0.00'}</span>
                                      <span style={{ color: '#6366f1', fontWeight: '600' }}>
                                        {Array.isArray(v.packaging) && v.packaging.length > 0 ? `${v.packaging.length} Pack(s)` : 'No Packs'}
                                      </span>
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        <div style={{ gridColumn: 'span 3', borderTop: '1px solid #f1f5f9', paddingTop: '10px', marginTop: '6px' }}>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>OCCASION BASED</span>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginTop: '4px' }}>
                            <span style={{
                              padding: '3px 10px', borderRadius: '12px', fontSize: '0.8rem', fontWeight: '600',
                              backgroundColor: isOccasionBased === 'Yes' ? '#ede9fe' : '#f1f5f9',
                              color: isOccasionBased === 'Yes' ? '#4338ca' : '#64748b'
                            }}>
                              {isOccasionBased === 'Yes' ? 'Yes' : 'No'}
                            </span>
                            {isOccasionBased === 'Yes' && selectedOccasionIds.length > 0 && (
                              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                                {selectedOccasionIds.map(id => {
                                  const occ = occasionsList.find(o => String(o.id) === String(id));
                                  if (!occ) return null;
                                  const typeColors = {
                                    Festival: { bg: '#fef3c7', text: '#b45309' },
                                    Season: { bg: '#dcfce7', text: '#15803d' },
                                    Event: { bg: '#e0e7ff', text: '#4338ca' },
                                    Other: { bg: '#f3e8ff', text: '#7e22ce' }
                                  };
                                  const colors = typeColors[occ.occasion_type] || { bg: '#f1f5f9', text: '#475569' };
                                  return (
                                    <span
                                      key={id}
                                      style={{
                                        fontSize: '0.75rem',
                                        fontWeight: '600',
                                        padding: '3px 8px',
                                        borderRadius: '12px',
                                        backgroundColor: colors.bg,
                                        color: colors.text
                                      }}
                                    >
                                      {occ.occasion_name} ({occ.occasion_type})
                                    </span>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* 2. Physical Details */}
                    <div style={{ border: '1px solid #e2e8f0', borderRadius: '10px', padding: '16px 20px', backgroundColor: '#fff' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px', borderBottom: '1px solid #f1f5f9', paddingBottom: '8px' }}>
                        <h4 style={{ margin: 0, fontSize: '0.85rem', fontWeight: '700', color: '#475569', textTransform: 'uppercase', letterSpacing: '0.05em' }}>2. Physical Details</h4>
                        <button type="button" onClick={() => setActiveTab('physical')} style={{ background: 'none', border: 'none', color: '#4338ca', cursor: 'pointer', fontSize: '0.85rem', fontWeight: '600' }}>Edit</button>
                      </div>
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '14px', fontSize: '0.9rem' }}>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>ELEMENT TYPE</span>
                          <strong style={{ color: '#0f172a' }}>{productType || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>PHYSICAL APPEARANCE</span>
                          <strong style={{ color: '#0f172a' }}>{physicalAppearance || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>SIZE</span>
                          <strong style={{ color: '#0f172a' }}>{size || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>PACKAGING</span>
                          <strong style={{ color: '#0f172a' }}>{packaging || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>DIMENSIONS (L × B × T)</span>
                          <strong style={{ color: '#0f172a' }}>{[length, breadth, thickness].filter(Boolean).length > 0 ? `${[length, breadth, thickness].filter(Boolean).join(' × ')} ${dimensionUnit === 'custom' ? (customDimensionUnit || '') : dimensionUnit}` : '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>VOLUME</span>
                          <strong style={{ color: '#0f172a' }}>{volume ? `${volume} ${volumeUnit === 'custom' ? (customVolumeUnit || '') : volumeUnit}` : '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>NET WEIGHT</span>
                          <strong style={{ color: '#0f172a' }}>{netWeight ? `${netWeight} ${weightUnit === 'custom' ? (customWeightUnit || '') : weightUnit}` : '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>GROSS WEIGHT</span>
                          <strong style={{ color: '#0f172a' }}>{grossWeight ? `${grossWeight} ${weightUnit === 'custom' ? (customWeightUnit || '') : weightUnit}` : '-'}</strong>
                        </div>
                      </div>
                    </div>

                    {/* 3. Pricing & Inventory */}
                    <div style={{ border: '1px solid #e2e8f0', borderRadius: '10px', padding: '16px 20px', backgroundColor: '#fff' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px', borderBottom: '1px solid #f1f5f9', paddingBottom: '8px' }}>
                        <h4 style={{ margin: 0, fontSize: '0.85rem', fontWeight: '700', color: '#475569', textTransform: 'uppercase', letterSpacing: '0.05em' }}>3. Pricing & Tracking</h4>
                        <button type="button" onClick={() => setActiveTab('pricing')} style={{ background: 'none', border: 'none', color: '#4338ca', cursor: 'pointer', fontSize: '0.85rem', fontWeight: '600' }}>Edit</button>
                      </div>
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '14px', fontSize: '0.9rem' }}>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>PURCHASE PRICE</span>
                          <strong style={{ color: '#0f172a' }}>{currency} {purchasePrice || 0}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>SELLING PRICE</span>
                          <strong style={{ color: '#16a34a' }}>{currency} {sellingPrice || 0}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>MRP</span>
                          <strong style={{ color: '#0f172a' }}>{currency} {mrp || 0}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>DISTRIBUTOR PRICE</span>
                          <strong style={{ color: '#0f172a' }}>{currency} {distributorPrice || 0}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>DISTRIBUTOR PROFIT</span>
                          <strong style={{ color: '#0f172a' }}>{distributorProfitPercent ? `${distributorProfitPercent}%` : '0%'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>SELLING (WHOLESALE)</span>
                          <strong style={{ color: '#0f172a' }}>{currency} {sellingPriceWholesale || 0}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>WHOLESALE PROFIT</span>
                          <strong style={{ color: '#0f172a' }}>{wholesaleProfitPercent ? `${wholesaleProfitPercent}%` : '0%'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>SELLING (RETAIL / MRP)</span>
                          <strong style={{ color: '#0f172a' }}>{currency} {sellingPriceRetail || 0}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>RETAIL PROFIT</span>
                          <strong style={{ color: '#0f172a' }}>{retailProfitPercent ? `${retailProfitPercent}%` : '0%'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>PROFIT PERCENT</span>
                          <strong style={{ color: '#0f172a' }}>{profitPercent ? `${profitPercent}%` : '0%'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>GST RATE</span>
                          <strong style={{ color: '#0f172a' }}>{gstRate ? `${gstRate}%` : '0%'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>BARCODE / UPC</span>
                          <strong style={{ color: '#0f172a' }}>{barcode || '-'}</strong>
                          {barcodeImageUrl && (
                            <div style={{ marginTop: '6px' }}>
                              <a href={barcodeImageUrl} target="_blank" rel="noopener noreferrer" style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', textDecoration: 'none' }}>
                                <img src={barcodeImageUrl} alt="Barcode" style={{ height: '32px', maxWidth: '80px', objectFit: 'contain', border: '1px solid #cbd5e1', borderRadius: '4px', backgroundColor: '#fff', padding: '2px' }} />
                                <span style={{ fontSize: '0.75rem', color: '#4338ca', fontWeight: '600' }}>View Barcode</span>
                              </a>
                            </div>
                          )}
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>HSN CODE</span>
                          <strong style={{ color: '#0f172a' }}>{hsnCode || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>REORDER LEVEL</span>
                          <strong style={{ color: '#0f172a' }}>{reorderLevel || 0}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>REORDER NOTE</span>
                          <span style={{ color: '#334155' }}>{reorderNote || '-'}</span>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>PURCHASE QTY</span>
                          <strong style={{ color: '#0f172a' }}>{purchaseQuantity || 0}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>LOT NO</span>
                          <strong style={{ color: '#0f172a' }}>{lotNumber || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>BATCH NO</span>
                          <strong style={{ color: '#0f172a' }}>{batchNumber || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>MFG DATE</span>
                          <strong style={{ color: '#0f172a' }}>{manufacturingDate || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>EXPIRY DATE</span>
                          <strong style={{ color: expiryDate ? '#b91c1c' : '#0f172a' }}>{expiryDate || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>BEST BEFORE DATE</span>
                          <strong style={{ color: '#0f172a' }}>{bestBeforeDate || '-'}</strong>
                        </div>
                      </div>
                    </div>

                    {/* 4. Warehouse Review */}
                    <div style={{ border: '1px solid #e2e8f0', borderRadius: '10px', padding: '16px 20px', backgroundColor: '#fff' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px', borderBottom: '1px solid #f1f5f9', paddingBottom: '8px' }}>
                        <h4 style={{ margin: 0, fontSize: '0.85rem', fontWeight: '700', color: '#475569', textTransform: 'uppercase', letterSpacing: '0.05em' }}>4. Warehouse (Rackbin)</h4>
                        <button type="button" onClick={() => setActiveTab('racking')} style={{ background: 'none', border: 'none', color: '#4338ca', cursor: 'pointer', fontSize: '0.85rem', fontWeight: '600' }}>Edit</button>
                      </div>
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '14px', fontSize: '0.9rem' }}>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>WAREHOUSE NAME</span>
                          <strong style={{ color: '#0f172a' }}>{warehouseLocation || (warehouses.find(w => String(w.id) === String(warehouseId))?.name) || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>RACK NUMBER</span>
                          <strong style={{ color: '#0f172a' }}>{rackNumber || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>SHELF NUMBER</span>
                          <strong style={{ color: '#0f172a' }}>{shelfNumber || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>BIN LOCATION</span>
                          <strong style={{ color: '#0f172a' }}>{binLocation || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>OPENING STOCK</span>
                          <strong style={{ color: '#16a34a' }}>{openingStock || purchaseQuantity || 0}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>SAFETY STOCK</span>
                          <strong style={{ color: '#0f172a' }}>{safetyStock || '-'}</strong>
                        </div>
                      </div>
                    </div>

                    {/* 5. Schemes & Targets Review */}
                    <div style={{ border: '1px solid #e2e8f0', borderRadius: '10px', padding: '16px 20px', backgroundColor: '#fff' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px', borderBottom: '1px solid #f1f5f9', paddingBottom: '8px' }}>
                        <h4 style={{ margin: 0, fontSize: '0.85rem', fontWeight: '700', color: '#475569', textTransform: 'uppercase', letterSpacing: '0.05em' }}>5. Schemes & Targets</h4>
                        <button type="button" onClick={() => setActiveTab('schemes')} style={{ background: 'none', border: 'none', color: '#4338ca', cursor: 'pointer', fontSize: '0.85rem', fontWeight: '600' }}>Edit</button>
                      </div>
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '14px', fontSize: '0.9rem' }}>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>PRODUCT PE PRODUCT</span>
                          <strong style={{ color: '#0f172a' }}>{productPeProduct || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>DISCOUNT ON PRODUCT</span>
                          <strong style={{ color: '#0f172a' }}>{discountOnProduct || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>PRODUCT TARGET SCHEME</span>
                          <strong style={{ color: '#0f172a' }}>{productTargetScheme || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>DISCOUNT ON BILL AMOUNT</span>
                          <strong style={{ color: '#0f172a' }}>{discountOnBillAmount || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>QUARTERLY DISCOUNT (TURNOVER)</span>
                          <strong style={{ color: '#0f172a' }}>{quarterlyDiscountOnTurnover || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>YEARLY DISCOUNT (TURNOVER)</span>
                          <strong style={{ color: '#0f172a' }}>{yearlyDiscountOnTurnover || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>SEASON NAME</span>
                          <strong style={{ color: '#0f172a' }}>{seasonalSchemeName || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>SEASON FREQUENCY</span>
                          <strong style={{ color: '#0f172a' }}>{seasonalFrequency || '-'}</strong>
                        </div>
                        <div>
                          <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>SEASON APPLICABILITY</span>
                          <strong style={{ color: '#0f172a' }}>{seasonalApplicability || '-'}</strong>
                        </div>
                        {seasonalPeriodStart && (
                          <div>
                            <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>PERIOD START</span>
                            <strong style={{ color: '#0f172a' }}>{seasonalPeriodStart}</strong>
                          </div>
                        )}
                        {seasonalPeriodEnd && (
                          <div>
                            <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem', fontWeight: '600' }}>PERIOD END</span>
                            <strong style={{ color: '#0f172a' }}>{seasonalPeriodEnd}</strong>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* 5. Product Media Review */}
                    <div style={{ border: '1px solid #e2e8f0', borderRadius: '10px', padding: '16px 20px', backgroundColor: '#fff' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px', borderBottom: '1px solid #f1f5f9', paddingBottom: '8px' }}>
                        <h4 style={{ margin: 0, fontSize: '0.85rem', fontWeight: '700', color: '#475569', textTransform: 'uppercase', letterSpacing: '0.05em' }}>5. Uploaded Photos</h4>
                        <button type="button" onClick={() => setActiveTab('tracking')} style={{ background: 'none', border: 'none', color: '#4338ca', cursor: 'pointer', fontSize: '0.85rem', fontWeight: '600' }}>Edit Photos</button>
                      </div>
                      {productImages.length > 0 ? (
                        <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
                          {productImages.map((img, i) => (
                            <div key={i} style={{ position: 'relative', width: '70px', height: '70px', borderRadius: '8px', overflow: 'hidden', border: i === 0 ? '2px solid #4338ca' : '1px solid #cbd5e1' }}>
                              <img src={img} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                              {i === 0 && (
                                <span style={{ position: 'absolute', bottom: '2px', left: '2px', right: '2px', backgroundColor: 'rgba(67, 56, 202, 0.9)', color: 'white', fontSize: '0.55rem', fontWeight: '700', textAlign: 'center', borderRadius: '4px' }}>
                                  MAIN
                                </span>
                              )}
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div style={{ color: '#94a3b8', fontSize: '0.85rem', fontStyle: 'italic' }}>
                          No photos uploaded yet. (You can add photos in Labelling tab)
                        </div>
                      )}
                    </div>

                    {/* 6. Element Video Review */}
                    <div style={{ border: '1px solid #e2e8f0', borderRadius: '10px', padding: '16px 20px', backgroundColor: '#fff' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px', borderBottom: '1px solid #f1f5f9', paddingBottom: '8px' }}>
                        <h4 style={{ margin: 0, fontSize: '0.85rem', fontWeight: '700', color: '#475569', textTransform: 'uppercase', letterSpacing: '0.05em' }}>6. Element Video</h4>
                        <button type="button" onClick={() => setActiveTab('tracking')} style={{ background: 'none', border: 'none', color: '#4338ca', cursor: 'pointer', fontSize: '0.85rem', fontWeight: '600' }}>Edit Video</button>
                      </div>
                      {productVideos.length > 0 ? (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                          {productVideos.map((vUrl, vi) => (
                            <div key={vi} style={{ display: 'flex', alignItems: 'center', gap: '14px', backgroundColor: '#f8fafc', padding: '10px 14px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                              <video src={vUrl} style={{ width: '80px', height: '50px', borderRadius: '6px', objectFit: 'cover', backgroundColor: '#000' }} />
                              <div>
                                <strong style={{ display: 'block', fontSize: '0.85rem', color: '#0f172a' }}>Video {vi + 1}{vi === 0 ? ' (Primary)' : ''}</strong>
                                <span style={{ fontSize: '0.75rem', color: '#16a34a', fontWeight: '600' }}>Ready for publishing</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div style={{ color: '#94a3b8', fontSize: '0.85rem', fontStyle: 'italic' }}>
                          No video uploaded.
                        </div>
                      )}
                    </div>

                    {/* 7. Company Brochure Review */}
                    <div style={{ border: '1px solid #e2e8f0', borderRadius: '10px', padding: '16px 20px', backgroundColor: '#fff', marginTop: '14px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px', borderBottom: '1px solid #f1f5f9', paddingBottom: '8px' }}>
                        <h4 style={{ margin: 0, fontSize: '0.85rem', fontWeight: '700', color: '#475569', textTransform: 'uppercase', letterSpacing: '0.05em' }}>7. Company Brochure</h4>
                        <button type="button" onClick={() => setActiveTab('tracking')} style={{ background: 'none', border: 'none', color: '#4338ca', cursor: 'pointer', fontSize: '0.85rem', fontWeight: '600' }}>Edit Brochure</button>
                      </div>
                      {companyBrochure?.url ? (
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#f8fafc', padding: '10px 14px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                          <span style={{ fontSize: '0.85rem', fontWeight: '600', color: '#0f172a' }}>{companyBrochure.name || 'Company Brochure'}</span>
                          <a href={companyBrochure.url} target="_blank" rel="noopener noreferrer" style={{ color: '#4338ca', fontSize: '0.82rem', fontWeight: '600', textDecoration: 'none' }}>View File</a>
                        </div>
                      ) : (
                        <div style={{ color: '#94a3b8', fontSize: '0.85rem', fontStyle: 'italic' }}>
                          No company brochure attached.
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* FOOTER BUTTONS */}
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '32px', paddingTop: '20px', borderTop: '1px solid #e2e8f0' }}>
                  <button
                    type="button"
                    onClick={() => setShowForm(false)}
                    style={{
                      padding: '10px 22px',
                      border: '1px solid #cbd5e1',
                      backgroundColor: 'white',
                      color: '#334155',
                      borderRadius: '8px',
                      fontWeight: '600',
                      fontSize: '0.95rem',
                      cursor: 'pointer',
                      transition: 'all 0.2s'
                    }}
                    onMouseOver={e => e.currentTarget.style.backgroundColor = '#f8fafc'}
                    onMouseOut={e => e.currentTarget.style.backgroundColor = 'white'}
                  >
                    Cancel
                  </button>

                  <div style={{ display: 'flex', gap: '12px' }}>
                    {activeTab !== 'info' && (
                      <button
                        type="button"
                        onClick={() => {
                          const tabOrder = ['info', ...(hasVariants === 'Yes' ? ['variants'] : []), 'physical', 'pricing', 'tracking', 'racking', 'schemes', 'review'];
                          const idx = tabOrder.indexOf(activeTab);
                          if (idx > 0) setActiveTab(tabOrder[idx - 1]);
                        }}
                        style={{
                          padding: '10px 20px',
                          border: 'none',
                          backgroundColor: '#ede9fe',
                          color: '#4f46e5',
                          borderRadius: '8px',
                          fontWeight: '600',
                          fontSize: '0.95rem',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px',
                          transition: 'all 0.2s'
                        }}
                        onMouseOver={e => e.currentTarget.style.backgroundColor = '#ddd6fe'}
                        onMouseOut={e => e.currentTarget.style.backgroundColor = '#ede9fe'}
                      >
                        <ChevronLeft size={18} /> Previous
                      </button>
                    )}

                    {activeTab !== 'review' ? (
                      <button
                        type="button"
                        onClick={() => {
                          if (activeTab === 'pricing') {
                            if (
                              (purchasePrice !== '' && parseFloat(purchasePrice) < 0) ||
                              (sellingPrice !== '' && parseFloat(sellingPrice) < 0) ||
                              (mrp !== '' && parseFloat(mrp) < 0) ||
                              (gstRate !== '' && parseFloat(gstRate) < 0) ||
                              (purchaseQuantity !== '' && parseInt(purchaseQuantity, 10) < 0)
                            ) {
                              alert("Prices, GST, and quantities cannot be negative.");
                              return;
                            }
                          }
                          if (activeTab === 'tracking') {
                            if (
                              (lotNumber !== '' && !/^\d+$/.test(String(lotNumber).trim())) ||
                              (lotNumber !== '' && Number(lotNumber) < 0)
                            ) {
                              alert("Lot Number must contain only positive numbers.");
                              return;
                            }
                            if (
                              (batchNumber !== '' && !/^\d+$/.test(String(batchNumber).trim())) ||
                              (batchNumber !== '' && Number(batchNumber) < 0)
                            ) {
                              alert("Batch Number must contain only positive numbers.");
                              return;
                            }
                          }
                          const tabOrder = ['info', ...(hasVariants === 'Yes' ? ['variants'] : []), 'physical', 'pricing', 'tracking', 'racking', 'schemes', 'review'];
                          const idx = tabOrder.indexOf(activeTab);
                          if (idx < tabOrder.length - 1) setActiveTab(tabOrder[idx + 1]);
                        }}
                        style={{
                          padding: '10px 22px',
                          border: 'none',
                          backgroundColor: '#ede9fe',
                          color: '#4f46e5',
                          borderRadius: '8px',
                          fontWeight: '600',
                          fontSize: '0.95rem',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px',
                          transition: 'all 0.2s'
                        }}
                        onMouseOver={e => e.currentTarget.style.backgroundColor = '#ddd6fe'}
                        onMouseOut={e => e.currentTarget.style.backgroundColor = '#ede9fe'}
                      >
                        {activeTab === 'schemes' ? 'Proceed to Review' : 'Next'} <ChevronRight size={18} />
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={handleSubmit}
                        style={{
                          padding: '10px 28px',
                          border: 'none',
                          backgroundColor: '#16a34a',
                          color: 'white',
                          borderRadius: '8px',
                          fontWeight: '700',
                          fontSize: '0.95rem',
                          cursor: 'pointer',
                          boxShadow: '0 4px 6px -1px rgba(22, 163, 74, 0.3)',
                          transition: 'all 0.2s',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px'
                        }}
                        onMouseOver={e => e.currentTarget.style.backgroundColor = '#15803d'}
                        onMouseOut={e => e.currentTarget.style.backgroundColor = '#16a34a'}
                      >
                        ✓ Save Element
                      </button>
                    )}
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {
        showTypeForm && (
          <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
            <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '8px', width: '500px', position: 'relative' }}>
              <button type="button" onClick={() => setShowTypeForm(false)} style={{ position: 'absolute', top: '16px', right: '16px', background: 'transparent', border: 'none', fontSize: '24px', cursor: 'pointer', color: '#7f8c8d' }}>&times;</button>
              <h2 style={{ marginTop: 0, marginBottom: '24px', color: '#2c3e50', fontSize: '1.25rem' }}>Add Product Type</h2>
              <form onSubmit={(e) => { e.preventDefault(); setProductTypes([...productTypes, newTypeName]); setNewTypeName(''); setShowTypeForm(false); }}>
                <div style={{ marginBottom: '16px' }}>
                  <label style={{ display: 'block', color: '#000', fontSize: '1rem', marginBottom: '6px' }}>Type Name *</label>
                  <input type="text" required style={{ width: '100%', padding: '10px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={newTypeName} onChange={(e) => setNewTypeName(e.target.value)} />
                </div>
                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '24px', borderTop: '1px solid #ecf0f1', paddingTop: '16px' }}>
                  <button type="button" onClick={() => setShowTypeForm(false)} style={{ padding: '8px 16px', border: '1px solid #bdc3c7', backgroundColor: 'white', color: '#333', borderRadius: '4px', cursor: 'pointer' }}>Close</button>
                  <button type="submit" style={{ padding: '8px 16px', border: 'none', backgroundColor: '#1abc9c', color: 'white', borderRadius: '4px', cursor: 'pointer' }}>Save</button>
                </div>
              </form>
            </div>
          </div>
        )
      }

      {
        showGroupForm && (
          <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
            <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '8px', width: '500px', position: 'relative' }}>
              <button type="button" onClick={() => setShowGroupForm(false)} style={{ position: 'absolute', top: '16px', right: '16px', background: 'transparent', border: 'none', fontSize: '24px', cursor: 'pointer', color: '#7f8c8d' }}>&times;</button>
              <h2 style={{ marginTop: 0, marginBottom: '24px', color: '#2c3e50', fontSize: '1.25rem' }}>Add Product Group</h2>
              <form onSubmit={handleGroupSubmit}>
                <div style={{ marginBottom: '16px' }}>
                  <label style={{ display: 'block', color: '#000', fontSize: '1rem', marginBottom: '6px' }}>Group Name *</label>
                  <input type="text" required style={{ width: '100%', padding: '10px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={newGroupName} onChange={(e) => setNewGroupName(e.target.value)} />
                </div>
                <div style={{ marginBottom: '16px' }}>
                  <label style={{ display: 'block', color: '#000', fontSize: '1rem', marginBottom: '6px' }}>Description</label>
                  <textarea style={{ width: '100%', padding: '10px', border: '1px solid #bdc3c7', borderRadius: '4px', minHeight: '80px', resize: 'vertical' }} value={newGroupDescription} onChange={(e) => setNewGroupDescription(e.target.value)}></textarea>
                </div>
                <div style={{ marginBottom: '16px' }}>
                  <label style={{ display: 'block', color: '#000', fontSize: '1rem', marginBottom: '6px' }}>Parent Group (Optional)</label>
                  <select style={{ width: '100%', padding: '10px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={newGroupParentId} onChange={(e) => setNewGroupParentId(e.target.value)}>
                    <option value="">-- None (Make this a Root Group) --</option>
                    {groups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                  </select>
                </div>
                <div style={{ marginBottom: '16px' }}>
                  <label style={{ display: 'block', color: '#000', fontSize: '1rem', marginBottom: '6px' }}>Status</label>
                  <select style={{ width: '100%', padding: '10px', border: '1px solid #bdc3c7', borderRadius: '4px' }} value={newGroupStatus} onChange={(e) => setNewGroupStatus(e.target.value)}>
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                  </select>
                </div>
                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '24px', borderTop: '1px solid #ecf0f1', paddingTop: '16px' }}>
                  <button type="button" onClick={() => setShowGroupForm(false)} style={{ padding: '8px 16px', border: '1px solid #bdc3c7', backgroundColor: 'white', color: '#333', borderRadius: '4px', cursor: 'pointer' }}>Close</button>
                  <button type="submit" style={{ padding: '8px 16px', border: 'none', backgroundColor: '#1abc9c', color: 'white', borderRadius: '4px', cursor: 'pointer' }}>Save Group</button>
                </div>
              </form>
            </div>
          </div>
        )
      }

      {showAddOccasionModal && (
        <AddOccasionModal
          isOpen={showAddOccasionModal}
          onClose={() => setShowAddOccasionModal(false)}
          defaultType={selectedOccasionType || 'Festival'}
          onOccasionAdded={(newOcc) => {
            fetchOccasions();
            if (newOcc && newOcc.id) {
              setSelectedOccasionId(newOcc.id);
              if (newOcc.occasion_type) {
                setSelectedOccasionType(newOcc.occasion_type);
              }
            }
          }}
        />
      )}

    </div >
  );
};

export default Products;
