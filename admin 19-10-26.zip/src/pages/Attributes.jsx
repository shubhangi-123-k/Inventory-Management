import { useState, useEffect } from 'react';
import api from '../api/axios';
import { Plus } from 'lucide-react';

const Attributes = () => {
  const [attributes, setAttributes] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Form State
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState('');
  const [dataType, setDataType] = useState('String');
  const [uom, setUom] = useState('');
  const [isRequired, setIsRequired] = useState(false);

  const handleToggleStatus = async (id, currentStatus) => {
    const newStatus = currentStatus === 'Active' ? 'Inactive' : 'Active';
    try {
      await api.put(`/admin/attributes/${id}`, { status: newStatus });
      fetchAttributes();
    } catch (err) {
      alert("Failed to update status");
    }
  };

  const fetchAttributes = async () => {
    try {
      setLoading(true);
      const response = await api.get('/admin/attributes');
      setAttributes(response.data || []);
      setLoading(false);
    } catch (error) {
      console.error("Attributes fetch error", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAttributes();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/admin/attributes', { 
        name, 
        data_type: dataType, 
        uom, 
        is_required: isRequired 
      });
      setName('');
      setDataType('String');
      setUom('');
      setIsRequired(false);
      setShowForm(false);
      fetchAttributes();
    } catch (error) {
      console.error("Failed to create attribute", error);
      alert("Failed to create attribute");
    }
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
        <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>Product Attributes</h1>
                <button className="btn btn-primary" style={{ width: 'auto' }} onClick={() => setShowForm(!showForm)}>
          <Plus size={18} /> {showForm ? 'Cancel' : 'Add Attribute'}
        </button>
      </div>

      {showForm && (
        <div style={{ background: 'var(--surface)', padding: '24px', borderRadius: '12px', marginBottom: '24px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
          <h2 style={{ marginBottom: '16px', fontSize: '1.125rem', fontWeight: '600' }}>Create New Attribute</h2>
          <form onSubmit={handleSubmit} style={{ display: 'flex', gap: '16px', alignItems: 'flex-end', flexWrap: 'wrap' }}>
            <div className="form-group" style={{ marginBottom: 0, flex: '1 1 200px' }}>
              <label className="form-label">Attribute Name</label>
              <input type="text" className="form-control" value={name} onChange={(e) => setName(e.target.value)} required />
            </div>
            <div className="form-group" style={{ marginBottom: 0, flex: '1 1 150px' }}>
              <label className="form-label">Data Type</label>
              <select className="form-control" value={dataType} onChange={(e) => setDataType(e.target.value)}>
                <option value="String">String</option>
                <option value="Number">Number</option>
                <option value="Boolean">Boolean</option>
                <option value="Date">Date</option>
                <option value="List">List</option>
              </select>
            </div>
            <div className="form-group" style={{ marginBottom: 0, flex: '1 1 100px' }}>
              <label className="form-label">UOM (Optional)</label>
              <input type="text" className="form-control" placeholder="e.g. kg, cm" value={uom} onChange={(e) => setUom(e.target.value)} />
            </div>
            <div className="form-group" style={{ marginBottom: 0, flex: '1 1 100px', display: 'flex', alignItems: 'center', height: '42px' }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
                <input type="checkbox" checked={isRequired} onChange={(e) => setIsRequired(e.target.checked)} />
                Required
              </label>
            </div>
            <button type="submit" className="btn btn-primary" style={{ width: 'auto' }}>Save</button>
          </form>
        </div>
      )}

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Data Type</th>
              <th>UOM</th>
              <th>Required</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan="6" style={{ textAlign: 'center' }}>Loading attributes...</td></tr>
            ) : attributes.length > 0 ? (
              attributes.map((attr) => (
                <tr key={attr.id}>
                  <td>#{attr.id}</td>
                  <td style={{ fontWeight: '500' }}>{attr.name}</td>
                  <td>{attr.data_type}</td>
                  <td style={{ color: 'var(--text-muted)' }}>{attr.uom || '-'}</td>
                  <td>{attr.is_required ? 'Yes' : 'No'}</td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center' }}>
                      <div 
                        onClick={() => handleToggleStatus(attr.id, attr.status)}
                        style={{ 
                          cursor: 'pointer',
                          display: 'inline-flex',
                          alignItems: 'center',
                          justifyContent: attr.status === 'Active' ? 'flex-end' : 'flex-start',
                          width: '40px',
                          height: '22px',
                          background: attr.status === 'Active' ? 'var(--primary)' : '#cbd5e1',
                          borderRadius: '11px',
                          padding: '2px',
                          transition: 'background 0.2s',
                          marginRight: '8px',
                          verticalAlign: 'middle'
                        }}
                        title="Toggle Status"
                      >
                        <div style={{ 
                          width: '18px', 
                          height: '18px', 
                          background: '#fff', 
                          borderRadius: '50%',
                          boxShadow: '0 1px 2px rgba(0,0,0,0.2)'
                        }} />
                      </div>
                      <span style={{ verticalAlign: 'middle', fontSize: '0.875rem', color: attr.status === 'Active' ? 'var(--primary)' : 'var(--text-muted)' }}>
                        {attr.status || 'Active'}
                      </span>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr><td colSpan="6" style={{ textAlign: 'center' }}>No attributes found.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Attributes;
