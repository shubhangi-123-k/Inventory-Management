import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api/axios';
import { 
  Package, 
  AlertTriangle, 
  AlertOctagon, 
  Clock, 
  ShoppingCart, 
  TrendingUp, 
  ArrowRight,
  Warehouse,
  CheckCircle2,
  RefreshCw
} from 'lucide-react';

const Dashboard = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const fetchDashboard = async () => {
    try {
      setLoading(true);
      const response = await api.get('/admin/dashboard');
      if (response.data?.data) {
        setStats(response.data.data);
      }
      setLoading(false);
    } catch (error) {
      console.error("Dashboard fetch error", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboard();
  }, []);

  if (loading) {
    return (
      <div style={{ padding: '40px', textAlign: 'center', color: '#64748b' }}>
        <RefreshCw size={28} className="animate-spin" style={{ margin: '0 auto 12px' }} />
        <p>Loading real-time inventory ...</p>
      </div>
    );
  }

  const criticalCount = stats?.criticalStockProducts || 0;
  const belowReorderCount = stats?.productsBelowReorder || 0;
  const lowCount = stats?.lowStockProducts || 0;
  const pendingPRs = stats?.pendingPurchaseRequests || 0;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '28px' }}>
      {/* HEADER */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <h1 style={{ fontSize: '1.75rem', fontWeight: '800', color: '#0f172a', margin: 0, letterSpacing: '-0.02em' }}>
            Inventory Dashboard
          </h1>
          <p style={{ margin: '4px 0 0 0', color: '#64748b', fontSize: '0.95rem' }}>
            Automated reorder monitoring, stock health tracking, and procurement drafts
          </p>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button 
            onClick={() => navigate('/inventory?filter=reorder')}
            className="btn btn-primary"
            style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 18px', fontWeight: '600' }}
          >
            <AlertTriangle size={18} /> Review Reorder List ({belowReorderCount})
          </button>
          <button 
            onClick={fetchDashboard}
            style={{ padding: '10px 14px', borderRadius: '8px', border: '1px solid #cbd5e1', backgroundColor: '#fff', cursor: 'pointer', display: 'flex', alignItems: 'center', color: '#475569' }}
            title="Refresh Metrics"
          >
            <RefreshCw size={18} />
          </button>
        </div>
      </div>

      {/* KPI METRIC CARDS GRID (5 Cards) */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))', gap: '18px' }}>
        {/* Total Products */}
        <div className="stat-card" style={{ borderLeft: '4px solid #3b82f6', cursor: 'pointer' }} onClick={() => navigate('/products')}>
          <div className="stat-icon" style={{ backgroundColor: 'rgba(59, 130, 246, 0.1)', color: '#3b82f6' }}>
            <Package size={22} />
          </div>
          <div className="stat-content">
            <h3 style={{ fontSize: '0.85rem', color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Total Active Products</h3>
            <p style={{ fontSize: '1.75rem', fontWeight: '800', color: '#0f172a', margin: '4px 0 0 0' }}>{stats?.totalProducts || 0}</p>
          </div>
        </div>

        {/* Below Reorder Level */}
        <div className="stat-card" style={{ borderLeft: '4px solid #ef4444', cursor: 'pointer' }} onClick={() => navigate('/inventory?filter=reorder')}>
          <div className="stat-icon" style={{ backgroundColor: 'rgba(239, 68, 68, 0.12)', color: '#ef4444' }}>
            <AlertTriangle size={22} />
          </div>
          <div className="stat-content">
            <h3 style={{ fontSize: '0.85rem', color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Below Reorder Level</h3>
            <p style={{ fontSize: '1.75rem', fontWeight: '800', color: '#ef4444', margin: '4px 0 0 0' }}>{belowReorderCount}</p>
          </div>
        </div>

        {/* Critical Stock */}
        <div className="stat-card" style={{ borderLeft: '4px solid #b91c1c', cursor: 'pointer' }} onClick={() => navigate('/inventory?filter=critical')}>
          <div className="stat-icon" style={{ backgroundColor: 'rgba(185, 28, 28, 0.12)', color: '#b91c1c' }}>
            <AlertOctagon size={22} />
          </div>
          <div className="stat-content">
            <h3 style={{ fontSize: '0.85rem', color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Critical / Zero Stock</h3>
            <p style={{ fontSize: '1.75rem', fontWeight: '800', color: '#b91c1c', margin: '4px 0 0 0' }}>{criticalCount}</p>
          </div>
        </div>

        {/* Low Stock (Approaching ROL) */}
        <div className="stat-card" style={{ borderLeft: '4px solid #f59e0b', cursor: 'pointer' }} onClick={() => navigate('/inventory?filter=low')}>
          <div className="stat-icon" style={{ backgroundColor: 'rgba(245, 158, 11, 0.12)', color: '#f59e0b' }}>
            <Clock size={22} />
          </div>
          <div className="stat-content">
            <h3 style={{ fontSize: '0.85rem', color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Low Stock Buffer</h3>
            <p style={{ fontSize: '1.75rem', fontWeight: '800', color: '#f59e0b', margin: '4px 0 0 0' }}>{lowCount}</p>
          </div>
        </div>

        {/* Pending Purchase Requests */}
        <div className="stat-card" style={{ borderLeft: '4px solid #8b5cf6', cursor: 'pointer' }} onClick={() => navigate('/purchases?tab=requests')}>
          <div className="stat-icon" style={{ backgroundColor: 'rgba(139, 92, 246, 0.12)', color: '#8b5cf6' }}>
            <ShoppingCart size={22} />
          </div>
          <div className="stat-content">
            <h3 style={{ fontSize: '0.85rem', color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Draft Purchase Requests</h3>
            <p style={{ fontSize: '1.75rem', fontWeight: '800', color: '#8b5cf6', margin: '4px 0 0 0' }}>{pendingPRs}</p>
          </div>
        </div>
      </div>

      {/* REORDER & VISUAL ANALYTICS GRID */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(420px, 1fr))', gap: '24px' }}>
        {/* Top Low Stock Products Progress List */}
        <div className="table-container" style={{ padding: '24px', margin: 0 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '18px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <div style={{ padding: '6px 10px', borderRadius: '6px', backgroundColor: 'rgba(239, 68, 68, 0.1)', color: '#ef4444' }}>
                <AlertTriangle size={18} />
              </div>
              <div>
                <h2 style={{ fontSize: '1.1rem', fontWeight: '700', margin: 0, color: '#0f172a' }}>Top Priority Reorder Items</h2>
                <p style={{ fontSize: '0.8rem', color: '#64748b', margin: '2px 0 0 0' }}>Products farthest below minimum safety thresholds</p>
              </div>
            </div>
            <button 
              onClick={() => navigate('/inventory')} 
              style={{ background: 'none', border: 'none', color: '#3b82f6', fontSize: '0.85rem', fontWeight: '600', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px' }}
            >
              View All <ArrowRight size={14} />
            </button>
          </div>

          {stats?.topLowStockProducts && stats.topLowStockProducts.length > 0 ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              {stats.topLowStockProducts.map((p) => (
                <div key={p.id} style={{ padding: '14px 16px', borderRadius: '10px', backgroundColor: '#f8fafc', border: '1px solid #e2e8f0' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                    <div>
                      <strong style={{ fontSize: '0.95rem', color: '#0f172a' }}>{p.name}</strong>
                      <span style={{ fontSize: '0.8rem', color: '#64748b', marginLeft: '8px' }}>({p.sku || 'No SKU'})</span>
                    </div>
                    <span style={{ 
                      padding: '3px 8px', 
                      borderRadius: '6px', 
                      fontSize: '0.75rem', 
                      fontWeight: '700',
                      backgroundColor: p.stock_status === 'CRITICAL_STOCK' ? '#fee2e2' : '#fef3c7',
                      color: p.stock_status === 'CRITICAL_STOCK' ? '#b91c1c' : '#d97706'
                    }}>
                      {p.stock_status.replace('_', ' ')}
                    </span>
                  </div>

                  {/* Stock Bar */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div style={{ flex: 1, height: '8px', backgroundColor: '#e2e8f0', borderRadius: '999px', overflow: 'hidden' }}>
                      <div 
                        style={{ 
                          width: `${Math.min(p.percentage, 100)}%`, 
                          height: '100%', 
                          backgroundColor: p.stock_status === 'CRITICAL_STOCK' ? '#ef4444' : '#f59e0b',
                          borderRadius: '999px'
                        }} 
                      />
                    </div>
                    <span style={{ fontSize: '0.85rem', fontWeight: '700', color: '#334155', minWidth: '85px', textAlign: 'right' }}>
                      {p.current_stock} / {p.reorder_level} units
                    </span>
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '8px', fontSize: '0.75rem', color: '#64748b' }}>
                    <span>Location: {p.warehouse_name}</span>
                    <span style={{ fontWeight: '600', color: '#4338ca' }}>Recommended Reorder: +{p.reorder_qty} units</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div style={{ padding: '36px 20px', textAlign: 'center', color: '#10b981', backgroundColor: 'rgba(16, 185, 129, 0.05)', borderRadius: '10px' }}>
              <CheckCircle2 size={36} style={{ margin: '0 auto 8px' }} />
              <strong style={{ display: 'block', fontSize: '1rem' }}>All Stock Healthy</strong>
              <p style={{ margin: '4px 0 0 0', fontSize: '0.85rem', color: '#64748b' }}>No products currently below their reorder safety thresholds.</p>
            </div>
          )}
        </div>

        {/* Warehouse-wise Low Stock Breakdown */}
        <div className="table-container" style={{ padding: '24px', margin: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '18px' }}>
            <div style={{ padding: '6px 10px', borderRadius: '6px', backgroundColor: 'rgba(59, 130, 246, 0.1)', color: '#3b82f6' }}>
              <Warehouse size={18} />
            </div>
            <div>
              <h2 style={{ fontSize: '1.1rem', fontWeight: '700', margin: 0, color: '#0f172a' }}>Warehouse Low Stock Distribution</h2>
              <p style={{ fontSize: '0.8rem', color: '#64748b', margin: '2px 0 0 0' }}>Locations with items requiring replenishment</p>
            </div>
          </div>

          {stats?.warehouseWiseLowStock && stats.warehouseWiseLowStock.length > 0 ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {stats.warehouseWiseLowStock.map((w, idx) => (
                <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', borderRadius: '8px', border: '1px solid #e2e8f0', backgroundColor: '#fff' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <div style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#ef4444' }} />
                    <span style={{ fontWeight: '600', color: '#1e293b' }}>{w.warehouse}</span>
                  </div>
                  <span style={{ padding: '4px 10px', borderRadius: '999px', backgroundColor: 'rgba(239, 68, 68, 0.1)', color: '#ef4444', fontWeight: '700', fontSize: '0.85rem' }}>
                    {w.low_stock_count} Items Low
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div style={{ padding: '36px 20px', textAlign: 'center', color: '#64748b', backgroundColor: '#f8fafc', borderRadius: '10px' }}>
              <CheckCircle2 size={32} style={{ margin: '0 auto 8px', color: '#10b981' }} />
              <p style={{ margin: 0, fontSize: '0.9rem' }}>All warehouse facilities operating within safe buffer limits.</p>
            </div>
          )}

          {/* Quick Shortcuts */}
          <div style={{ marginTop: '24px', paddingTop: '18px', borderTop: '1px solid #f1f5f9' }}>
            <h4 style={{ fontSize: '0.85rem', fontWeight: '700', color: '#64748b', textTransform: 'uppercase', marginBottom: '10px' }}>Quick Procurement Actions</h4>
            <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
              <button 
                onClick={() => navigate('/purchases?action=new')}
                style={{ padding: '8px 14px', borderRadius: '6px', border: '1px solid #cbd5e1', backgroundColor: '#fff', fontSize: '0.85rem', fontWeight: '600', cursor: 'pointer', color: '#334155' }}
              >
                + Create Purchase Order
              </button>
              <button 
                onClick={() => navigate('/inventory')}
                style={{ padding: '8px 14px', borderRadius: '6px', border: '1px solid #cbd5e1', backgroundColor: '#fff', fontSize: '0.85rem', fontWeight: '600', cursor: 'pointer', color: '#334155' }}
              >
                Stock Adjustment Ledger
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* RECENT SALES ORDERS TABLE */}
      <div className="table-container" style={{ margin: 0 }}>
        <div className="table-header" style={{ padding: '16px 20px', borderBottom: '1px solid #e2e8f0' }}>
          <h2 style={{ fontSize: '1.125rem', fontWeight: '700', color: '#0f172a', margin: 0 }}>Recent Sales Activity</h2>
        </div>
        <table>
          <thead>
            <tr>
              <th>SO Number</th>
              <th>Customer</th>
              <th>Date</th>
              <th>Total Amount</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {stats?.recentOrders && stats.recentOrders.length > 0 ? (
              stats.recentOrders.map(order => (
                <tr key={order.id}>
                  <td style={{ fontWeight: '600', color: '#3b82f6' }}>{order.so_number}</td>
                  <td>{order.customer_name || 'Walk-in Customer'}</td>
                  <td>{order.date}</td>
                  <td style={{ fontWeight: '700' }}>${parseFloat(order.total_amount || 0).toFixed(2)}</td>
                  <td>
                    <span className="badge active" style={{ 
                      backgroundColor: order.status === 'Confirmed' ? '#dcfce7' : '#e0e7ff',
                      color: order.status === 'Confirmed' ? '#15803d' : '#4338ca'
                    }}>
                      {order.status}
                    </span>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5" style={{ textAlign: 'center', padding: '24px', color: '#64748b' }}>No recent sales orders recorded yet.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Dashboard;
