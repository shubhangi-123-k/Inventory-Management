import { useState, useEffect } from 'react';
import api from '../api/axios';
import { Plus } from 'lucide-react';

const Countries = () => {
  const [countries, setCountries] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Form State
  const [showForm, setShowForm] = useState(false);
  const [iso2, setIso2] = useState('');
  const [iso3, setIso3] = useState('');
  const [countryName, setCountryName] = useState('');
  const [region, setRegion] = useState('');
  const [currency, setCurrency] = useState('');

  const handleToggleStatus = async (id, currentStatus) => {
    const newStatus = currentStatus === 'Active' ? 'Inactive' : 'Active';
    try {
      await api.put(`/admin/countries/${id}`, { status: newStatus });
      fetchCountries();
    } catch (err) {
      alert("Failed to update status");
    }
  };

  const fetchCountries = async () => {
    try {
      setLoading(true);
      const response = await api.get('/admin/countries');
      setCountries(response.data.data || []);
      setLoading(false);
    } catch (error) {
      console.error("Countries fetch error", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCountries();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/admin/countries', { 
        iso2, 
        iso3, 
        country_name: countryName, 
        region, 
        currency,
        status: 'Active' 
      });
      setIso2(''); setIso3(''); setCountryName(''); setRegion(''); setCurrency('');
      setShowForm(false);
      fetchCountries();
    } catch (error) {
      console.error("Failed to create country", error);
      alert("Failed to create country");
    }
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
        <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>Countries & Regions</h1>
                <button className="btn btn-primary" style={{ width: 'auto' }} onClick={() => setShowForm(!showForm)}>
          <Plus size={18} /> {showForm ? 'Cancel' : 'Add Country'}
        </button>
      </div>

      {showForm && (
        <div style={{ background: 'var(--surface)', padding: '24px', borderRadius: '12px', marginBottom: '24px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
          <h2 style={{ marginBottom: '16px', fontSize: '1.125rem', fontWeight: '600' }}>Create New Country</h2>
          <form onSubmit={handleSubmit} style={{ display: 'flex', gap: '16px', alignItems: 'flex-end', flexWrap: 'wrap' }}>
            <div className="form-group" style={{ marginBottom: 0, flex: '1 1 200px' }}>
              <label className="form-label">Country Name</label>
              <input type="text" className="form-control" value={countryName} onChange={(e) => setCountryName(e.target.value)} required />
            </div>
            <div className="form-group" style={{ marginBottom: 0, flex: '1 1 100px' }}>
              <label className="form-label">ISO2</label>
              <input type="text" className="form-control" maxLength="2" placeholder="US" value={iso2} onChange={(e) => setIso2(e.target.value)} required />
            </div>
            <div className="form-group" style={{ marginBottom: 0, flex: '1 1 100px' }}>
              <label className="form-label">ISO3</label>
              <input type="text" className="form-control" maxLength="3" placeholder="USA" value={iso3} onChange={(e) => setIso3(e.target.value)} required />
            </div>
            <div className="form-group" style={{ marginBottom: 0, flex: '1 1 150px' }}>
              <label className="form-label">Region</label>
              <input type="text" className="form-control" placeholder="North America" value={region} onChange={(e) => setRegion(e.target.value)} />
            </div>
            <div className="form-group" style={{ marginBottom: 0, flex: '1 1 100px' }}>
              <label className="form-label">Currency</label>
              <input type="text" className="form-control" placeholder="USD" value={currency} onChange={(e) => setCurrency(e.target.value)} />
            </div>
            <button type="submit" className="btn btn-primary" style={{ width: 'auto' }}>Save</button>
          </form>
        </div>
      )}

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>ISO2/ISO3</th>
              <th>Region</th>
              <th>Currency</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan="5" style={{ textAlign: 'center' }}>Loading countries...</td></tr>
            ) : countries.length > 0 ? (
              countries.map((c) => (
                <tr key={c.id}>
                  <td style={{ fontWeight: '500' }}>{c.country_name}</td>
                  <td>{c.iso2} / {c.iso3}</td>
                  <td>{c.region || '-'}</td>
                  <td style={{ color: 'var(--text-muted)' }}>{c.currency || '-'}</td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center' }}>
                      <div 
                        onClick={() => handleToggleStatus(c.id, c.status)}
                        style={{ 
                          cursor: 'pointer',
                          display: 'inline-flex',
                          alignItems: 'center',
                          justifyContent: c.status === 'Active' ? 'flex-end' : 'flex-start',
                          width: '40px',
                          height: '22px',
                          background: c.status === 'Active' ? 'var(--primary)' : '#cbd5e1',
                          borderRadius: '11px',
                          padding: '2px',
                          transition: 'background 0.2s',
                          marginRight: '8px',
                          verticalAlign: 'middle'
                        }}
                        title="Toggle Status"
                      >
                        <div style={{ 
                          width: '18px', 
                          height: '18px', 
                          background: '#fff', 
                          borderRadius: '50%',
                          boxShadow: '0 1px 2px rgba(0,0,0,0.2)'
                        }} />
                      </div>
                      <span style={{ verticalAlign: 'middle', fontSize: '0.875rem', color: c.status === 'Active' ? 'var(--primary)' : 'var(--text-muted)' }}>
                        {c.status || 'Active'}
                      </span>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr><td colSpan="5" style={{ textAlign: 'center' }}>No countries found.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Countries;
