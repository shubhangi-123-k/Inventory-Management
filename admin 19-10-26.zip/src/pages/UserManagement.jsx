import React from 'react';

const UserManagement = () => {
  return (
    <div style={{ padding: '24px' }}>
      <h1>User Management</h1>
      <p>This is a protected page. Only Super Admins can manage users.</p>
    </div>
  );
};

export default UserManagement;
