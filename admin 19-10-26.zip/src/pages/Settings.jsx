import React from 'react';

const Settings = () => {
  return (
    <div style={{ padding: '24px' }}>
      <h1>System Settings</h1>
      <p>This is a protected page. Only Super Admins can access settings.</p>
    </div>
  );
};

export default Settings;
