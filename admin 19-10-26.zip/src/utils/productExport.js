/**
 * Product Export Utility: Generates Print-ready PDF Brochure and CSV/Excel datasheet.
 */

export const downloadProductBrochurePDF = (product, groups = [], brands = []) => {
  if (!product) return;

  const brandObj = brands.find(b => b.id == product.brand_id);
  const brandName = brandObj ? brandObj.name : (product.Brand?.name || '-');

  let groupPath = [];
  let currentId = product.group_id;
  while (currentId) {
    const g = groups.find(x => x.id == currentId);
    if (g) {
      groupPath.unshift(g.name);
      currentId = g.parent_id;
    } else {
      break;
    }
  }
  const groupName = groupPath.length > 0 ? groupPath.join(' › ') : (product.Group?.name || '-');

  const mainImage = product.image_url || (Array.isArray(product.images) && product.images[0]) || '';
  const barcodeImage = product.barcode_image_url || '';

  const occasionsText = product.occasions && product.occasions.length > 0
    ? product.occasions.map(o => `${o.occasion_name} (${o.occasion_type})`).join(', ')
    : 'None';

  const attributesList = Array.isArray(product.attributes) ? product.attributes : [];

  const printWindow = window.open('', '_blank', 'width=900,height=1000');
  if (!printWindow) {
    alert('Please allow popups to generate and download the product brochure PDF.');
    return;
  }

  const htmlContent = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>${product.name || product.product_name} - Product Brochure</title>
      <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        
        @page {
          size: A4;
          margin: 12mm 15mm;
        }

        body {
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
          color: #1e293b;
          background: #ffffff;
          margin: 0;
          padding: 24px;
          line-height: 1.5;
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
        }

        .header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          border-bottom: 2px solid #0f172a;
          padding-bottom: 16px;
          margin-bottom: 20px;
        }

        .header-title h1 {
          margin: 0 0 6px 0;
          font-size: 26px;
          font-weight: 800;
          color: #0f172a;
        }

        .badge {
          display: inline-block;
          background: #0f172a;
          color: #fff;
          font-size: 11px;
          font-weight: 700;
          padding: 4px 10px;
          border-radius: 4px;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .badge-status {
          background: #10b981;
        }

        .sku-tag {
          font-size: 13px;
          color: #64748b;
          font-weight: 600;
          margin-top: 4px;
        }

        .hero-section {
          display: grid;
          grid-template-columns: 260px 1fr;
          gap: 24px;
          margin-bottom: 24px;
          background: #f8fafc;
          border: 1px solid #e2e8f0;
          border-radius: 12px;
          padding: 16px;
        }

        .image-box {
          width: 260px;
          height: 260px;
          border-radius: 8px;
          background: #fff;
          border: 1px solid #cbd5e1;
          display: flex;
          align-items: center;
          justify-content: center;
          overflow: hidden;
        }

        .image-box img {
          max-width: 100%;
          max-height: 100%;
          object-fit: contain;
        }

        .price-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 12px;
          margin-bottom: 16px;
        }

        .price-card {
          background: #fff;
          border: 1px solid #e2e8f0;
          padding: 12px 14px;
          border-radius: 8px;
        }

        .price-card .label {
          font-size: 11px;
          color: #64748b;
          font-weight: 600;
          text-transform: uppercase;
        }

        .price-card .val {
          font-size: 18px;
          font-weight: 700;
          color: #0f172a;
          margin-top: 2px;
        }

        .price-card.primary {
          background: #0f172a;
          color: #fff;
          border-color: #0f172a;
        }

        .price-card.primary .label {
          color: #94a3b8;
        }

        .price-card.primary .val {
          color: #38bdf8;
        }

        .section-title {
          font-size: 14px;
          font-weight: 700;
          color: #0f172a;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          border-left: 4px solid #0f172a;
          padding-left: 8px;
          margin: 20px 0 10px 0;
        }

        table.spec-table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 16px;
          font-size: 12.5px;
        }

        table.spec-table th, table.spec-table td {
          padding: 8px 12px;
          border: 1px solid #e2e8f0;
          text-align: left;
        }

        table.spec-table th {
          background: #f1f5f9;
          font-weight: 600;
          color: #334155;
          width: 25%;
        }

        table.spec-table td {
          background: #ffffff;
          color: #1e293b;
          font-weight: 500;
        }

        .barcode-box {
          text-align: right;
        }

        .barcode-box img {
          max-height: 55px;
          display: inline-block;
        }

        .footer {
          margin-top: 30px;
          padding-top: 12px;
          border-top: 1px solid #e2e8f0;
          display: flex;
          justify-content: space-between;
          font-size: 11px;
          color: #94a3b8;
        }

        @media print {
          body {
            padding: 0;
          }
          .no-print {
            display: none;
          }
        }
      </style>
    </head>
    <body>
      <div class="no-print" style="margin-bottom: 20px; display: flex; justify-content: flex-end; gap: 10px;">
        <button onclick="window.print()" style="padding: 10px 20px; background: #0f172a; color: white; border: none; border-radius: 6px; font-weight: bold; cursor: pointer;">
          🖨️ Print / Save as PDF
        </button>
        <button onclick="window.close()" style="padding: 10px 20px; background: #e2e8f0; color: #334155; border: none; border-radius: 6px; font-weight: bold; cursor: pointer;">
          Close
        </button>
      </div>

      <div class="header">
        <div class="header-title">
          <span class="badge">Official Product Brochure</span>
          <span class="badge badge-status">${product.status || 'Active'}</span>
          <h1>${product.name || product.product_name}</h1>
          <div class="sku-tag">
            SKU: <strong>${product.sku || product.internal_sku || '-'}</strong> | 
            Product Code: <strong>${product.product_code || '-'}</strong> | 
            Brand: <strong>${brandName}</strong>
          </div>
        </div>
        ${barcodeImage ? `
          <div class="barcode-box">
            <img src="${barcodeImage}" alt="Barcode" />
            <div style="font-size: 10px; color: #64748b; font-family: monospace;">${product.gtin_ean_upc || ''}</div>
          </div>
        ` : ''}
      </div>

      <div class="hero-section">
        <div class="image-box">
          ${mainImage 
            ? `<img src="${mainImage}" alt="${product.name || 'Product Image'}" />` 
            : `<div style="color: #94a3b8; font-size: 13px; font-weight: 600;">No Product Image</div>`}
        </div>
        <div>
          <div class="price-grid">
            <div class="price-card primary">
              <div class="label">Selling Price</div>
              <div class="val">${product.currency || '₹'} ${parseFloat(product.selling_price || 0).toLocaleString()}</div>
            </div>
            <div class="price-card">
              <div class="label">M.R.P.</div>
              <div class="val">${product.currency || '₹'} ${parseFloat(product.mrp || 0).toLocaleString()}</div>
            </div>
            <div class="price-card">
              <div class="label">GST Rate</div>
              <div class="val">${product.gst_rate || 0}%</div>
            </div>
          </div>

          <table class="spec-table" style="margin: 0;">
            <tr>
              <th>Category / Group</th>
              <td>${groupName}</td>
            </tr>
            <tr>
              <th>Item Classification</th>
              <td>${product.item_type || 'Goods'}</td>
            </tr>
            <tr>
              <th>Stock On Hand</th>
              <td><strong>${product.purchase_quantity || 0} Units</strong> (Reorder: ${product.reorder_level || 0})</td>
            </tr>
            <tr>
              <th>Occasions / Season</th>
              <td>${occasionsText}</td>
            </tr>
          </table>
        </div>
      </div>

      <div class="section-title">Commercial & Lot Specifications</div>
      <table class="spec-table">
        <tr>
          <th>Lot Number</th>
          <td>${product.lot_number || '-'}</td>
          <th>Batch Number</th>
          <td>${product.batch_number || '-'}</td>
        </tr>
        <tr>
          <th>Manufacturing Date</th>
          <td>${product.manufacturing_date || '-'}</td>
          <th>Expiry Date</th>
          <td>${product.expiry_date || '-'}</td>
        </tr>
        <tr>
          <th>Purchase Price</th>
          <td>${product.currency || '₹'} ${parseFloat(product.purchase_price || 0).toLocaleString()}</td>
          <th>GTIN / EAN / UPC</th>
          <td>${product.gtin_ean_upc || '-'}</td>
        </tr>
      </table>

      <div class="section-title">Physical Dimensions & Packaging</div>
      <table class="spec-table">
        <tr>
          <th>Appearance / Shape</th>
          <td>${product.physical_appearance || product.physical_shape || '-'}</td>
          <th>Size / Dimensions</th>
          <td>${product.size || (product.length ? `${product.length} × ${product.breadth} × ${product.thickness}` : '-')}</td>
        </tr>
        <tr>
          <th>Packaging Type</th>
          <td>${product.packaging || '-'}</td>
          <th>Net / Gross Weight</th>
          <td>${product.net_weight || '-'} / ${product.gross_weight || '-'}</td>
        </tr>
      </table>

      ${product.short_description ? `
        <div class="section-title">Product Description</div>
        <div style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 12px; border-radius: 8px; font-size: 13px; color: #334155; margin-bottom: 16px;">
          ${product.short_description}
        </div>
      ` : ''}

      ${attributesList.length > 0 ? `
        <div class="section-title">Custom Specifications & Attributes</div>
        <table class="spec-table">
          <thead>
            <tr>
              <th style="width: 50%;">Attribute</th>
              <th style="width: 50%;">Value</th>
            </tr>
          </thead>
          <tbody>
            ${attributesList.map(a => `
              <tr>
                <td><strong>${a.Attribute?.name || a.name || 'Feature'}</strong></td>
                <td>${a.value || '-'}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      ` : ''}

      <div class="footer">
        <div>Generated by Inventory Management System</div>
        <div>Date: ${new Date().toLocaleDateString()}</div>
      </div>

      <script>
        window.onload = function() {
          setTimeout(function() {
            window.print();
          }, 400);
        };
      </script>
    </body>
    </html>
  `;

  printWindow.document.open();
  printWindow.document.write(htmlContent);
  printWindow.document.close();
};

export const downloadProductDetailsExcel = (product, groups = [], brands = []) => {
  if (!product) return;

  const brandObj = brands.find(b => b.id == product.brand_id);
  const brandName = brandObj ? brandObj.name : (product.Brand?.name || '');

  let groupPath = [];
  let currentId = product.group_id;
  while (currentId) {
    const g = groups.find(x => x.id == currentId);
    if (g) {
      groupPath.unshift(g.name);
      currentId = g.parent_id;
    } else {
      break;
    }
  }
  const groupName = groupPath.length > 0 ? groupPath.join(' > ') : (product.Group?.name || '');

  const data = [
    ["FIELD", "VALUE"],
    ["Product Name", product.name || product.product_name || ""],
    ["SKU", product.sku || product.internal_sku || ""],
    ["Product Code", product.product_code || ""],
    ["Product Alias", product.product_alias || ""],
    ["Brand", brandName],
    ["Group / Category", groupName],
    ["Item Type", product.item_type || "Goods"],
    ["Status", product.status || "Active"],
    ["Selling Price", product.selling_price || 0],
    ["MRP", product.mrp || 0],
    ["Purchase Price", product.purchase_price || 0],
    ["Currency", product.currency || "INR"],
    ["GST Rate (%)", product.gst_rate || 0],
    ["In Stock Quantity", product.purchase_quantity || 0],
    ["Reorder Level", product.reorder_level || 0],
    ["Reorder Note", product.reorder_note || ""],
    ["Lot Number", product.lot_number || ""],
    ["Batch Number", product.batch_number || ""],
    ["Manufacturing Date", product.manufacturing_date || ""],
    ["Expiry Date", product.expiry_date || ""],
    ["GTIN / EAN / UPC", product.gtin_ean_upc || ""],
    ["Physical Appearance", product.physical_appearance || product.physical_shape || ""],
    ["Size", product.size || ""],
    ["Packaging", product.packaging || ""],
    ["Length", product.length || ""],
    ["Breadth", product.breadth || ""],
    ["Thickness", product.thickness || ""],
    ["Net Weight", product.net_weight || ""],
    ["Gross Weight", product.gross_weight || ""],
    ["Volume", product.volume || ""],
    ["Warehouse", product.warehouse_location || product.default_warehouse?.name || ""],
    ["Rack Number", product.rack_number || ""],
    ["Shelf Number", product.shelf_number || ""],
    ["Bin Location", product.bin_location || ""],
    ["Safety Stock", product.safety_stock || 0],
    ["Product BOGO Scheme", product.product_pe_product || "None"],
    ["Discount on Product (Offer)", product.discount_on_product || "None"],
    ["Product Target Scheme", product.product_target_scheme || "None"],
    ["Discount on Bill Amount", product.discount_on_bill_amount || "None"],
    ["Quarterly Turnover Discount", product.quarterly_discount_on_turnover || "None"],
    ["Yearly Turnover Discount", product.yearly_discount_on_turnover || "None"],
    ["Seasonal Scheme Name", product.seasonal_scheme_name || "None"],
    ["Seasonal Frequency", product.seasonal_frequency || ""],
    ["Seasonal Period Start", product.seasonal_period_start || ""],
    ["Seasonal Period End", product.seasonal_period_end || ""],
    ["Short Description", (product.short_description || "").replace(/"/g, '""')]
  ];

  if (Array.isArray(product.attributes)) {
    product.attributes.forEach(a => {
      data.push([`Attribute: ${a.Attribute?.name || a.name || 'Custom'}`, a.value || ""]);
    });
  }

  const csvRows = data.map(e => `"${e[0]}","${String(e[1] ?? '').replace(/"/g, '""')}"`).join("\r\n");
  const blob = new Blob(["\uFEFF" + csvRows], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  const fileName = `${(product.name || product.product_name || 'product').toLowerCase().replace(/[^a-z0-9]/g, '_')}_details.csv`;
  link.setAttribute("href", url);
  link.setAttribute("download", fileName);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

export const exportAllProductsExcel = (products = [], groups = [], brands = []) => {
  if (!products || products.length === 0) {
    alert("No products available to export.");
    return;
  }

  const getGroupName = (groupId) => {
    let groupPath = [];
    let currentId = groupId;
    while (currentId) {
      const g = groups.find(x => x.id == currentId);
      if (g) {
        groupPath.unshift(g.name);
        currentId = g.parent_id;
      } else break;
    }
    return groupPath.length > 0 ? groupPath.join(' › ') : '-';
  };

  const getBrandName = (brandId) => {
    const b = brands.find(x => x.id == brandId);
    return b ? b.name : '-';
  };

  const headers = [
    "ID", "Product Name", "SKU", "Group / Category", "Brand",
    "Selling Price", "MRP", "Purchase Price", "Stock Qty", "Reorder Level",
    "GST Rate (%)", "HSN Code", "Barcode", "Lot Number", "Batch Number",
    "Mfg Date", "Expiry Date", "Best Before", "Warehouse", "Rack", "Shelf", "Bin",
    "BOGO Scheme", "Discount on Product (Offer)", "Target Scheme", "Bill Discount",
    "Quarterly Turnover Discount", "Yearly Turnover Discount", "Seasonal Scheme",
    "Status"
  ];

  const rows = products.map(p => [
    p.id,
    p.name || p.product_name || '',
    p.sku || p.internal_sku || '',
    getGroupName(p.group_id),
    getBrandName(p.brand_id),
    p.selling_price || 0,
    p.mrp || 0,
    p.purchase_price || 0,
    p.purchase_quantity || 0,
    p.reorder_level || 0,
    p.gst_rate || 0,
    p.hsn_code || '',
    p.gtin_ean_upc || '',
    p.lot_number || '',
    p.batch_number || '',
    p.manufacturing_date || '',
    p.expiry_date || '',
    p.best_before_date || '',
    p.warehouse_location || p.default_warehouse?.name || '',
    p.rack_number || '',
    p.shelf_number || '',
    p.bin_location || '',
    p.product_pe_product || '',
    p.discount_on_product || '',
    p.product_target_scheme || '',
    p.discount_on_bill_amount || '',
    p.quarterly_discount_on_turnover || '',
    p.yearly_discount_on_turnover || '',
    p.seasonal_scheme_name || '',
    p.status || 'Active'
  ]);

  const csvContent = [
    headers.map(h => `"${h}"`).join(','),
    ...rows.map(r => r.map(val => `"${String(val ?? '').replace(/"/g, '""')}"`).join(','))
  ].join("\r\n");

  const blob = new Blob(["\uFEFF" + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", `Products_Catalog_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};
